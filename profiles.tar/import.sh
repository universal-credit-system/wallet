#!/bin/sh -xv
script_name=${0}
script_path=$(dirname $(readlink -f ${0}))
ls -1 *.asc >${script_path}/keys.tmp
while read line
do
	gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --import ${script_path}/${line}
	key_name=`echo $line|cut -d '_' -f1`
	key_to_move=`ls -1 ${script_path}/keys|grep $key_name`
	cp ${script_path}/${line} ${script_path}/control/keys/${key_to_move}
done <${script_path}/keys.tmp
rm ${script_path}/keys.tmp
