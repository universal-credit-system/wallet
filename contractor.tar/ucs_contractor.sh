#!/bin/bash

###GET SCRIPTPATH#############################
script_path=$(dirname $(readlink -f ${0}))

###GET PID####################################
process_pid=$$

###SET VARIABLES##############################
cmd_ruleset=""
cmd_contract=""

###CHECK FOR STDIN INPUT######################
if [ ! -t 0 ]
then
	set -- $(cat) $*
fi

###GET PARAMETERS#############################
if [ $# -gt 0 ]
then
	cmd_var=""
	cmd_contract=""
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case $1 in
			"-ruleset")	cmd_var=$1
					;;
			"-contract")	cmd_var=$1
					;;
			"-help")	more ${script_path}/control/contractor_HELP.txt
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case $cmd_var in
						"-ruleset")	cmd_ruleset=$1
								;;
						"-contract")	cmd_contract=$1
								;;
						*)		echo "ERROR! TRY THIS:"
								echo "./ucs_contractor.sh -help"
								exit 1
					esac
					;;
		esac
		shift
	done
	if [ -s $cmd_contract ] && [ -s $cmd_ruleset ]
	then
		###SOURCE CONTRACT##########################
		. $cmd_contract

		###EXECUTE CONTRACT#########################
		contract_action
	else
		exit 1
	fi
else
	exit 1
fi
