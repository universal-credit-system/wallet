#!/bin/sh

###GET SCRIPTPATH#############################
script_path=$(cd "$(dirname "$0")" && pwd)

###GET PID####################################
process_pid=$$

###SET VARIABLES##############################
cmd_ruleset=""
cmd_contract=""
debug=0
trace=0

###CHECK FOR STDIN INPUT######################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi

###GET PARAMETERS#############################
if [ $# -gt 0 ]
then
	cmd_var=""
	cmd_contract=""
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case "$1" in
			"-ruleset")	cmd_var=$1
					;;
			"-contract")	cmd_var=$1
					;;
			"-debug")	debug=1	
					set -v
					;;
			"-trace")	trace=1
					set -x
					;;
			"-help")	more ${script_path}/control/contractor_HELP.txt
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case "${cmd_var}" in
						"-ruleset")	cmd_ruleset=$1
								;;
						"-contract")	cmd_contract=$1
								;;
						*)		echo "ERROR! TRY THIS:"
								echo "./ucs_contractor.sh -help"
								exit 1
					esac
					;;
		esac
		shift
	done

	###CHECK IF CONTRACT EXISTS#################
	contract_exists=0
	if [ -f "${cmd_contract}" ] && [ -s "${cmd_contract}" ]
	then
		contract_exists=1
	fi
	
	###CHECK IF RULESET EXISTS##################
	ruleset_exists=0
	if [ -f "${cmd_ruleset}" ] && [ -s "${cmd_ruleset}" ]
	then
		ruleset_exists=1
	fi
	
	if [ "${contract_exists}" -eq 1 ] && [ "${ruleset_exists}" -eq 1 ]
	then
		###SOURCE CONTRACT##########################
		. "${cmd_contract}"

		###EXECUTE CONTRACT#########################
		contract_action
	else
		if [ "${contract_exists}" -eq 0 ] && [ "${ruleset_exists}" -eq 0 ]
		then
			exit 2
		else
			if [ "${contract_exists}" -eq 0 ] && [ "${ruleset_exists}" -eq 1 ]
			then
				exit 3
			else
				exit 4
			fi
		fi
	fi
else
	exit 1
fi
