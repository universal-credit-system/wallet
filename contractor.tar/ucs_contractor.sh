#!/bin/sh

###GET SCRIPTPATH#############################
script_path=$(dirname $(readlink -f ${0}))

###GET PARAMETERS#############################
if [ $# -gt 0 ]
then
	cmd_var=""
	cmd_contract=""
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case $1 in
			"-contract")	cmd_var=$1
					;;
			"-help")	more ${script_path}/control/contractor_HELP.txt
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case $cmd_var in
						"-contract")	cmd_contract=$1
								;;
						*)		echo "ERROR! TRY THIS:"
								echo "./ucs_contractor.sh -help"
								exit 1
					esac
					;;
		esac
		shift
	done
	if [ -s $cmd_contract ]
	then
		###SOURCE CONTRACT FILE TO GET RULESET################################
		. ${cmd_contract}
	
		##CHECK FOR WILDCARDS#################################################
		if [ "${ruleset_sender}" = "*" ]
		then
			ruleset_sender=""
		fi
		if [ "${ruleset_receiver}" = "*" ]
		then
			ruleset_receiver=""
		fi
		if [ "${ruleset_amount}" = "*" ]
		then
			ruleset_amount=""
		fi
		if [ "${ruleset_purpose}" = "*" ]
		then
			ruleset_purpose=""
		fi
		

		###GO THROUGH ALL TRX THAT HAVE THIS SENDER/RECEIVER/PURPOSE##########
		for trx_file_full in `grep -l "SNDR:${ruleset_sender}\|RCVR:${ruleset_receiver}\|PRPS:${ruleset_purpose}" ${script_path}/trx/*|grep -v "${contract_sender}" 2>/dev/null`
		do
			###GET VALUES OF THIS TRANSACTION#####################################
			trx_stamp=`sed -n '4p' ${trx_file_full}|cut -d ':' -f2`
			trx_amount=`sed -n '5p' ${trx_file_full}|cut -d ':' -f2`
			trx_sender=`sed -n '6p' ${trx_file_full}|cut -d ':' -f2`
			trx_receiver=`sed -n '7p' ${trx_file_full}|cut -d ':' -f2`
			trx_purpose_full=`sed -n '8p' ${trx_file_full}`
			trx_purpose_size=`echo "${purpose}"|wc -c`
			if [ $trx_purpose_size -gt 6 ]
			then
				trx_purpose=`echo $trx_purpose_full|cut -c 6-$trx_purpose_size`
			else
				trx_purpose=""
			fi
	
			###GET BASENAME#######################################################
			trx_file=`basename ${trx_file_full}`

			###SOURCE CONTRACT FILE TO GET CONTRACT###############################
			. ${cmd_contract}

			##CHECK FOR WILDCARDS#################################################
			if [ "${ruleset_sender}" = "*" ]
			then
				ruleset_sender=""
			fi
			if [ "${ruleset_receiver}" = "*" ]
			then
				ruleset_receiver=""
			fi
			if [ "${ruleset_amount}" = "*" ]
			then
				ruleset_amount=""
			fi
			if [ "${ruleset_purpose}" = "*" ]
			then
				ruleset_purpose=""
			fi

			###CHECK IF AMOUNT MATCHES CONTRACT###################################
			skip_check_amount=0
			safety_block=1
			if [ "${ruleset_amount}" = "" -a "${ruleset_amount_comparison_variable}" = "" -a "${ruleset_amount_comparison_operator}" = "" ]
			then
				safety_block=0
				skip_check_amount=1
			else
				if [ ! "${ruleset_amount}" = "" -a ! "${ruleset_amount_comparison_operator}" = "" ]
				then
					safety_block=0
				else
					if [ ! "${ruleset_amount_comparison_variable}" = "" -a ! "${ruleset_amount_comparison_operator}" = "" ]
					then
						safety_block=0
					fi
				fi
			fi
			if [ $safety_block = 1 ]
			then
				is_matching=0
			else
				case $ruleset_amount_comparison_operator in
					"lt")	ruleset_amount_comparison_operator="<"
						;;
					"<")	ruleset_amount_comparison_operator="<"
						;;
					"le")	ruleset_amount_comparison_operator="<="
						;;
					"<=")	ruleset_amount_comparison_operator="<="
						;;
					"eq")	ruleset_amount_comparison_operator="=="
						;;
					"=")	ruleset_amount_comparison_operator="=="
						;;
					"==")	ruleset_amount_comparison_operator="=="
						;;
					"ge")	ruleset_amount_comparison_operator=">="
						;;
					">=")	ruleset_amount_comparison_operator=">="
						;;
					"gt")	ruleset_amount_comparison_operator=">"
						;;
					">")	ruleset_amount_comparison_operator=">"
						;;
				esac
				if [ $skip_check_amount = 1 ]
				then
					is_matching=1
				else
					is_matching=`echo "${trx_amount} ${ruleset_amount_comparison_operator} ${ruleset_amount_comparison_variable}"|bc`
					rt_query=$?
					if [ $rt_query -gt 0 ]
					then
						is_matching=0
					fi
				fi
			fi
			###IF MATCHED OR NO CHECK TOOK PLACE######################################
			if [ $is_matching = 1 ]
			then
				###CHECK IF TRX ALREADY PROCESSED#########################################
				already_processed=`grep "PRPS:${contract_purpose}" ${script_path}/trx/${contract_sender}.*|wc -l` 2>/dev/null
				if [ $already_processed = 0 ]
				then
					###CHECK IF TRX HAS ENOUGH CONFIRMATIONS##################################
					enough_confirmations=`grep -l "trx/${trx_file}" ${script_path}/proofs/*.*/*.txt|grep -v "${contract_sender}\|${contract_receiver}"|wc -l` 2>/dev/null
					contract_sender_acknowledged=`grep -l "trx/${trx_file}" ${script_path}/proofs/${contract_sender}/${contract_sender}.txt`
					if [ $enough_confirmations -ge $ruleset_required_confirmations ]
					then
						if [ "${contract_receiver}" = "*" ]
						then
							for receiver in `ls -1 ${script_path}/keys`
							do
								if [ ! "${contract_sender}" = "${receiver}" ]
								then
									###GET STAMP##########################################################
									now=`date +%s`
								
									###WRITE OUTPUT#######################################################
									echo "CONTRACT_${now}:${trx_file}"

									###CALL UCS_CLIENT####################################################
									./ucs_client.sh -action create_trx -sender ${contract_sender} -password "${contract_sender_password}" -receiver ${receiver} -amount ${contract_amount} -purpose ${contract_purpose} -type $contract_type
								fi
							done
						else
							if [ ! "${contract_receiver}" = "" ]
							then
								###GET STAMP##########################################################
								now=`date +%s`
								
								###WRITE OUTPUT#######################################################
								echo "CONTRACT_${now}:${trx_file}"

								###CALL UCS_CLIENT####################################################
								./ucs_client.sh -action create_trx -sender ${contract_sender} -password "${contract_sender_password}" -receiver ${contract_receiver} -amount ${contract_amount} -purpose ${contract_purpose} -type $contract_type
							fi
						fi
					fi
				fi
			fi
		done
	else
		exit 1
	fi
else
	exit 1
fi
