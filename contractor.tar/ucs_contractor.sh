#!/bin/sh

###GET SCRIPTPATH#############################
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")

###GET PID####################################
my_pid=$$

###SET VARIABLES##############################
cmd_ruleset=""
cmd_contract=""
debug=0
trace=0

###CHECK FOR STDIN INPUT######################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi

###GET PARAMETERS#############################
if [ $# -gt 0 ]
then
	cmd_var=""
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case "$1" in
			"-ruleset")	cmd_var=$1
					;;
			"-contract")	cmd_var=$1
					;;
			"-debug")	debug=1	
					set -v
					;;
			"-trace")	trace=1
					set -x
					;;
			"-help")	more "${script_path}"/control/contractor_HELP.txt
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case "${cmd_var}" in
						"-ruleset")	cmd_ruleset=$1
								;;
						"-contract")	cmd_contract=$1
								;;
						*)		printf "%s\n" "[${script_name}][ERROR][parser] Unexpected argument $1" >&2
								exit 1
					esac
					;;
		esac
		shift
	done

	###CHECK IF CONTRACT EXISTS#################
	contract_exists=0
	contract_set=0
	if [ -n "${cmd_contract}" ]
	then
		contract_set=1
	fi
	if [ "${contract_set}" -eq 1 ] && [ -f "${cmd_contract}" ] && [ -s "${cmd_contract}" ]
	then
		contract_exists=1
	fi
	
	###CHECK IF RULESET EXISTS##################
	ruleset_exists=0
	ruleset_set=0
	if [ -n "${cmd_ruleset}" ]
	then
		ruleset_set=1
	fi
	if [ "${ruleset_set}" -eq 1 ] && [ -f "${cmd_ruleset}" ] && [ -s "${cmd_ruleset}" ]
	then
		ruleset_exists=1
	fi
	
	if [ "${contract_exists}" -eq 1 ] && [ "${ruleset_exists}" -eq 1 ]
	then
		###SOURCE CONTRACT##########################
		. "${cmd_contract}"

		###TEST IF FUNCTION CONTRACT_ACTION EXISTS##
		if command -v "contract_action" >/dev/null 2>&1
		then
			###EXECUTE CONTRACT#########################
			contract_action
		else
			printf "%s\n" "[${script_name}][ERROR][parser] couldn't source function contract_action from contract file ${cmd_contract}" >&2
			exit 2
		fi
	else
		if [ "${ruleset_set}" -eq 0 ]
		then
			printf "%s\n" "[${script_name}][ERROR][parser] parameter -ruleset empty" >&2
		fi
		if [ "${ruleset_exists}" -eq 0 ]
		then
			printf "%s\n" "[${script_name}][ERROR][parser] ruleset file not found or empty" >&2
		fi
		if [ "${contract_set}" -eq 0 ]
		then
			printf "%s\n" "[${script_name}][ERROR][parser] parameter -contract empty" >&2
		fi
		if [ "${contract_exists}" -eq 0 ]
		then
			printf "%s\n" "[${script_name}][ERROR][parser] countract file not found or empty" >&2
		fi
		if [ "${ruleset_exists}" -eq 0 ] && [ "${contract_exists}" -eq 0 ]
		then
			exit 3
		else
			if [ "${contract_exists}" -eq 0 ]
			then
				exit 4
			fi
			if [ "${ruleset_exists}" -eq 0 ]
			then
				exit 5
			fi
		fi
	fi
else
	exit 1
fi
