#!/bin/sh

###GET SCRIPTPATH#############################
script_path=$(dirname $(readlink -f ${0}))

###SET VARIABLES##############################
contract_check_sender=""
contract_check_amount=""
contract_check_operator=""
contract_check_purpose=""
contract_check_receiver=""
contract_sender=""
contract_sender_pw=""
contract_amount=""
contract_purpose=""
contract_receiver=""

###GET PARAMETER##############################
if [ $# -gt 0 ]
then
	cmd_contract=""
	cmd_var=""
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case $1 in
			"-contract")	cmd_var=$1			
					;;
			"-help")	more ${script_path}/control/contractor_HELP.txt
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case $cmd_var in
						"-contract")	cmd_contract=$1
								;;
						*)		echo "ERROR! TRY THIS:"
								echo "./ucs_contractor.sh -help"
								exit 1
					esac	
					;;
		esac
		shift
	done
	if [ -s $cmd_contract ]
	then
		###READ CONTRACT FILE###################################
		contract_check_sender=`sed -n '1p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_check_amount=`sed -n '2p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_check_operator=`sed -n '3p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_check_purpose=`sed -n '4p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_check_receiver=`sed -n '5p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_check_confirmations=`sed -n '6p' ${cmd_contract}|cut -d '=' -f2`
		contract_sender=`sed -n '7p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_sender_pw=`sed -n '8p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_amount=`sed -n '9p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_purpose=`sed -n '10p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_receiver=`sed -n '11p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`
		contract_trx_type=`sed -n '12p' ${cmd_contract}|cut -d '=' -f2|cut -d '"' -f2`

		###ASSING VALUES########################################
		if [ "${contract_check_sender}" = "*" ]
		then
			contract_check_sender=""
		else
			if [ "${contract_check_sender}" = "" ]
			then
				exit 1
			fi
		fi

		###ASSING VALUES########################################
		if [ "${contract_check_amount}" = "*" ]
		then
			contract_check_amount=""
		else
			if [ "${contract_check_amount}" = "" ]
			then
				exit 1
			fi
		fi
	
		###GET COMPARISON OPERATOR##############################
		case $contract_check_operator in
                        "eq") contract_check_op="=="
                              ;;
                        "ge") contract_check_op=">="
                              ;;
                        "gt") contract_check_op=">"
                              ;;
                        "le") contract_check_op="<="
                              ;;
                        "lt") contract_check_op="<"
                              ;;
                        "ne") contract_check_op="!="
                              ;;
                        *)    exit 1
                              ;;
                esac

		###ASSING VALUES########################################
		if [ "${contract_check_purpose}" = "*" ]
		then
			contract_check_purpose=""
		else
			if [ "${contract_check_purpose}" = "" ]
			then
				exit 1
			fi
		fi

		###ASSING VALUES########################################
		if [ "${contract_check_receiver}" = "*" ]
		then
			contract_check_receiver=""
		else
			if [ "${contract_check_receiver}" = "" ]
			then
				exit 1
			fi
		fi

		###ASSING VALUES########################################
		if [ "${contract_check_confirmations}" = "*" ]
		then
			contract_check_confirmations=0
		else
			if [ "${contract_check_confirmations}" = "" ]
			then
				exit 1
			fi
		fi

		###ASSING VALUES########################################
		if [ ! "${contract_trx_type}" = "partial" ]
		then
			if [ ! "${contract_trx_type}" = "full" ]
			then
				exit 1
			fi
		fi

		###GO THROUGH ALL TRX THAT HAVE THIS SENDER/RECEIVER/PURPOSE##########
		for each_trx in `grep -l "SNDR:${contract_check_sender}\|RCVR:${contract_check_receiver}\|PRPS:${contract_check_purpose}" ${script_path}/trx/* 2>/dev/null`
		do
			###GET TRX AMOUNT OF THIS TRANSACTION##############
			trx_amount=`sed -n '5p' ${each_trx}|cut -d ':' -f2`
			if [ "${contract_check_amount}" = "" ]
			then
				contract_check_amount=0
				contract_check_operator="gt"
			fi

			###ASSING VALUES###################################
			if [ "${contract_amount}" = "*" ]
			then
				contract_amount=$trx_amount
			fi

			###ASSING VALUES###################################
			c_trx=`basename ${each_trx}`
			if [ "${contract_purpose}" = "*" ]
			then
				contract_purpose=`printf "${c_trx}"|sha256sum|cut -d ' ' -f1`
			else
				tmp_contract_purpose=$contract_purpose
				contract_purpose=`printf "${contract_purpose}"|sha256sum|cut -d ' ' -f1`
			fi

			###CHECK IF AMOUNT MATCHES CONTRACT################
			is_matching=`echo "${trx_amount} ${contract_check_op} ${contract_check_amount}"|bc`
			if [ $is_matching = 1 ]
			then
				###CHECK IF ALREADY PROCESSED######################
				already_processed=`grep "PRPS:${c_trx}" ${script_path}/trx/${contract_sender}.*|wc -l` 2>/dev/null
				if [ $already_processed = 0 ]
				then
					###CHECK IF TRX HAS ENOUGH CONFIRMATIONS###########
					enough_confirmations=`grep -l "trx/${c_trx}" proofs/*.*/*.txt|grep -v "${contract_sender}\|${contract_receiver}"|wc -l` 2>/dev/null
					if [ $enough_confirmations -ge $contract_check_confirmations ]
					then
						if [ "${contract_receiver}" = "*" ]
						then
							for each_key in `ls -1 ${script_path}/keys`
							do
								if [ ! "${contract_sender}" = "${each_key}" ]
								then
									./ucs_client.sh -action create_trx -sender ${contract_sender} -password '${contract_sender_pw}' -receiver ${each_key} -amount ${contract_amount} -purpose ${contract_purpose} -type $contract_trx_type
								fi
							done
						else
							if [ ! "${contract_receiver}" = "" ]
							then
								./ucs_client.sh -action create_trx -sender ${contract_sender} -password '${contract_sender_pw}' -receiver ${contract_check_receiver} -amount ${contract_amount} -purpose ${contract_purpose} -type $contract_trx_type
							else
								exit 1
							fi
						fi
					fi
				fi
			fi
		done
	else
		exit 1
	fi
else
	exit 1
fi