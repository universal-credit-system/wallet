#!/bin/sh
cleanup_pids(){
		kill "${sender_pid}" "${receiver_pid}" "${filewatch_pid}" "${logwatch_pid}" 2>/dev/null
		terminated=1
}
start_sender(){
		### START SENDER SCRIPT #####################
		tcpserver -R -c "${max_connect_sender}" "${bind_ip_address}" "${sender_port}" "${script_path}"/sender.sh "${session_pid}" &
		sender_pid=$!
		echo "$(date -u): [INFO] started sender.sh with PID ${sender_pid}"|tee -a "${script_path}"/log/sender.log >>"${script_path}"/log/server.log
}
start_receiver(){
		### START RECEIVER SCRIPT ###################
		tcpserver -R -c "${max_connect_receiver}" "${bind_ip_address}" "${receiver_port}" "${script_path}"/receiver.sh "${session_pid}" &
		receiver_pid=$!
		echo "$(date -u): [INFO] started receiver.sh with PID ${receiver_pid}"|tee -a "${script_path}"/log/receiver.log >>"${script_path}"/log/server.log
}
start_filewatch(){
		### START FILEWATCH SCRIPT ##################
		"${script_path}"/filewatch.sh "${session_pid}" &
		filewatch_pid=$!
		echo "$(date -u): [INFO] started filewatch.sh with PID ${filewatch_pid}" >>"${script_path}"/log/server.log
}
start_logwatch(){
		### START LOGWATCH SCRIPT ###################
		"${script_path}"/logwatch.sh "${session_pid}" &
		logwatch_pid=$!
		echo "$(date -u): [INFO] started logwatch.sh with PID ${logwatch_pid}" >>"${script_path}"/log/server.log
}
### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(cd "$(dirname "$0")" || exit 1; pwd)

### GET SESSION-PID##########################
session_pid=$$

### SET DEFAULT FOR SIGTERM TRIGGER #########
terminated=0

### SOURCE CONFIG ###########################
. "${script_path}"/control/server.conf

### CLEANUP AT START ########################
[ -d "${script_path}/server" ] && rm -f "${script_path}/server/"* 2>/dev/null

### START SENDER SCRIPT #####################
start_sender

### START RECEIVER SCRIPT ###################
start_receiver

### START FILEWATCH SCRIPT ##################
start_filewatch

### START LOGWATCH SCRIPT ###################
start_logwatch

### SET UP TRAP TO CLEAN UP PIDS ############
trap cleanup_pids INT TERM EXIT

### CHECK IF PROCESSES ARE UP ###############
while [ "${terminated}" -eq 0 ]
do
	### CHECK IF SENDER IS STILL RUNNING ########
	if ! kill -0 "${sender_pid}" 2>/dev/null
        then
  		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): [ERROR] listener of sender.sh crashed, restart"|tee -a "${script_path}"/log/sender.log >>"${script_path}"/log/server.log

		### RESTART #################################
		start_sender
	fi

	### CHECK IF RECEIVER IS STILL RUNNING ######
	if ! kill -0 "${receiver_pid}" 2>/dev/null
	then
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): [ERROR] listener of receiver.sh crashed, restart"|tee -a "${script_path}"/log/receiver.log >>"${script_path}"/log/server.log

		### RESTART #################################
		start_receiver
	fi

	### CHECK IF FILEWATCH IS STILL RUNNING #####
	if ! kill -0 "${filewatch_pid}" 2>/dev/null
	then
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): [ERROR] filewatch.sh crashed, restart" >>"${script_path}"/log/server.log

		### RESTART #################################
		start_filewatch
	fi

	### CHECK IF LOGWATCH IS STILL RUNNING ######
	if ! kill -0 "${logwatch_pid}" 2>/dev/null
	then
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): [ERROR] logwatch.sh crashed, restart" >>"${script_path}"/log/server.log

		### RESTART #################################
		start_logwatch
	fi
	
	### CHECK EVERY 60 SECONDS ##################
	sleep 60
done
