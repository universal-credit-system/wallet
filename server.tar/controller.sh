#!/bin/sh
start_sender(){
		### START SENDER SCRIPT #####################
		tcpserver -R -c ${max_connect_sender} ${bind_ip_address} ${sender_port} ${script_path}/sender.sh ${session_pid} &
		sender_pid=$!
		server_date=$(date -u)
		echo "${server_date}: started sender.sh with PID ${sender_pid}" >>${script_path}/log/server.log
}
start_receiver(){
		### START RECEIVER SCRIPT ###################
		tcpserver -R -c ${max_connect_receiver} ${bind_ip_address} ${receiver_port} ${script_path}/receiver.sh ${session_pid} &
		receiver_pid=$!
		server_date=$(date -u)
		echo "${server_date}: started receiver.sh with PID ${receiver_pid}" >>${script_path}/log/server.log
}
start_filewatch(){
		### START FILEWATCH SCRIPT ##################
		${script_path}/filewatch.sh ${session_pid} &
		filewatch_pid=$!
		server_date=$(date -u)
		echo "${server_date}: started filewatch.sh with PID ${filewatch_pid}" >>${script_path}/log/server.log
}
start_logwatch(){
		### START LOGWATCH SCRIPT ###################
		${script_path}/logwatch.sh ${session_pid} &
		logwatch_pid=$!
		server_date=$(date -u)
		echo "${server_date}: started logwatch.sh with PID ${logwatch_pid}" >>${script_path}/log/server.log
}
### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### GET SESSION-PID##########################
session_pid=$$

### SOURCE CONFIG ###########################
. ${script_path}/control/server.conf

### CLEANUP AT START ########################
rm ${script_path}/server/* 2>/dev/null

### WRITE LOGFILE ENTRY #####################
server_date=$(date -u)
echo "${server_date}: starting server..." >>${script_path}/log/server.log

### START SENDER SCRIPT #####################
start_sender

### START RECEIVER SCRIPT ###################
start_receiver

### START FILEWATCH SCRIPT ##################
start_filewatch

### START LOGWATCH SCRIPT ###################
start_logwatch

### CHECK IF PROCESSES ARE UP ###############
while true
do
	sleep 60
	ps --pid $sender_pid >/dev/null
	service_running=$?
	if [ ! $service_running = 0 ]
	then
		start_sender
	fi
	ps --pid $receiver_pid >/dev/null
	service_running=$?
	if [ ! $service_running = 0 ]
	then
		start_receiver
	fi
	ps --pid $filewatch_pid >/dev/null
	service_running=$?
	if [ ! $service_running = 0 ]
	then
		start_filewatch
	fi
	ps --pid $logwatch_pid >/dev/null
	service_running=$?
	if [ ! $service_running = 0 ]
	then
		start_logwatch
	fi
done

