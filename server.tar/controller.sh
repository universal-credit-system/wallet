#!/bin/sh

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### GET SESSION-PID##########################
session_pid=$$

### SOURCE CONFIG ###########################
. ${script_path}/control/server.conf

### CLEANUP AT START ########################
rm ${script_path}/server/* 2>/dev/null

### WRITE LOGFILE ENTRY #####################
server_date=$(date -u)
echo "${server_date}: starting server..." >>${script_path}/log/server.log

### START SENDER SCRIPT #####################
tcpserver -R -c ${max_connect_sender} ${bind_ip_address} ${sender_port} ${script_path}/sender.sh ${session_pid} &
sender_pid=$!
server_date=$(date -u)
echo "${server_date}: started sender.sh with PID ${sender_pid}" >>${script_path}/log/server.log

### START RECEIVER SCRIPT ###################
tcpserver -R -c ${max_connect_receiver} ${bind_ip_address} ${receiver_port} ${script_path}/receiver.sh ${session_pid} ${sync_user_name} ${sync_user_pin} ${sync_user_pw} &
receiver_pid=$!
server_date=$(date -u)
echo "${server_date}: started receiver.sh with PID ${receiver_pid}" >>${script_path}/log/server.log

### START FILEWATCH SCRIPT ##################
${script_path}/filewatch.sh ${session_pid} &
filewatch_pid=$!
server_date=$(date -u)
echo "${server_date}: started filewatch.sh with PID ${filewatch_pid}" >>${script_path}/log/server.log

### START LOGWATCH SCRIPT ###################
${script_path}/logwatch.sh ${session_pid} &
logwatch_pid=$!
server_date=$(date -u)
echo "${server_date}: started logwatch.sh with PID ${logwatch_pid}" >>${script_path}/log/server.log

### SET VARIRABLES FOR LOOP #################
sender_running=0
receiver_running=0
filewatch_running=0
logwatch_running=0

### CHECK IF PROCESSES ARE UP ###############
while [ $sender_running = 0 ] && [ $receiver_running = 0 ] && [ $filewatch_running = 0 ] && [ $logwatch_running = 0 ]
do
	sleep 60
	ps --pid $sender_pid >/dev/null
	sender_running=$?
	ps --pid $receiver_pid >/dev/null
	receiver_running=$?
	ps --pid $filewatch_pid >/dev/null
	filewatch_running=$?
	ps --pid $logwatch_pid >/dev/null
	logwatch_running=$?
done

### WRITE LOGFILE ENTRY #####################
server_date=$(date -u)
echo "${server_date}: stopping server..." >>${script_path}/log/server.log

### CLEAN UP PROCESSES ######################
if [ $sender_running = 0 ]
then
	kill $sender_pid
	echo "${server_date}: killed sender.sh" >>${script_path}/log/server.log
fi
if [ $receiver_running = 0 ]
then
        kill $receiver_pid
	echo "${server_date}: killed receiver.sh" >>${script_path}/log/server.log
fi
if [ $filewatch_running = 0 ]
then
	kill $filewatch_pid
	echo "${server_date}: killed filewatch.sh" >>${script_path}/log/server.log
fi
if [ $logwatch_running = 0 ]
then
	kill $logwatch_pid
	echo "${server_date}: killed logwatch.sh" >>${script_path}/log/server.log
fi

### SAY GOODBYE #############################
echo "${server_date}: server stopped. bye bye" >>${script_path}/log/server.log

### CALL START_SERVER.SH TO START AGAIN #####
${script_path}/start_server.sh &
