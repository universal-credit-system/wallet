#!/bin/sh
start_sender(){
		### START SENDER SCRIPT #####################
		tcpserver -R -c "${max_connect_sender}" "${bind_ip_address}" "${sender_port}" "${script_path}"/sender.sh "${session_pid}" &
		sender_pid=$!
		echo "$(date -u): started sender.sh with PID ${sender_pid}"|tee "${script_path}"/log/sender.log >>"${script_path}"/log/server.log
}
start_receiver(){
		### START RECEIVER SCRIPT ###################
		tcpserver -R -c "${max_connect_receiver}" "${bind_ip_address}" "${receiver_port}" "${script_path}"/receiver.sh "${session_pid}" &
		receiver_pid=$!
		echo "$(date -u): started receiver.sh with PID ${receiver_pid}"|tee "${script_path}"/log/receiver.log >>"${script_path}"/log/server.log
}
start_filewatch(){
		### START FILEWATCH SCRIPT ##################
		"${script_path}"/filewatch.sh "${session_pid}" &
		filewatch_pid=$!
		echo "$(date -u): started filewatch.sh with PID ${filewatch_pid}" >>"${script_path}"/log/server.log
}
start_logwatch(){
		### START LOGWATCH SCRIPT ###################
		"${script_path}"/logwatch.sh "${session_pid}" &
		logwatch_pid=$!
		echo "$(date -u): started logwatch.sh with PID ${logwatch_pid}" >>"${script_path}"/log/server.log
}
### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname "$(readlink -f "${0}")")

### GET SESSION-PID##########################
session_pid=$$

### SOURCE CONFIG ###########################
. "${script_path}"/control/server.conf

### CLEANUP AT START ########################
rm "${script_path}"/server/* 2>/dev/null

### WRITE LOGFILE ENTRY #####################
echo "$(date -u): starting server..." >>"${script_path}"/log/server.log

### START SENDER SCRIPT #####################
start_sender

### START RECEIVER SCRIPT ###################
start_receiver

### START FILEWATCH SCRIPT ##################
start_filewatch

### START LOGWATCH SCRIPT ###################
start_logwatch

### CHECK IF PROCESSES ARE UP ###############
while true
do
	### CHECK EVERY 60 SECONDS ##################
	sleep 60

	### CHECK IF SENDER IS STILL RUNNING ########
	ps --pid "$sender_pid" >/dev/null
	service_running=$?
	if [ "$service_running" -ne 0 ]
	then
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): Listener of sender.sh crashed, restart..."|tee "${script_path}"/log/sender.log >>"${script_path}"/log/server.log

		### RESTART #################################
		start_sender
	fi

	### CHECK IF RECEIVER IS STILL RUNNING ######
	ps --pid "$receiver_pid" >/dev/null
	service_running=$?
	if [ "$service_running" -ne 0 ]
	then
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): Listener of receiver.sh crashed, restart..."|tee "${script_path}"/log/receiver.log >>"${script_path}"/log/server.log

		### RESTART #################################
		start_receiver
	fi

	### CHECK IF FILEWATCH IS STILL RUNNING #####
	ps --pid "$filewatch_pid" >/dev/null
	service_running=$?
	if [ "$service_running" -ne 0 ]
	then
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): filewatch.sh crashed, restart..." >>"${script_path}"/log/server.log

		### RESTART #################################
		start_filewatch
	fi

	### CHECK IF LOGWATCH IS STILL RUNNING ######
	ps --pid "$logwatch_pid" >/dev/null
	service_running=$?
	if [ "$service_running" -ne 0 ]
	then
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): logwatch.sh crashed, restart..." >>"${script_path}"/log/server.log

		### RESTART #################################
		start_logwatch
	fi
done
