#!/bin/sh
trap_command(){
	    	command_to_add="$1"
		if [ -n "${command_to_add:-}" ]
		then
			if [ -z "${current_trap:-}" ]
		    	then
		    		### IF EMPTY SET TRAP #########################
		    		current_trap=${command_to_add}
		    		trap "${command_to_add}" EXIT
		    	else
		    		### IF NOT EMPTY APPEND #######################
				trap "${current_trap}; ${command_to_add}" EXIT
				current_trap="${current_trap}; ${command_to_add}"
			fi
		fi
}
print_message(){
		message="$1"
		if [ -n "${message}" ]
		then
			printf "%b" "${message}"|tee -a "${script_path}/install_server_${timestamp}.log"
		else
			if [ "${rt_query}" -eq 0 ]
			then
				printf "%s\n" "DONE"|tee -a "${script_path}/install_server_${timestamp}.log"
			else
				printf "%s\n" "FAILED"|tee -a "${script_path}/install_server_${timestamp}.log"
				error_counter=$(( error_counter + 1 ))
			fi
		fi
		rt_query=0
}
### SET VARIABLES ############
timestamp=$(date -u +%Y%m%d_%H%M%S)
script_path=$(dirname "$(readlink -f "${0}")")
script_name=$(basename "${0}")
current_trap=""
error_counter=0
cmd_env=""
cmd_user=""

### ASSIGN VARIABLES ###########
if [ $# -gt 0 ]
then
	cmd_var=""

	### GO THROUGH PARAMETERS ######
	while [ $# -gt 0 ]
	do
		### GET TARGET VARIABLES #######
		case $1 in
			"-env")		cmd_var=$1
					;;
			"-user")	cmd_var=$1
					;;
			"-debug")	set -v
					;;
			"-trace")	set -x
					;;
			"-help")	more "${script_path}"/control/install_server_HELP.txt
					exit 0
					;;
			*)		### SET TARGET VARIABLES #######
					case "${cmd_var}" in
						"-env")	cmd_env=$(printf "%b" "${1}"|tr '[:upper:]' '[:lower:]')
							;;
						"-user")cmd_user=$1
							;;
						*)	printf "%s\n" "[${script_name}][ERROR][parser] Unexpected argument $1"
							printf "%s\n" "[${script_name}][INFO] To display the HELP run: ./install_server.sh -help"
							exit 1
							;;
					esac
					cmd_var=""
					;;
		esac
		shift
	done

fi

### CREATE TMP ###############
trap_command '[ -n "${install_dep:-}" ] && rm -f -- "${install_dep}"'
install_dep=$(mktemp "${script_path}/tmp/install_server.XXXXXX") || exit 2
trap_command '[ -n "${install_service:-}" ] && rm -f -- "${install_service}"'
install_service=$(mktemp "${script_path}/tmp/install_server.XXXXXX") || exit 3
trap_command '[ -n "${config_tmp:-}" ] && rm -f -- "${config_tmp}"'
config_tmp=$(mktemp "${script_path}/tmp/install_server.XXXXXX") || exit 4

### DISPLAY OUTPUT #######################
print_message "[${script_name}][INFO] Start installation\n"

### CHECK DEPENDENCIES #######
while read program
do
	### CONSIDER PACKAGE != COMMAND #####
	if [ "${program}" = "ucspi-tcp-ipv6" ]
	then
		program="tcpserver"
	fi
	### CHECK IF PROGRAMM IS UNKNOWN ####
        type "${program}" >/dev/null 2>/dev/null
        rt_query=$?
        if [ "$rt_query" -gt 0 ]
        then
        	### CONSIDER PACKAGE != COMMAND #####
		if [ "${program}" = "tcpserver" ]
		then
			program="ucspi-tcp-ipv6"
		fi
		### WRITE DEPENDENCY TO FILE ########
        	echo "${program}"  >>"${install_dep}"
        fi
done <"${script_path}"/control/server_install.dep
if [ -f "${install_dep}" ] && [ -s "${install_dep}" ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case "${cmd_env}" in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				for pmgr in apk apt-get brew dnf pacman pkg pkg_add pkgin swinstall yum zypper
				do
					if [ -x "$(command -v "${pmgr}")" ]
					then
						pkg_mngr="${pmgr}";
						break
					fi
				done
				if [ -z "${pkg_mngr}" ]
				then
					###IF PACKAGING MANAGER DETECTION FAILED####
					error_counter=1
					no_of_programs=$(wc -l <"${install_dep}")
					print_message "[${script_name}][ERROR][package] Couldn't detect the package management system used on this machine!\n"
					print_message "[${script_name}][ERROR][package] Found ${no_of_programs} programs that need to be installed:\n"
					awk -v script_name="${script_name}" '{print "[" script_name "][ERROR][package] -> " $1}' "${install_dep}"
					print_message "[${script_name}][ERROR][package] Install these programms first using your package management system and then run ${script_name} again.\n"
					############################################
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ "${error_counter}" -eq 0 ]
	then
		### INSTALL MISSING PKGS #####
		while IFS= read -r program
		do
			tried_all=0
			while [ "${tried_all}" -eq 0 ]
			do
				print_message "[${script_name}][INFO] Trying to install ${program} using ${pkg_mngr}\n"
				case "${pkg_mngr}" in
					"apk")		apk add "${program}" ;;
					"apt-get")	apt-get -y install "${program}" ;;
					"brew")		brew install "${program}" ;;
					"dnf")		dnf -y install "${program}" ;;
					"pacman")	pacman --noconfirm -S "${program}" ;;
					"pkg")		pkg install -y "${program}" ;;
					"pkg_add")	env BATCH=Yes pkg_add -I -D automated "${program}" ;;
					"pkgin")	pkgin -y install "${program}" ;;
					"swinstall")	swinstall -x autoreboot=false "${program}" ;;
					"yum")		yum -y install "${program}" ;;
					"zypper")	zypper -n install "${program}" ;;
				esac
				rt_query=$?
				if [ "$rt_query" -ne 0 ]
				then
					print_message "[${script_name}][ERROR] Error running the following command: ${pkg_mngr} install ${program}\n"
					print_message "[${script_name}][ERROR] Maybe the program ${program} is available in a package with different name\n"
					if [ "${program}" = "ucspi-tcp-ipv6" ]
					then
						new_program="ucspi-tcp6"
						print_message "[${script_name}][INFO] Trying package name ${new_program} instead of ${program}\n"
						program=$new_program
					else
						print_message "[${script_name}][ERROR] Could not install program: ${program}\n"
						error_counter=$(( error_counter + 1 ))
						tried_all=1
					fi
				else
					tried_all=1
				fi
			done
		done <"${install_dep}"
		############################
	fi
fi

if [ -n "${cmd_user}" ]
then
	### DOCUMENT SU COMMAND ######
	print_message "[${script_name}][INFO] Switch to user ${cmd_user}\n"
	su - "${cmd_user}" || exit 5
fi

###CONFIGURE UCA.SERVICE####
print_message "[${script_name}][INFO] Configure ${script_path}/uca.service...\n"
user=$(whoami)
sed "s/<<USER>>/${user}/g" "${script_path}"/uca.service.template >"${script_path}"/uca.service || rt_query=1
sed "s#<<SCRIPT_PATH>>#${script_path}#g" "${script_path}"/uca.service >"${install_service}" && mv "${install_service}" "${script_path}"/uca.service || rt_query=1
print_message

### IF OLD CONFIG THERE ######
if [ -s "${script_path}"/control/server.conf ]
then
	print_message "[${script_name}][INFO] Backup old config ( ->control/server.bak )..."
	mv -- "${script_path}"/control/server.conf "${script_path}"/control/server.bak || rt_query=1
	print_message
fi

### COPY TO PLACE ############
print_message "[${script_name}][INFO] Copy install_server.conf to server.conf..."
cp -- "${script_path}"/control/install_server.conf "${script_path}"/control/server.conf || rt_query=1
print_message

### REWRITE CONFIG ###########
if [ -s "${script_path}"/control/server.bak ]
then
	### READ OLD CONFIG #########
	grep -vF -- "#" "${script_path}"/control/server.bak | while IFS= read -r config_line
	do
		if [ -n "${config_line:-}" ]
		then
			### EXTRACT CONFIG LINES ###############
			conf_var="${config_line%%=*}"
			conf_var_val="${config_line#*=}"
			if grep -q "^$(printf '%s\n' "${conf_var}"|sed 's/[.[\*^$]/\\&/g')=" "${script_path}"/control/server.conf
			then
				### IF OLD CONFIG LINES STILL EXISTS IN NEW CONFIG.CONF ####
				print_message "[${script_name}][INFO] Configure var \$${conf_var} in server.conf..."
				conf_line=$(grep "^${conf_var}" "${script_path}"/control/server.conf)
				if [ ! "${conf_line:-}" = "${conf_var}=${conf_var_val}" ]
				then
					sed "s#${conf_line}#${conf_var}=${conf_var_val}#g" "${script_path}"/control/server.conf >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/control/server.conf || rt_query=1
				fi
				print_message
			else
				### IF OLD CONFIG LINE IS CMD_ VARIABLE ####################
				if echo "${conf_var}"|grep -q "^cmd_"
				then
					printf "%s\n" "${config_line}" >>"${script_path}"/control/server.conf
				fi
			fi
		fi
	done
fi

#############################################
### TARGET ENVIRONMENT SPECIFIC TASKS #######
#############################################

### TERMUX ##################################
if [ "${error_counter}" -eq 0 ] && echo "${cmd_env}"|grep -qF -- "termux"
then
	termux-fix-shebang "${script_path}"/*.sh
fi

### DISPLAY OUTPUT #######################
print_message "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})\n"
