#!/bin/sh

### SET VARIABLES ############
script_path=$(dirname $(readlink -f "${0}"))
script_name=$(basename "$0")
specific_env=$1
specific_env=$(echo "${specific_env}"|tr '[A-Z]' '[a-z]')
specific_user=$2
error_detected=0

### CHECK DEPENDENCIES #######
while read program
do
	### CONSIDER PACKAGE != COMMAND #####
	if [ "${program}" = "ucspi-tcp-ipv6" ]
	then
		program="tcpserver"
	fi
	### CHECK IF PROGRAMM IS UNKNOWN ####
        type "$program" >/dev/null 2>/dev/null
        rt_query=$?
        if [ "$rt_query" -gt 0 ]
        then
        	### CONSIDER PACKAGE != COMMAND #####
		if [ "${program}" = "tcpserver" ]
		then
			program="ucspi-tcp-ipv6"
		fi
		### WRITE DEPENDENCY TO FILE ########
        	echo "${program}"  >>"${script_path}"/server_install_dep.tmp
        fi
done <"${script_path}"/control/server_install.dep
if [ -f "${script_path}"/server_install_dep.tmp ] && [ -s "${script_path}"/server_install_dep.tmp ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case "$specific_env" in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				if [ -x "$(command -v apk)" ]
				then
					pkg_mngr="apk";
				else
					if [ -x "$(command -v apt-get)" ]
					then
						pkg_mngr="apt-get";
					else
						if [ -x "$(command -v dnf)" ]
						then
							pkg_mngr="dnf";
						else
							if [ -x "$(command -v pacman)" ]
							then
								pkg_mngr="pacman";
							else
								if [ -x "$(command -v pkg)" ]
								then
									pkg_mngr="pkg";
								else
									if [ -x "$(command -v yum)" ]
									then
										pkg_mngr="yum";
									else
										if [ -x "$(command -v zypper)" ]
										then
											pkg_mngr="zypper";
										else
											###IF PACKAGING MANAGER DETECTION FAILED####
											error_detected=1
											no_of_programs=$(wc -l <"${script_path}"/install_dep.tmp)
											printf "%b" "[ ERROR ] Couldn't detect the package management system used on this machine!\n"
											printf "%b" "[ ERROR ] Found ${no_of_programs} programs that need to be installed:\n"
											cat "${script_path}"/server_install_dep.tmp
											printf "%b" "[ ERROR ] Install these programms first using your package management system and then run install.sh again.\n"
											############################################
										fi
									fi
								fi
							fi
						fi
					fi
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ "$error_detected" -eq 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read program
		do
			tried_all=0
			while [ "$tried_all" -eq 0 ]
			do
				printf "%b" "[ INFO ] Trying to install ${program} using ${pkg_mngr}...\n"
				case "$pkg_mngr" in
					"apk")		apk add $program ;;
					"apt-get")	apt-get -y install $program ;;
					"dnf")		dnf -y install $program ;;
					"pacman")	pacman --noconfirm -S $program ;;
					"pkg")		pkg install -y $program ;;
					"yum")		yum -y install $program ;;
					"zypper")	zypper -n install $program ;;
				esac
				rt_query=$?
				if [ "$rt_query" -ne 0 ]
				then
					printf "%b" "[ ERROR ] Error running the following command: ${pkg_mngr} install ${program}\n"
					printf "%b" "[ ERROR ] Maybe the program ${program} is available in a package with different name\n"
					if [ "$program" = "ucspi-tcp-ipv6" ]
					then
						new_program="ucspi-tcp6"
						printf "%b" "[ INFO ] Trying package name ${new_program} instead of ${program}\n"
						program=$new_program
					else
						printf "%b" "[ ERROR ] Could not install program: ${program}\n"
						error_detected=1
						tried_all=1
					fi
				else
					tried_all=1
				fi
			done
		done <"${script_path}"/server_install_dep.tmp
		############################
	fi
fi
###REMOVE TMP FILE##########
rm "${script_path}"/server_install_dep.tmp 2>/dev/null
#############################################
### TARGET ENVIRONMENT SPECIFIC TASKS #######
#############################################

### TERMUX ##################################
is_termux=$(echo "${specific_env}"|grep -c "termux")
if [ "${is_termux}" = 1 ] && [ "$error_detected" -eq 0 ]
then
	termux-fix-shebang "${script_path}"/*.sh
fi

### DISPLAY OUTPUT #######################
error_text="with errors"
if [ "$error_detected" -eq 0 ]
then
	error_text="without errors"
fi
printf "%b" "[ INFO ] $script_name finished $error_text. exiting...\n"
