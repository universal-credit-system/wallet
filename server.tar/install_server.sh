#!/bin/sh

### SET VARIABLES ############
script_path=$(dirname "$(readlink -f "${0}")")
script_name=$(basename "${0}")
specific_env=$1
specific_env=$(echo "${specific_env}"|tr 'A-Z' 'a-z')
error_counter=0

### CHECK DEPENDENCIES #######
while read program
do
	### CONSIDER PACKAGE != COMMAND #####
	if [ "${program}" = "ucspi-tcp-ipv6" ]
	then
		program="tcpserver"
	fi
	### CHECK IF PROGRAMM IS UNKNOWN ####
        type "${program}" >/dev/null 2>/dev/null
        rt_query=$?
        if [ "$rt_query" -gt 0 ]
        then
        	### CONSIDER PACKAGE != COMMAND #####
		if [ "${program}" = "tcpserver" ]
		then
			program="ucspi-tcp-ipv6"
		fi
		### WRITE DEPENDENCY TO FILE ########
        	echo "${program}"  >>"${script_path}"/server_install_dep.tmp
        fi
done <"${script_path}"/control/server_install.dep
if [ -f "${script_path}"/server_install_dep.tmp ] && [ -s "${script_path}"/server_install_dep.tmp ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case "$specific_env" in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				for pmgr in apk apt-get dnf pacman pkg yum zipper
				do
					if [ -x "$(command -v "${pmgr}")" ]
					then
						pkg_mngr="${pmgr}";
					fi
				done
				if [ -z "${pkg_mngr}" ]
				then
					###IF PACKAGING MANAGER DETECTION FAILED####
					error_counter=1
					no_of_programs=$(wc -l <"${install_dep}")
					printf "%s\n" "[${script_name}][ERROR][package] Couldn't detect the package management system used on this machine!"
					printf "%s\n" "[${script_name}][ERROR][package] Found ${no_of_programs} programs that need to be installed:"
					awk -v script_name="${script_name}" '{print "[" script_name "][ERROR][package] -> " $1}' "${install_dep}"
					printf "%s\n" "[${script_name}][ERROR][package] Install these programms first using your package management system and then run ${script_name} again."
					############################################
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ "${error_counter}" -eq 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read program
		do
			tried_all=0
			while [ "${tried_all}" -eq 0 ]
			do
				printf "%b" "[ INFO ] Trying to install ${program} using ${pkg_mngr}...\n"
				case "${pkg_mngr}" in
					"apk")		apk add "${program}" ;;
					"apt-get")	apt-get -y install "${program}" ;;
					"dnf")		dnf -y install "${program}" ;;
					"pacman")	pacman --noconfirm -S "${program}" ;;
					"pkg")		pkg install -y "${program}" ;;
					"yum")		yum -y install "${program}" ;;
					"zypper")	zypper -n install "${program}" ;;
				esac
				rt_query=$?
				if [ "$rt_query" -ne 0 ]
				then
					printf "%s\n" "[${script_name}][ERROR] Error running the following command: ${pkg_mngr} install ${program}"
					printf "%s\n" "[${script_name}][ERROR] Maybe the program ${program} is available in a package with different name"
					if [ "${program}" = "ucspi-tcp-ipv6" ]
					then
						new_program="ucspi-tcp6"
						printf "%s\n" "[${script_name}][INFO] Trying package name ${new_program} instead of ${program}"
						program=$new_program
					else
						printf "%s\n" "[${script_name}][ERROR] Could not install program: ${program}"
						error_counter=$(( error_counter + 1 ))
						tried_all=1
					fi
				else
					tried_all=1
				fi
			done
		done <"${script_path}"/server_install_dep.tmp
		############################
	fi
fi
###REMOVE TMP FILE##########
rm -f -- "${script_path}"/server_install_dep.tmp

#############################################
### TARGET ENVIRONMENT SPECIFIC TASKS #######
#############################################

### TERMUX ##################################
if [ "${error_counter}" -eq 0 ] && echo "${specific_env}"|grep -qF -- "termux"
then
	termux-fix-shebang "${script_path}"/*.sh
fi

### DISPLAY OUTPUT #######################
printf "%b" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})\n"
