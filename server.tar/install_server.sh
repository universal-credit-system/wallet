#!/bin/sh

### GET PATH #################
script_path=$(dirname $(readlink -f "${0}"))

### GET ENVIRONMENT###########
specific_env=$1
specific_env=$(echo "${specific_env}"|tr '[A-Z]' '[a-z]')

### USER TO INSTALL FOR#######
specific_user=$2

### SET VARIABLES ############
error_detected=0

### CHECK DEPENDENCIES #######
while read program
do
	### CONSIDER PACKAGE != COMMAND #####
	if [ "${program}" = "ucspi-tcp-ipv6" ]
	then
		program="tcpserver"
	fi
	### CHECK IF PROGRAMM IS UNKNOWN ####
        type "$program" >/dev/null 2>/dev/null
        rt_query=$?
        if [ $rt_query -gt 0 ]
        then
        	### CONSIDER PACKAGE != COMMAND #####
		if [ "${program}" = "tcpserver" ]
		then
			program="ucspi-tcp-ipv6"
		fi
		### WRITE DEPENDENCY TO FILE ########
        	echo "${program}"  >>"${script_path}"/server_install_dep.tmp
        fi
done <"${script_path}"/control/server_install.dep
if [ -f ${script_path}/server_install_dep.tmp ] && [ -s ${script_path}/server_install_dep.tmp ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case $specific_env in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				if [ -x "$(command -v apk)" ]
				then
					pkg_mngr="apk";
				else
					if [ -x "$(command -v apt-get)" ]
					then
						pkg_mngr="apt-get";
					else
						if [ -x "$(command -v dnf)" ]
						then
							pkg_mngr="dnf";
						else
							if [ -x "$(command -v pacman)" ]
							then
								pkg_mngr="pacman";
							else
								if [ -x "$(command -v pkg)" ]
								then
									pkg_mngr="pkg";
								else
									if [ -x "$(command -v yum)" ]
									then
										pkg_mngr="yum";
									else
										if [ -x "$(command -v zypper)" ]
										then
											pkg_mngr="zypper";
										else
											###IF PACKAGING MANAGER DETECTION FAILED####
											error_detected=1
											no_of_programs=$(wc -l <${script_path}/install_dep.tmp)
											printf "%b" "ERROR: Couldn't detect the package management system used on this machine!\n"
											printf "%b" "INFO:  Found ${no_of_programs} programs that need to be installed:\n"
											cat ${script_path}/server_install_dep.tmp
											printf "%b" "INFO:  Install these programms first using your package management system and then run install.sh again.\n"
											############################################
										fi
									fi
								fi
							fi
						fi
					fi
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ $error_detected = 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read line
		do
			tried_all=0
			while [ $tried_all = 0 ]
			do
				printf "%b" "INFO: Trying to install ${line} using ${pkg_mngr}...\n"
				case $pkg_mngr in
					"apk")		apk add $line ;;
					"apt-get")	apt-get -y install $line ;;
					"dnf")		dnf -y install $line ;;
					"pacman")	pacman --noconfirm -S $line ;;
					"pkg")		pkg install -y $line ;;
					"yum")		yum -y install $line ;;
					"zypper")	zypper -n install $line ;;
				esac
				rt_query=$?
				if [ ! $rt_query = 0 ]
				then
					printf "%b" "ERROR: Error running the following command: ${pkg_mngr} install ${line}\n"
					printf "%b" "INFO:  Maybe the program ${line} is available in a package with different name\n"
					if [ "$line" = "ucspi-tcp-ipv6" ]
					then
						new_line="ucspi-tcp6"
						printf "%b" "INFO:  Trying package name ${new_line} instead of ${line}\n"
						line=$new_line
					else
						printf "%b" "ERROR: Could not install program: ${line}\n"
						error_detected=1
						tried_all=1
					fi
				else
					tried_all=1
				fi
			done
		done <${script_path}/server_install_dep.tmp
		############################
	fi
fi
###REMOVE TMP FILE##########
rm ${script_path}/server_install_dep.tmp 2>/dev/null
#############################################
### TARGET ENVIRONMENT SPECIFIC TASKS #######
#############################################

### TERMUX ##################################
is_termux=$(echo "${specific_env}"|grep -c "termux")
if [ "${is_termux}" = 1 ] && [ $error_detected = 0 ]
then
	termux-fix-shebang "${script_path}"/*.sh
fi
#############################################
printf "%b" "INFO: exiting install_server.sh...\n"
