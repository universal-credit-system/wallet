#!/bin/sh
###CET CURRENT PATH####
script_path=$(dirname $(readlink -f ${0}))

###SWITCH TO PATH######
cd ${script_path}/

###CHECK FOR FILES#####
while [ 1 -lt 2 ]
do
	###DELETE FILES#########################
	find . -type f -size +10M -delete

	###WAIT#################################
	sleep 30
done
