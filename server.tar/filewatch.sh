#!/bin/sh

###CET CURRENT PATH####
script_path=$(dirname $(readlink -f ${0}))

###SWITCH TO PATH######
cd ${script_path}/

###DEFINE FIND CMD#####
trx_smaller_bigger="+"
trx_max_size=10
trx_max_type="M"

###WAITING PERIOD######
wait_period=30

###STEP INTO SERVER DIR
cd ${script_path}/server

###CHECK FOR FILES#####
while [ 1 -lt 2 ]
do

	###DELETE FILES#########################
	find . -type f -size ${trx_smaller_bigger}${trx_max_size}${trx_max_type} -iname ".dat.tmp" -delete

	###DELET OLD KEY FILES OF DIFFIE-HELLMAN
	find . -maxdepth 1 -type f -mmin +5 -iname "*.key" -delete

	###WAIT#################################
	sleep $wait_period
done
