#!/bin/sh

### GET PID #############
controller_pid=$1

### GET CURRENT PATH ####
script_path=$(cd "$(dirname "$0")" || exit 1; pwd)

### SET DEFAULT VALUES ##
filewatch_trx_smaller_bigger="+"
filewatch_trx_max_size=10
filewatch_trx_max_type="M"
filewatch_file_description="${filewatch_trx_smaller_bigger}${filewatch_trx_max_size}${filewatch_trx_max_type}"
filewatch_interval_seconds=30

### SOURCE CONFIG FILE ##
. "${script_path}"/control/server.conf

### CHECK FOR FILES #####
while kill -0 "${controller_pid}" 2>/dev/null && ps -p "${controller_pid}" -o args=|grep -q "controller.sh"
do
	### DELETE FILES BIGGER THAN ####
	find "${script_path}"/server/ -maxdepth 1 -type f -name '*.tmp' -o -name '*.dat' -o -name '*.sync' -size "${filewatch_file_description}" -delete

	### DELETE OLD FILES ############
	find "${script_path}"/server/ -maxdepth 1 -type f -name '*.tmp' -o -name '*.dat' -o -name '*.sync' -mmin +5 -delete

	### WAIT ########################
	sleep "${filewatch_interval_seconds}"
done

