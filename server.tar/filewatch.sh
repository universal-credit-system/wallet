#!/bin/sh

### GET PIDS ############
controller_pid=$1

### GET CURRENT PATH ####
script_path=$(dirname $(readlink -f ${0}))

### SOURCE CONFIG FILE ##
. ${script_path}/control/server.conf

### CHECK PIDS ##########
ps --pid $controller_pid >/dev/null
controller_running=$?

### CHECK FOR FILES #####
while [ $controller_running = 0 ]
do
	### DELETE FILES ################
	find ${script_path}/server/ -maxdepth 1 -type f -size ${filewatch_file_description} -iname ".dat.tmp" -delete

	### DELETE OLD KEY FILES OF D-H #
	find ${script_path}/server/ -maxdepth 1 -type f -mmin +5 -iname "*.key" -delete

	### WAIT ########################
	sleep $filewatch_interval_seconds

	### CHECK PIDS ##################
	ps --pid $controller_pid >/dev/null
	controller_running=$?
done
