#!/bin/sh

###CET CURRENT PATH####
script_path=$(dirname $(readlink -f ${0}))

###DEFINE FIND CMD#####
trx_smaller_bigger="+"
trx_max_size=10
trx_max_type="M"

###WAITING PERIOD######
wait_period=30

###CHECK FOR FILES#####
while [ 1 -lt 2 ]
do

	###DELETE FILES#########################
	find ${script_path}/server/ -maxdepth 1 -type f -size ${trx_smaller_bigger}${trx_max_size}${trx_max_type} -iname ".dat.tmp" -delete

	###DELET OLD KEY FILES OF DIFFIE-HELLMAN
	find ${script_path}/server/ -maxdepth 1 -type f -mmin +5 -iname "*.key" -delete

	###WAIT#################################
	sleep $wait_period
done
