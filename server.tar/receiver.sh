#!/bin/sh

###GET USERDATA############################
controller_pid=$1
user_name=$2
user_pin=$3
user_pw=$4

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###GET CURRENT PID#########################
session_pid=$$

###CHECK IF SERVER IS STILL RUNNING########
ps --pid $controller_pid >/dev/null
controller_running=$?

if [ $controller_running = 0 ]
then
	###WRITE ENTRY TO LOGFILE##################
	receiver_date=`date -u`
	echo "${receiver_date}: $TCPREMOTEIP $TCPREMOTEPORT sent data" >>${script_path}/log/receiver.log

	###SET PATHS###############################
	syncfile_staged="${script_path}/server/server_syncfile_staged.sync"
	syncfile_temp="${script_path}/server/server_syncfile_temp.sync"

	###SET AES256 SESSION KEY##################
	session_key=`date -u +%Y%m%d`

	###ACCEPT CONNECTION AND WRITE TO FILE#####
	cat - >${script_path}/server/transaction_${session_pid}.dat.tmp

	###CALCULATE SHARED-SECRET#################
	###CHECK IF FILE IS GREATER THAN 0#########
	if [ -s ${script_path}/server/transaction_${session_pid}.dat.tmp ]
	then
		###TRY TO DECRYPT HEADER#######################
		head -6 ${script_path}/server/transaction_${session_pid}.dat.tmp|gpg --batch --no-tty --output ${script_path}/server/transaction_${session_pid}_header.dat --passphrase ${session_key} --decrypt - 2>/dev/null
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			###SET $SAVE_FILE VARIABLE TO STORE KEY####
			usera_session_id=`head -1 ${script_path}/server/transaction_${session_pid}_header.dat`
			session_id_token=`echo "${usera_session_id}"|sha224sum|cut -d ' ' -f1`
			save_file="${script_path}/server/${session_id_token}.key"

			###CHECK IF SAVE-FILE IS THERE#################
			if [ -s  ${save_file} ]
			then
				###GET SSECRET FROM SAVE-FILE######################
				ssecret=`cat ${save_file}`
				ssecret=$(( $ssecret + $ssecret ))
				hssecret=`echo "${ssecret}_${session_key}"|sha256sum|cut -d ' ' -f1`

				###GET SIZE OF HEADER AND BODY#####################
				total_bytes_received=`wc -c <${script_path}/server/transaction_${session_pid}.dat.tmp`
				total_bytes_header=`head -6 ${script_path}/server/transaction_${session_pid}.dat.tmp|wc -c`
				total_bytes_count=$(( $total_bytes_received - $total_bytes_header ))

				###CUT OUT BODY AND MOVE FILE######################
				dd skip=${total_bytes_header} count=${total_bytes_count} if=${script_path}/server/transaction_${session_pid}.dat.tmp of=${script_path}/server/transaction_${session_pid}.dat bs=1 2>/dev/null
				mv ${script_path}/server/transaction_${session_pid}.dat ${script_path}/server/transaction_${session_pid}.dat.tmp

				###DECRYPT#########################################
				gpg --batch --no-tty --pinentry-mode loopback --output ${script_path}/server/transaction_${session_pid}.dat --passphrase ${hssecret} --decrypt ${script_path}/server/transaction_${session_pid}.dat.tmp 2>/dev/null
				rt_query=$?
				if [ $rt_query = 0 ]
				then
					###CHEEK IF FILE IS A TAR-FILE#########################
					tar -tf ${script_path}/server/transaction_${session_pid}.dat >/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						###CALL OF UCS CLIENT TO READ######################
						flock ${script_path}/ucs_client.sh ${script_path}/ucs_client.sh -action read_sync -user ${user_name} -pin ${user_pin} -password "${user_pw}" -type partial -path ${script_path}/server/transaction_${session_pid}.dat >/dev/null 2>&1

						###BUILD SYNC FILE#################################
						if [ ! -s ${syncfile_staged} ]
						then
							flock ${script_path}/keys tar -czf ${syncfile_staged} keys/ proofs/ trx/ --dereference --hard-dereference
						else
							flock ${script_path}/keys tar -czf ${syncfile_temp} keys/ proofs/ trx/ --dereference --hard-dereference
							syncfile_old_hash=`tar -tf ${syncfile_staged}|sha256sum|cut -d ' ' -f1`
							syncfile_new_hash=`tar -tf ${syncfile_temp}|sha256sum|cut -d ' ' -f1`
							if [ ! "${syncfile_old_hash}" = "${syncfile_new_hash}" ]
							then
								flock ${syncfile_staged} mv ${syncfile_temp} ${syncfile_staged}
							else
								rm ${syncfile_temp}
							fi
						fi
					fi
				fi
				rm ${save_file}
			fi
		fi
		###REMOVE TEMP FILE#############################
		rm ${script_path}/server/transaction_${session_pid}_header.dat 2>/dev/null
	fi
	###REMOVE DATA AFTER PROCESSING############
	rm ${script_path}/server/transaction_${session_pid}.dat 2>/dev/null
	rm ${script_path}/server/transaction_${session_pid}.dat.tmp 2>/dev/null
else
	parent_pid=`ps --ppid ${session_pid}|tail -1|awk '{print $1}'`
	kill ${parent_pid}
fi
