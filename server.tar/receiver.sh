#!/bin/sh -xv

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###GET CURRENT PID#########################
session_pid=$$

###SET LOGPAH AND DEFINE LOGFILE###########
receiver_log="${script_path}/log/receiver.log"
receiver_date=`date -u`
receiver_log_max_lines=10000
if [ -s ${receiver_log} ]
then
	receiver_log_curr_lines=`cat ${receiver_log}|wc -l`
else
	receiver_log_curr_lines=0
fi

###CHECK IF LOG>MAX_LINES##################
if [ $receiver_log_curr_lines -eq $receiver_log_max_lines ]
then
	rm ${receiver_log}
fi

###WRITE ENTRY TO LOGFILE##################
echo "${receiver_date}: $TCPREMOTEIP $TCPREMOTEPORT sent data" >>${receiver_log}

###SET PATHS###############################
syncfile_staged="${script_path}/server/server_syncfile_staged.sync"
syncfile_temp="${script_path}/server/server_syncfile_temp.sync"

###SET SAVE FILE TO STORE KEY##############
ip_token=`echo $TCPREMOTEIP|sha224sum|cut -d ' ' -f1`
save_file="${script_path}/server/${ip_token}.key"

###SET AES256 SESSION KEY##################
session_key=`date -u +%Y%m%d`

###ACCEPT CONNECTION AND WRITE TO FILE#####
cat - >${script_path}/server/transaction_${session_pid}.dat.tmp

###CALCULATE SHARED-SECRET#################
###CHECK IF FILE IS GREATER THAN 0#########
if [ -s ${script_path}/server/transaction_${session_pid}.dat.tmp ]
then
	###CHECK IF SAVE-FILE IS THERE#############
	if [ -s  ${save_file} ]
	then
		###GET SSECRET FROM SAVE-FILE##############
		ssecret=`cat ${save_file}`
		ssecret=$(( $ssecret + $ssecret ))
		hssecret=`echo "${ssecret}_${session_key}"|sha256sum|cut -d ' ' -f1`

		###DECRYPT#################################
		gpg --batch --no-tty --pinentry-mode loopback --output ${script_path}/server/transaction_${session_pid}.dat --passphrase ${hssecret} --decrypt ${script_path}/server/transaction_${session_pid}.dat.tmp
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			###CHEEK IF FILE IS A TAR-FILE#############
			tar -tf ${script_path}/server/transaction_${session_pid}.dat >/dev/null
			rt_query=$?
			if [ $rt_query = 0 ]
			then
				###CALL OF UCS CLIENT TO READ##############
				flock ${script_path}/ucs_client.sh ${script_path}/ucs_client.sh -action read_sync -user testkonto1 -pin 62268 -password testpw -type partial -path ${script_path}/server/transaction_${session_pid}.dat

				###BUILD SYNC FILE#########################
				if [ ! -s ${syncfile_staged} ]
				then
					flock ${script_path}/keys tar -czf ${syncfile_staged} keys/ proofs/ trx/ --dereference --hard-dereference
				else
					flock ${script_path}/keys tar -czf ${syncfile_temp} keys/ proofs/ trx/ --dereference --hard-dereference
					syncfile_old_hash=`tar -tf ${syncfile_staged}|sha256sum|cut -d ' ' -f1`
					syncfile_new_hash=`tar -tf ${syncfile_temp}|sha256sum|cut -d ' ' -f1`
					if [ ! "${syncfile_old_hash}" = "${syncfile_new_hash}" ]
					then
						flock ${syncfile_staged} mv ${syncfile_temp} ${syncfile_staged}
					else
						rm ${syncfile_temp}
					fi
				fi
			fi
		fi
		rm ${save_file}
	fi
fi
###REMOVE DATA AFTER PROCESSING############
rm ${script_path}/server/transaction_${session_pid}.dat 2>/dev/null
rm ${script_path}/server/transaction_${session_pid}.dat.tmp 2>/dev/null
