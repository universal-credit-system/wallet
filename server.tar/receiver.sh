#!/bin/sh

### GET CONTROLLER.SH PID ###################
controller_pid=$1

### GET CURRENT PID #########################
session_pid=$$

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### GET UNIQUE ID ###########################
unique_id=$(basename "$(mktemp XXXXXXXXXXXXXXXX -p ${script_path}/server/)")

### SOURCE CONFIG ###########################
. ${script_path}/control/server.conf

### CHECK IF SERVER IS STILL RUNNING ########
ps --pid $controller_pid >/dev/null
controller_running=$?
if [ $controller_running = 0 ]
then
	### SET RT_QUERY ############################
	rt_query=0

	### SET AES256 SESSION KEY ##################
	session_key=$(date -u +%Y%m%d)

	### SET FILE PATHS ##########################
	user_path="${script_path}/userdata/${user_account}"
	out_file="${script_path}/server/transaction_${unique_id}.dat.tmp"

	### WRITE ENTRY TO LOGFILE ##################
	echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT connected" >>${script_path}/log/receiver.log

	### ACCEPT CONNECTION AND WRITE TO FILE #####
	#cat - >${out_file}
	timeout $connect_read_timeout dd bs=1 status=none >${out_file} || rt_query=1

	### CHECK IF ANY DATA WAS SENT ##############
	if [ -s ${out_file} ] && [ $rt_query = 0 ]
	then
		### GET SIZE OF HEADER AND BODY #############
		total_lines_header=$(grep -n "END PGP MESSAGE" ${out_file}|head -1|cut -d ':' -f1)
		total_bytes_received=$(wc -c <${out_file})
		total_bytes_header=$(head -$total_lines_header ${out_file}|wc -c)
		total_bytes_count=$(( total_bytes_received - total_bytes_header ))

		### DECRYPT RECEIVED CLIENT INFO ############
		head -$total_lines_header ${out_file} >${script_path}/server/dhuser_${unique_id}.dat.tmp
		echo "${session_key}"|gpg --batch --no-tty --pinentry-mode loopback --output ${script_path}/server/dhuser_${unique_id}.dat --passphrase-fd 0 --decrypt ${script_path}/server/dhuser_${unique_id}.dat.tmp 2>/dev/null
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			### HASH CLIENT INFO ########################
			user_requesting=$(cat ${script_path}/server/dhuser_${unique_id}.dat)
			user_requesting_hash=$(sha224sum <${script_path}/server/dhuser_${unique_id}.dat)
			user_requesting_hash=${user_requesting_hash%% *}

			### CHECK IF SECRET EXISTS ##################
			if [ -s ${script_path}/server/dhsecret_${user_requesting_hash}.dat ]
			then
				### EXTRACT SECRET ##########################
				shared_secret=$(sha224sum <${script_path}/server/dhsecret_${user_requesting_hash}.dat)
				shared_secret=${shared_secret%% *}

				### CUT OUT BODY AND MOVE FILE ##############
				dd skip=${total_bytes_header} count=${total_bytes_count} bs=1 status=none if=${script_path}/server/transaction_${unique_id}.dat.tmp of=${script_path}/server/transaction_${unique_id}.dat
				mv ${script_path}/server/transaction_${unique_id}.dat ${script_path}/server/transaction_${unique_id}.dat.tmp

				### DECRYPT BODY ############################
				echo "${shared_secret}"|gpg --batch --no-tty --pinentry-mode loopback --output ${script_path}/server/transaction_${unique_id}.dat --passphrase-fd 0 --decrypt ${script_path}/server/transaction_${unique_id}.dat.tmp 2>/dev/null
				rt_query=$?
				if [ $rt_query = 0 ]
				then
					### CHECK IF FILE IS A TAR-FILE #############
					tar -tf ${script_path}/server/transaction_${unique_id}.dat >/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### TRIGGER UCS_CLIENT.SH ###################
						flock ${script_path}/ucs_client.sh echo "-action read_sync -sender ${user_account} -password ${user_pw} -type partial -path ${script_path}/server/transaction_${unique_id}.dat"|${script_path}/ucs_client.sh >/dev/null 2>&1

						### WRITE ENTRY TO LOGFILE ##################
						echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT successfully linked" >>${script_path}/log/receiver.log
					else
						### WRITE ENTRY TO LOGFILE ##################
						echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT data check failed" >>${script_path}/log/receiver.log
					fi
				else
					### WRITE ENTRY TO LOGFILE ##########################
					echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT could not decrypt body" >>${script_path}/log/receiver.log
				fi
			else
				### WRITE ENTRY TO LOGFILE ##########################
				echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT could not find secret" >>${script_path}/log/receiver.log
			fi
			rm ${script_path}/server/dhsecret_${user_requesting_hash}.dat 2>/dev/null
		else
			### WRITE ENTRY TO LOGFILE ##########################
			echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT could not decrypt username" >>${script_path}/log/receiver.log
		fi
		rm ${script_path}/server/dhuser_${unique_id}.* 2>/dev/null
	else
		### WRITE ENTRY TO LOGFILE ##################
		echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT sent empty message" >>${script_path}/log/receiver.log
	fi
	rm ${script_path}/server/transaction_${unique_id}.* 2>/dev/null
else
	parent_pid=$(ps --ppid ${session_pid}|tail -1|awk '{print $1}')
	kill ${parent_pid}
fi
### CLEAN UP ################################
rm ${script_path}/server/${unique_id} 2>/dev/null
