#!/bin/sh

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###GET CURRENT PID#########################
session_pid=$$

###SET LOGPAH AND DEFINE LOGFILE###########
receiver_log="${script_path}/receiver.log"
receiver_date=`date -u`
receiver_log_max_lines=10000
receiver_log_curr_lines=`cat ${receiver_log}|wc -l`

###CHECK IF LOG>MAX_LINES##################
if [ $receiver_log_curr_lines -eq $receiver_log_max_lines ]
then
	rm ${receiver_log}
fi

###WRITE ENTRY TO LOGFILE##################
echo "$TCPREMOTEIP:$TCPREMOTEPORT connected on ${receiver_date}" >>${receiver_log}

###SET AES256 SESSION KEY##################
session_key=`date -u +%Y%m%d`

###ACCEPT CONNECTION AND WRITE TO FILE#####
cat - |gpg --batch --pinentry-mode loopback --output - --passphrase ${session_key} --decrypt - >>${script_path}/transaction_${session_pid}.dat

###CALL OF UCS CLIENT TO READ##############
flock ${script_path}/ ${script_path}/ucs_client.sh -action read_sync -user testkonto1 -pin 62268 -password testpw -type partial -path ${script_path}/transaction_${session_pid}.dat 2>debug_client.log

###REMOVE DATA AFTER PROCESSING############
rm ${script_path}/transaction_${session_pid}.dat 2>/dev/null
