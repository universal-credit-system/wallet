#!/bin/sh
cleanup() {
			### TO THROUGH LIST AND DELETE #####
			oldIFS=$IFS
			IFS='|'
			for file in ${cleanup_file_list}
			do
				rm -f -- "${file}"
			done
			IFS=${oldIFS}
}
log_message(){
			message_log=$1
			### WRITE OUTPUT ###################
			echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT ${message_log}" >>"${script_path}"/log/receiver.log
}
register_cleanup(){
			### ADD TO LIST ####################
			for file in "$@"
			do
				cleanup_file_list="${cleanup_file_list}|${file}"
			done
}
### PRIVILEDGED MODE ########################
umask 077
set -f

### SET TRAP ################################
cleanup_file_list=""
trap cleanup INT TERM EXIT

### GET CONTROLLER.SH PID ###################
controller_pid=$1

### GET CURRENT PID #########################
session_pid=$$

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(cd "$(dirname "$0")" || exit 1; pwd)

### SOURCE CONFIG ###########################
. "${script_path}"/control/server.conf

### CALCULATE MAX BYTE SIZE OF FILE #########
multi=0
case "$filewatch_trx_max_type" in
	"kB")	multi=1000
		;;
	"K")	multi=1000
		;;
	"KB")	multi=1000
		;;
	"Ki")	multi=1024
		;;
	"KiB")	multi=1024
		;;
	"M")	multi=1000000
		;;
	"MB")	multi=1000000
		;;
	"Mi")	multi=1048576
		;;
	"MiB")	multi=1048576
		;;
	"GB")	multi=1000000000
		;;
	"G")	multi=1073741824
		;;
	"GiB")	multi=1073741824
		;;
	*)	### WRITE ENTRY TO LOGFILE ##########################
		log_message "bad variable definition of filewatch_trx_max_type in control/server.conf. exiting"
		exit 1
		;;
esac

### CHECK IF SIZE SET CORRECTLY #############
file_max_size_bytes=$(( filewatch_trx_max_size * multi ))
if [ "${file_max_size_bytes}" -eq 0 ]
then
	### WRITE ENTRY TO LOGFILE ##########################
	log_message "bad variable definition of filewatch_trx_max_size in control/server.conf. exiting"
	exit 1
fi

### CHECK IF SERVER IS STILL RUNNING ########
if kill -0 "${controller_pid}" 2>/dev/null && ps -p "${controller_pid}" -o args=|grep -q "controller.sh"
then
	### SET RT_QUERY ############################
	rt_query=0

	### SET AES256 SESSION KEY ##################
	session_key=$(date -u +%Y%m%d)

	### GET UNIQUE ID ###########################
	unique_id=$(basename "$(mktemp XXXXXXXXXXXXXXXX -p "${script_path}"/server/)")

	### ADD ID-FILE TO TRAP #####################
	register_cleanup "${script_path}/server/${unique_id}"

	### SET FILE PATHS ##########################
	user_path="${script_path}/userdata/${user_account}"
	out_file="${script_path}/server/transaction_${unique_id}.dat.tmp"

	### WRITE ENTRY TO LOGFILE ##################
	log_message "connected"

	### ACCEPT CONNECTION AND WRITE TO FILE #####
	#cat - >${out_file}
	timeout "${connect_read_timeout}" dd bs=1 count="${file_max_size_bytes}" status=none >"${out_file}"
	rt_query=$?

	### ADD OUTFILE TO TRAP #####################
	register_cleanup "${out_file}"

	### CHECK IF ANY DATA WAS SENT ##############
	if [ -s "${out_file}" ] && [ "${rt_query}" -eq 0 ]
	then
		### GET TOTAL SIZE ##########################
		total_bytes_received=$(wc -c <"${out_file}")
		if [ "${total_bytes_received}" -ne "${file_max_size_bytes}" ]
		then
			### GET SIZE OF HEADER AND BODY #############
			total_lines_header=$(grep -n "END PGP MESSAGE" "${out_file}"|head -1|cut -d ':' -f1)
			if [ -n "${total_lines_header:-}" ]
			then
				### CALCULATE HEADER SIZE####################
				total_bytes_header=$(head -${total_lines_header} "${out_file}"|wc -c)
				total_bytes_count=$(( total_bytes_received - total_bytes_header ))

				### EXTRACT RECEIVED CLIENT INFO ############
				head -"${total_lines_header}" "${out_file}" >"${script_path}/server/dhuser_${unique_id}.dat.tmp"
				
				### ADD HEADERFILE TO TRAP ##################
				register_cleanup "${script_path}/server/dhuser_${unique_id}.dat"
				register_cleanup "${script_path}/server/dhuser_${unique_id}.dat.tmp"
				
				### DECRYPT RECEIVED CLIENT INFO ############
				echo "${session_key}"|gpg --batch --no-tty --pinentry-mode loopback --output "${script_path}/server/dhuser_${unique_id}.dat" --passphrase-fd 0 --decrypt "${script_path}/server/dhuser_${unique_id}.dat.tmp" 2>/dev/null
				rt_query=$?
				if [ "${rt_query}" -eq 0 ]
				then
					### HASH CLIENT INFO ########################
					user_requesting=$(cat "${script_path}/server/dhuser_${unique_id}.dat")
					user_requesting_hash=$(sha224sum <"${script_path}/server/dhuser_${unique_id}.dat")
					user_requesting_hash=${user_requesting_hash%% *}

					### CHECK IF SECRET EXISTS ##################
					if [ -s "${script_path}/server/dhsecret_${user_requesting_hash}.dat" ]
					then
						### ADD SECRETFILE TO TRAP ##################
						register_cleanup "${script_path}/server/dhsecret_${user_requesting_hash}.dat"

						### EXTRACT SECRET ##########################
						shared_secret=$(sha224sum <"${script_path}/server/dhsecret_${user_requesting_hash}.dat")
						shared_secret=${shared_secret%% *}

						### CUT OUT BODY AND MOVE FILE ##############
						dd skip="${total_bytes_header}" count="${total_bytes_count}" bs=1 status=none if="${script_path}/server/transaction_${unique_id}.dat.tmp" of="${script_path}/server/transaction_${unique_id}.dat"
						mv "${script_path}/server/transaction_${unique_id}.dat" "${script_path}/server/transaction_${unique_id}.dat.tmp"
						
						### ADD FILE TO TRAP ########################
						register_cleanup "${script_path}/server/transaction_${unique_id}.dat"
						register_cleanup "${script_path}/server/transaction_${unique_id}.dat.tmp"
				
						### DECRYPT BODY ############################
						echo "${shared_secret}"|gpg --batch --no-tty --pinentry-mode loopback --output "${script_path}/server/transaction_${unique_id}.dat" --passphrase-fd 0 --decrypt "${script_path}/server/transaction_${unique_id}.dat.tmp" 2>/dev/null
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### CHECK IF FILE IS A TAR-FILE #############
							tar -tf "${script_path}/server/transaction_${unique_id}.dat" >"${script_path}/server/tarcheck_${unique_id}.dat"
							rt_query=$?
							
							### ADD FILE TO TRAP ########################
							register_cleanup "${script_path}/server/tarcheck_${unique_id}.dat"

							### CHECK RT_CODE AND RESULT OF PATH CHECK ##
							if [ "${rt_query}" -eq 0 ] && ! grep -E '(^/|(^|/)\.\.(/|$))' "${script_path}/server/tarcheck_${unique_id}.dat" >/dev/null
							then
								### TRIGGER UCS_CLIENT.SH ###################
								flock "${script_path}"/ucs_client.sh echo "-action read_sync -sender ${user_account} -password ${user_pw} -type partial -path ${script_path}/server/transaction_${unique_id}.dat"|"${script_path}"/ucs_client.sh >/dev/null 2>&1

								### WRITE ENTRY TO LOGFILE ##################
								log_message "successfully linked"
							else
								### WRITE ENTRY TO LOGFILE ##################
								log_message "data check failed"
							fi
						else
							### WRITE ENTRY TO LOGFILE ##########################
							log_message "could not decrypt body"
						fi
					else
						### WRITE ENTRY TO LOGFILE ##########################
						log_message "could not find secret"
					fi
				else
					### WRITE ENTRY TO LOGFILE ##########################
					log_message "could not decrypt username"
				fi
			else
				### WRITE ENTRY TO LOGFILE ##########################
				log_message "invalid protocol"
			fi
		else
			### WRITE ENTRY TO LOGFILE ##########################
			log_message "received file exceeds max file size"
		fi
	else
		if [ "${rt_query}" -eq 124 ]
		then
			### WRITE ENTRY TO LOGFILE ##################
			log_message "connection timed out"
		else
			### WRITE ENTRY TO LOGFILE ##################
			log_message "sent empty message"
		fi
	fi
else
	### WRITE ENTRY TO LOGFILE ##################
	log_message "controller not running"

	### CHECK IF PARENT PID IS STILL VALID ######
	if kill -0 "${PPID}" 2>/dev/null && ps -p "${PPID}" -o args=|grep -q "tcpserver"
	then
		### WRITE ENTRY TO LOGFILE ##################
		log_message "stopping receiver.sh listener"
	
		### STOP LISTENER (PARENT) ##################
		kill "${PPID}"
	fi
fi

