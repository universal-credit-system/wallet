#!/bin/sh

###GET USERDATA############################
controller_pid=$1
user_account=$2
user_pw=$3

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###GET CURRENT PID#########################
session_pid=$$

###CHECK IF SERVER IS STILL RUNNING########
ps --pid $controller_pid >/dev/null
controller_running=$?

if [ $controller_running = 0 ]
then
	###WRITE ENTRY TO LOGFILE##################
	echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT connected" >>${script_path}/log/receiver.log

	###SET AES256 SESSION KEY##################
	session_key=$(date -u +%Y%m%d)

	###ACCEPT CONNECTION AND WRITE TO FILE#####
	#cat - >${script_path}/server/transaction_${session_pid}.dat.tmp
	dd bs=1 status=none >${script_path}/server/transaction_${session_pid}.dat.tmp

	###CHECK IF ANY DATA WAS SENT##############
	if [ -s ${script_path}/server/transaction_${session_pid}.dat.tmp ]
	then
		###TRY TO DECRYPT FILE#####################
		head -6 ${script_path}/server/transaction_${session_pid}.dat.tmp|gpg --batch --no-tty --output ${script_path}/server/transaction_${session_pid}_header.dat --passphrase ${session_key} --decrypt - 2>/dev/null
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			###SET $SAVE_FILE VARIABLE TO STORE KEY####
			usera_session_id=$(head -1 ${script_path}/server/transaction_${session_pid}_header.dat)
			session_id_token=$(echo "${usera_session_id}"|sha224sum)
			session_id_token=${session_id_token%% *}
			save_file="${script_path}/server/${session_id_token}.key"

			###CHECK IF SAVE-FILE IS THERE#################
			if [ -s  ${save_file} ]
			then
				###GET SSECRET FROM SAVE-FILE######################
				ssecret=$(cat ${save_file})
				ssecret=$(( $ssecret + $ssecret ))
				hssecret=$(echo "${ssecret}_${session_key}"|sha256sum)
				hssecret=${hssecret%% *}

				###GET SIZE OF HEADER AND BODY#####################
				total_bytes_received=$(wc -c <${script_path}/server/transaction_${session_pid}.dat.tmp)
				total_bytes_header=$(head -6 ${script_path}/server/transaction_${session_pid}.dat.tmp|wc -c)
				total_bytes_count=$(( $total_bytes_received - $total_bytes_header ))

				###CUT OUT BODY AND MOVE FILE######################
				dd skip=${total_bytes_header} count=${total_bytes_count} bs=1 status=none if=${script_path}/server/transaction_${session_pid}.dat.tmp of=${script_path}/server/transaction_${session_pid}.dat
				mv ${script_path}/server/transaction_${session_pid}.dat ${script_path}/server/transaction_${session_pid}.dat.tmp

				###DECRYPT#########################################
				gpg --batch --no-tty --pinentry-mode loopback --output ${script_path}/server/transaction_${session_pid}.dat --passphrase ${hssecret} --decrypt ${script_path}/server/transaction_${session_pid}.dat.tmp 2>/dev/null
				rt_query=$?
				if [ $rt_query = 0 ]
				then
					###CHECK IF FILE IS A TAR-FILE#####################
					tar -tf ${script_path}/server/transaction_${session_pid}.dat >/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						###FLOCK WRAPPER###################################
						(
							###LOCK FD 200#####################################
							flock 200
							
							###CALL OF UCS CLIENT TO READ######################
							echo "-action read_sync -sender ${user_account} -password ${user_pw} -type partial -path ${script_path}/server/transaction_${session_pid}.dat"|${script_path}/ucs_client.sh >/dev/null 2>&1
						) 200>${script_path}/server/flock.file
						###################################################
						
						###WRITE ENTRY TO LOGFILE##################################
						echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT successfully linked" >>${script_path}/log/receiver.log
					else
						###WRITE ENTRY TO LOGFILE##################################
						echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT data check failed" >>${script_path}/log/receiver.log
					fi
				else
					###WRITE ENTRY TO LOGFILE##################################
					echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT could not decrypt data" >>${script_path}/log/receiver.log
				fi
				rm ${save_file}
			fi
		else
			###WRITE ENTRY TO LOGFILE##################
			echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT could not decrypt header" >>${script_path}/log/receiver.log
		fi
		###REMOVE TEMP FILE#############################
		rm ${script_path}/server/transaction_${session_pid}_header.dat 2>/dev/null
	else
		###WRITE ENTRY TO LOGFILE##################
		echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT sent empty message" >>${script_path}/log/receiver.log
	fi
	###REMOVE DATA AFTER PROCESSING############
	rm ${script_path}/server/transaction_${session_pid}.dat 2>/dev/null
	rm ${script_path}/server/transaction_${session_pid}.dat.tmp 2>/dev/null
else
	parent_pid=$(ps --ppid ${session_pid}|tail -1|awk '{print $1}')
	kill ${parent_pid}
fi

