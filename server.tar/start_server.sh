#!/bin/sh

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###START SCRIPTS###########################
${script_path}/filewatch.sh &
tcpserver -R 127.0.0.1 15000 ${script_path}/receiver.sh &
tcpserver -R 127.0.0.1 15001 ${script_path}/sender.sh &
