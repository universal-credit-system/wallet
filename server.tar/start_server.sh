#!/bin/sh

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(cd "$(dirname "$0")" || exit 1; pwd)

### SET VARIABLES ###########################
logdir="${script_path}/log"
logfile="${logdir}/server.log"
controller="${script_path}/controller.sh"

### CREATE LOG-DIRECTRY IF IT DOESN'T EXIST##
mkdir -p "$logdir"

### GET PIDs OF CONTROLLER.SH (POSIX-SAFE)###
controller_pid_list=$(ps -ef | awk -v controller="${controller}" '$0 ~ controller && $0 !~ /awk/ { print $2 }')
if [ -n "${controller_pid_list:-}" ]
then
	for controller_pid in ${controller_pid_list}
	do
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): [INFO] controller already running with PID ${controller_pid}"|tee -a "${logfile}"
	done
else
	### CALL CONTROLLER.SH ######################
	"${script_path}"/controller.sh &
	controller_pid=$!

	### WRITE LOGFILE ENTRY #####################
        echo "$(date -u): [INFO] controller with PID ${controller_pid} started"|tee -a "${logfile}"
fi

