#!/bin/sh

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### SOURCE CONFIG ###########################
. ${script_path}/control/server.conf

### START SENDER SCRIPT #####################
tcpserver -R -c ${max_connect_sender} ${bind_ip_address} ${sender_port} ${script_path}/sender.sh &
sender_pid=$!

### START RECEIVER SCRIPT ###################
tcpserver -R -c ${max_connect_receiver} ${bind_ip_address} ${receiver_port} ${script_path}/receiver.sh ${sync_user_name} ${sync_user_pin} ${sync_user_pw} &
receiver_pid=$!

### START FILEWATCH SCRIPT ##################
${script_path}/filewatch.sh ${sender_pid} ${receiver_pid} &

### START LOGWATCH SCRIPT ###################
${script_path}/logwatch.sh ${sender_pid} ${receiver_pid} &
