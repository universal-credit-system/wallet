#!/bin/sh

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### SOURCE CONFIG ###########################
. ${script_path}/control/server.conf

### CLEANUP AT START ########################
rm -v ${script_path}/server/*

### START SENDER SCRIPT #####################
tcpserver -R -c ${max_connect_sender} ${bind_ip_address} ${sender_port} ${script_path}/sender.sh &
sender_pid=$!

### START RECEIVER SCRIPT ###################
tcpserver -R -c ${max_connect_receiver} ${bind_ip_address} ${receiver_port} ${script_path}/receiver.sh ${sync_user_name} ${sync_user_pin} ${sync_user_pw} &
receiver_pid=$!

### START FILEWATCH SCRIPT ##################
${script_path}/filewatch.sh ${sender_pid} ${receiver_pid} &
filewatch_pid=$!

### START LOGWATCH SCRIPT ###################
${script_path}/logwatch.sh ${sender_pid} ${receiver_pid} &
logwatch_pid=$!

### SET VARIRABLES FOR LOOP #################
sender_running=0
receiver_running=0
filewatch_running=0
logwatch_running=0

### CHECK IF PROCESSES ARE UP ###############
while [ $sender_running = 0 -a $receiver_running = 0 -a $filewatch_running = 0 -a $logwatch_running = 0 ]
do
	sleep 60
	ps --pid $sender_pid >/dev/null
	sender_running=$?
	ps --pid $receiver_pid >/dev/null
	receiver_running=$?
	ps --pid $filewatch_pid >/dev/null
	filewatch_running=$?
	ps --pid $logwatch_pid >/dev/null
	logwatch_running=$?
done

### CLEAN UP PROCESSES ######################
if [ $sender_running = 0 ]
then
	kill $sender_pid
fi
if [ $receiver_running = 0 ]
then
        kill $receiver_pid
fi
if [ $filewatch_running = 0 ]
then
	kill $filewatch_pid
fi
if [ $logwatch_running = 0 ]
then
	kill $logwatch_pid
fi

### CLEAN UP FILES ##########################
rm -v ${script_path}/server/*
