#!/bin/sh

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###MAX CONNCTIONS##########################
max_connect_receiver=50
max_connect_sender=50

###START SCRIPTS###########################
${script_path}/filewatch.sh &
tcpserver -R -c ${max_connect_receiver} 127.0.0.1 15000 ${script_path}/receiver.sh &
tcpserver -R -c ${max_connect_sender} 127.0.0.1 15001 ${script_path}/sender.sh &
