#!/bin/sh

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname "$(readlink -f "${0}")")

### CHECK IF ANY CONTROLLER IS UP ###########
controllers_running=$(ps -ef|grep "${script_path}/controller.sh"|wc -l)
if [ "$controllers_running" -gt 1 ]
then
	### GET PID OF CONTROLLER####################
        controller_pid=$(ps -ef|grep "${script_path}/controller.sh"|grep -v "grep"|awk '{print $2}')

	### WRITE LOGFILE ENTRY #####################
	echo "Controller already running with PID ${controller_pid}"
else
	### CALL CONTROLLER.SH ######################
	"${script_path}"/controller.sh &
	controller_pid=$!

	### WRITE LOGFILE ENTRY #####################
        echo "$(date -u): controller with PID ${controller_pid} started..." >>"${script_path}"/log/server.log
fi
