#!/bin/sh

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### CHECK IF ANY CONTROLLER IS UP ###########
controllers_running=$(ps -ef|grep "${script_path}/controller.sh"|wc -l)
if [ $controllers_running -gt 0 ]
then
	### GET PID OF CONTROLLER####################
	controller_pid=$(ps -ef|grep "${script_path}/controller.sh"|grep -v "grep"|awk '{print $2}')

	### WRITE LOGFILE ENTRY #####################
	server_date=$(date -u)
	echo "${server_date}: stopping controller with PID ${controller_pid}..." >>${script_path}/log/server.log

	### SENT KILL SIGNAL ########################
	kill ${controller_pid}

	### WRITE LOGFILE ENTRY #####################
	server_date=$(date -u)
	echo "${server_date}: controller with PID ${controller_pid} stopped..." >>${script_path}/log/server.log
fi
