#!/bin/sh

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(cd "$(dirname "$0")" || exit 1; pwd)

### SET VARIABLES ###########################
logdir="${script_path}/log"
logfile="${logdir}/server.log"
controller="${script_path}/controller.sh"

### CREATE LOG-DIRECTRY IF IT DOESN'T EXIST##
mkdir -p "$logdir"

### GET PIDs OF CONTROLLER.SH (POSIX-SAFE)###
controller_pid_list=$(ps -ef | awk -v controller="${controller}" '$0 ~ controller && $0 !~ /awk/ { print $2 }')
if [ -n "${controller_pid_list:-}" ]
then
	for controller_pid in ${controller_pid_list}
	do
		### WRITE LOGFILE ENTRY #####################
		echo "$(date -u): [INFO] stopping controller with PID ${controller_pid} with 'kill -9'"|tee -a "${logfile}"

		### SENT KILL SIGNAL ########################
		if kill -TERM "${controller_pid}" 2>/dev/null
		then
			### WRITE LOGFILE ENTRY #####################
			echo "$(date -u): [INFO] controller with PID ${controller_pid} stopped"|tee "${logfile}"
			
			### CHECK IF REALLY STOPPED #################
			sleep 60
			kill -0 "${controller_pid}" 2>/dev/null && echo "$(date -u): [ERROR] controller with PID ${controller_pid} still alive!"|tee -a "${logfile}"
		else
			### WRITE LOGFILE ENTRY #####################
			echo "$(date -u): [ERROR] failed to stop controller with PID ${controller_pid}"|tee "${logfile}"
		fi
	done
fi
