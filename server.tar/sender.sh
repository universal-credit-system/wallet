#!/bin/sh

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###SET AES256 SESSION KEY##################
session_key=`date -u +%Y%m%d`

###GET CURRENT PID#########################
session_pid=$$

###SET LOGPAH AND DEFINE LOGFILE###########
sender_log="${script_path}/log/sender.log"
sender_date=`date -u`
sender_log_max_lines=10000
if [ -s ${sender_log} ]
then
	sender_log_curr_lines=`cat ${sender_log}|wc -l`
else
	sender_log_curr_lines=0
fi

###CHECK IF LOG>MAX_LINES##################
if [ $sender_log_curr_lines -eq $sender_log_max_lines ]
then
	rm ${sender_log}
fi
echo "${sender_date}: $TCPREMOTEIP $TCPREMOTEPORT requested data" >>${sender_log}

###SET SAVE FILE TO STORE KEY##############
ip_token=`echo $TCPREMOTEIP|sha224sum|cut -d ' ' -f1`
save_file="${script_path}/server/${ip_token}.key"

###CREATE SYNC FILE IF REQUIRED############
syncfile_staged="${script_path}/server/server_syncfile_staged.sync"
syncfile_staged_encrypted="${script_path}/server/server_syncfile_staged_${session_pid}.encr"
if [ ! -s ${syncfile_staged} ]
then
	flock ${script_path}/keys tar -czf ${syncfile_staged} keys/ proofs/ trx/ --dereference --hard-dereference
fi

###WRITE OUTPUT TO FILE#############################
cat - >${script_path}/server/transaction_${session_pid}.dat

if [ -s ${script_path}/server/transaction_${session_pid}.dat ]
then
	###CALCULATE SHARED-SECRET##########################
	userb_random_integer_unformatted=`head -10 /dev/urandom|tr -dc "[:digit:]"|head -c 5`
	userb_random_integer_formatted=`echo "${userb_random_integer_unformatted} / 1"|bc`
	p_number=`head -1 ${script_path}/server/transaction_${session_pid}.dat|cut -d ':' -f1`
	g_number=`head -1 ${script_path}/server/transaction_${session_pid}.dat|cut -d ':' -f2`
	userb_send_tmp=`echo "${g_number} ^ ${userb_random_integer_formatted}"|bc`
	userb_send=`echo "${userb_send_tmp} % ${p_number}"|bc`
	usera_sent=`head -1 ${script_path}/server/transaction_${session_pid}.dat|cut -d ':' -f3`
	ssecret_tmp=`echo "${usera_sent} ^ ${userb_random_integer_formatted}"|bc`
	ssecret=`echo "${ssecret_tmp} % ${p_number}"|bc`
	userb_string="${p_number}:${g_number}:${userb_send}:"

	###GET KEY#################################
	printf "${ssecret}" >${save_file}

	###CALCULATE HSSECRET######################
	hssecret=`echo "${ssecret}_${session_key}"|sha256sum|cut -d ' ' -f1`

	###SEND DATA###############################
	gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output ${syncfile_staged_encrypted} --passphrase ${hssecret} ${syncfile_staged}
	rt_query=$?
	if [ $rt_query = 0 ]
	then
		printf "${userb_string}\n"|cat - ${syncfile_staged_encrypted}
	fi

	###REMOVE TEMP FILES#######################
	rm ${syncfile_staged_encrypted} 2>/dev/null
fi
###REMOVE TEMP FILES#######################
rm ${script_path}/server/transaction_${session_pid}.dat 2>/dev/null
