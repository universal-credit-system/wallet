#!/bin/sh

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###GET SESSION PID#########################
session_pid=$$

###SET AES256 SESSION KEY##################
session_key=`date -u +%Y%m%d`

###SET LOGPAH AND DEFINE LOGFILE###########
sender_log="${script_path}/server.log"
sender_date=`date -u`
sender_log_max_lines=10000
if [ -s ${sender_log} ]
then
	sender_log_curr_lines=`cat ${sender_log}|wc -l`
else
	sender_log_curr_lines=0
fi

###CHECK IF LOG>MAX_LINES##################
if [ $sender_log_curr_lines -eq $sender_log_max_lines ]
then
	rm ${sender_log}
fi
echo "${sender_date}: $TCPREMOTEIP $TCPREMOTEPORT requested data" >>${sender_log}

###CALL OF UCS CLIENT TO SEND##############
client_output="${script_path}/client_out.tmp"
flock ${script_path}/ ${script_path}/ucs_client.sh -action create_sync -user testkonto1 -pin 62268 -password testpw >${client_output} 2>debug_sender.log
rt_query=$?
if [ $rt_query = 0 ]
then
	file_to_reply=`cat ${client_output}|grep "FILE"|cut -d ':' -f2`
	session_file="${script_path}/syncfile_${session_pid}.dat"
	gpg --batch --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output ${session_file} --passphrase ${session_key} ${file_to_reply}
	cat ${session_file}
fi

###PURGE FILES#############################
rm ${client_output} 2>/dev/null
rm ${file_to_reply} 2>/dev/null
rm ${session_file} 2>/dev/null
