#!/bin/sh

###GET START_SERVER.SH PID#################
controller_pid=$1
user_account=$2

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###GET CURRENT PID#########################
session_pid=$$

###CHECK IF SERVER IS STILL RUNNING########
ps --pid $controller_pid >/dev/null
controller_running=$?

if [ $controller_running = 0 ]
then
	###SET AES256 SESSION KEY##################
	session_key=$(date -u +%Y%m%d)

	###WRITE ENTRY TO LOGFILE##################
	sender_date=$(date -u)
	echo "${sender_date}: $TCPREMOTEIP $TCPREMOTEPORT requested data" >>${script_path}/log/sender.log
	sleep 1

	###WRITE OUTPUT TO FILE#############################
	cat - >${script_path}/server/transaction_${session_pid}.dat

	###CHECK IF ANY DATA WAS SENT#######################
	if [ -s ${script_path}/server/transaction_${session_pid}.dat ]
	then
		###TRY TO DECRYPT HEADER################################
		gpg --batch --no-tty --pinentry-mode loopback --output ${script_path}/server/transaction_${session_pid}_header.dat --passphrase ${session_key} --decrypt ${script_path}/server/transaction_${session_pid}.dat 2>/dev/null
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			###CALCULATE SHARED-SECRET##################################
			userb_random_integer_unformatted=$(head -10 /dev/urandom|tr -dc "[:digit:]"|head -c 5)
			userb_random_integer_formatted=$(echo "${userb_random_integer_unformatted} / 1"|bc)
			header=$(head -1 ${script_path}/server/transaction_${session_pid}_header.dat)
			p_number=${header%%:*}
			header=${header#*:}
			g_number=${header%%:*}
			header=${header#*:}
			usera_sent=${header%%:*}
			header=${header#*:}
			usera_session_id=${header%%:*}
			header=${header#*:}
			user_requesting=${header%%:*}

			###CREATE SYNC FILE#############################################
			syncfile_staged="${script_path}/server/syncfile_staged_${session_pid}.sync"
			syncfile_staged_encrypted="${script_path}/server/server_syncfile_staged_${session_pid}.encr"
			receipient_index_file="${script_path}/proofs/${user_requesting}/${user_requesting}.txt"
			user_path="${script_path}/userdata/${user_account}"
			if [ -s $receipient_index_file ]
			then
				###GET ASSETS###################################################
				while read line
				do
					asset_there=$(grep -c "assets/${line}" $receipient_index_file)
					if [ $asset_there = 0 ]
					then
						echo "assets/${line}" >>${user_path}/files_list.tmp
					fi
				done <${user_path}/all_assets.dat

				###GET KEYS AND PROOFS##########################################
				while read line
				do
					key_there=$(grep -c "keys/${line}" $receipient_index_file)
					if [ $key_there = 0 ]
					then
						echo "keys/${line}" >>${user_path}/files_list.tmp
					fi

					for tsa_service in $(ls -1 ${script_path}/certs)
					do
						tsa_req_there=0
						tsa_req_there=$(grep -c "proofs/${line}/${tsa_service}.tsq" $receipient_index_file)
						if [ $tsa_req_there = 0 ]
						then
							echo "proofs/${line}/${tsa_service}.tsq" >>${user_path}/files_list.tmp
						fi
						tsa_res_there=0
						tsa_res_there=$(grep -c "proofs/${line}/${tsa_service}.tsr" $receipient_index_file)
						if [ $tsa_res_there = 0 ]
						then
							echo "proofs/${line}/${tsa_service}.tsr" >>${user_path}/files_list.tmp
						fi
					done
					if [ -s ${script_path}/proofs/${line}/${line}.txt ]
					then
						echo "proofs/${line}/${line}.txt" >>${user_path}/files_list.tmp
					fi
				done <${user_path}/all_accounts.dat

				###GET TRX###################################################################
				while read line
				do
					trx_there=$(grep -c "trx/${line}" $receipient_index_file)
					if [ $trx_there = 0 ]
					then
						echo "trx/${line}" >>${user_path}/files_list.tmp
					fi
				done <${user_path}/all_trx.dat
			else
				###GET ASSETS################################################################
				awk '{print "assets/" $1}' ${user_path}/all_assets.dat >${user_path}/files_list.tmp

				###GET KEYS AND PROOFS#######################################################
				while read line
				do
					echo "keys/${line}" >>${user_path}/files_list.tmp
					for tsa_file in $(ls -1 ${script_path}/proofs/${line}/*.ts*)
					do
						file=$(basename $tsa_file)
						echo "proofs/${line}/${file}" >>${user_path}/files_list.tmp
					done
					if [ -s ${script_path}/proofs/${line}/${line}.txt ]
					then
						echo "proofs/${line}/${line}.txt" >>${user_path}/files_list.tmp
					fi
				done <${user_path}/all_accounts.dat

				###GET TRX###################################################################
				awk '{print "trx/" $1}' ${user_path}/all_trx.dat >>${user_path}/files_list.tmp
			fi
			tar -czf ${syncfile_staged} -T ${user_path}/files_list.tmp --dereference --hard-dereference
			rm ${user_path}/files_list.tmp 2>/dev/null
			#############################################################################

			if [ ! "${p_number}" = "" ] && [ ! "${g_number}" = "" ] && [ ! "${usera_sent}" = "" ] && [ ! "${usera_session_id}" = "" ]
			then
				userb_send_tmp=$(echo "${g_number} ^ ${userb_random_integer_formatted}"|bc)
				userb_send=$(echo "${userb_send_tmp} % ${p_number}"|bc)
				ssecret_tmp=$(echo "${usera_sent} ^ ${userb_random_integer_formatted}"|bc)
				ssecret=$(echo "${ssecret_tmp} % ${p_number}"|bc)
				userb_string="${p_number}:${g_number}:${userb_send}:${user_account}:"

				###SET $SAVE_FILE VARIABLE TO STORE KEY########################
				session_id_token=$(echo ${usera_session_id}|sha224sum|cut -d ' ' -f1)
				save_file="${script_path}/server/${session_id_token}.key"

				###WRITE KEY###################################################
				printf "%s" "${ssecret}" >${save_file}

				###CALCULATE HSSECRET##########################################
				hssecret=$(echo "${ssecret}_${session_key}"|sha256sum|cut -d ' ' -f1)

				###SEND DATA###################################################
				printf "%s" "${userb_string}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --armor --cipher-algo AES256 --output ${script_path}/server/transaction_${session_pid}_header.tmp --passphrase ${session_key} - 2>/dev/null
				rt_query=$?
				if [ $rt_query = 0 ]
				then
					gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --armor --cipher-algo AES256 --output ${syncfile_staged_encrypted} --passphrase ${hssecret} ${syncfile_staged} 2>/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						cat ${script_path}/server/transaction_${session_pid}_header.tmp ${syncfile_staged_encrypted}
					fi
					###REMOVE TEMP FILES#######################
					rm ${syncfile_staged} 2>/dev/null
					rm ${syncfile_staged_encrypted} 2>/dev/null
				fi
				###REMOVE TEMP FILES#######################
				rm ${script_path}/server/transaction_${session_pid}_header.tmp 2>/dev/null
			fi
		fi
		###REMOVE TEMP FILE####################
		rm ${script_path}/server/transaction_${session_pid}_header.dat 2>/dev/null
	fi
	###REMOVE TEMP FILES###############
	rm ${script_path}/server/transaction_${session_pid}.dat 2>/dev/null
else
	parent_pid=$(ps --ppid ${session_pid}|tail -1|awk '{print $1}')
	kill ${parent_pid}
fi
