#!/bin/sh
cleanup() {
			### TO THROUGH LIST AND DELETE #####
			oldIFS=$IFS
			IFS='|'
			for file in ${cleanup_file_list}
			do
				rm -f -- "${file}"
			done
			IFS=${oldIFS}
}
log_message(){
			message_log=$1
			### WRITE OUTPUT ###################
			echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT ${message_log}" >>"${script_path}"/log/sender.log
}
register_cleanup(){
			### ADD TO LIST ####################
			for file in "$@"
			do
				cleanup_file_list="${cleanup_file_list}|${file}"
			done
}
### PRIVILEDGED MODE ########################
umask 077
set -f

### SET TRAP ################################
cleanup_file_list=""
trap cleanup INT TERM EXIT

### GET CONTROLLER.SH PID ###################
controller_pid=$1

### GET CURRENT PID #########################
session_pid=$$

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(cd "$(dirname "$0")" || exit 1; pwd)

### SOURCE CONFIG ###########################
. "${script_path}"/control/server.conf

### CHECK IF CONTROLLER.SH IS STILL RUNNING #
if kill -0 "${controller_pid}" 2>/dev/null && ps -p "${controller_pid}" -o args=|grep -q "controller.sh"
then
	### SET RT_QUERY ############################
	rt_query=0

	### SET AES256 SESSION KEY ##################
	session_key=$(date -u +%Y%m%d)

	### GET UNIQUE ID ###########################
	unique_id=$(basename "$(mktemp XXXXXXXXXXXXXXXX -p "${script_path}"/server/)")

	### ADD ID-FILE TO TRAP #####################
	register_cleanup "${script_path}/server/${unique_id}"

	### SET FILE PATHS ##########################
	user_path="${script_path}/userdata/${user_account}"
	out_file="${script_path}/server/transaction_${unique_id}.dat"
	syncfile_staged="${script_path}/server/syncfile_staged_${unique_id}.sync"
	syncfile_staged_encrypted="${script_path}/server/server_syncfile_staged_${unique_id}.encr"

	### WRITE ENTRY TO LOGFILE ##################
	log_message "connected"

	### ACCEPT CONNECTION AND WRITE TO FILE #####
	#cat - >${out_file}
	timeout "${connect_read_timeout}" dd bs=1 status=none >"${out_file}"
	rt_query=$?

	### ADD OUTFILE TO TRAP #####################
	register_cleanup "${out_file}"

	### CHECK IF ANY DATA WAS SENT ##############
	if [ -s "${out_file}" ] && [ "${rt_query}" -eq 0 ]
	then
		### GET SIZE OF HEADER AND BODY #############
		total_lines_header_user=$(grep -n "END PGP MESSAGE" "${out_file}"|cut -d ':' -f1)
		total_lines_header_param=$(grep -n "DH PARAMETERS" "${out_file}"|grep "END"|cut -d ':' -f1)
		total_lines_header_key=$(grep -n "END PUBLIC KEY" "${out_file}"|cut -d ':' -f1)
		total_lines_user_param=$(( total_lines_header_param - total_lines_header_user ))
		total_lines_key_param=$(( total_lines_header_key - total_lines_header_param ))

		### CHECK HEADERS ###########################
		if [ -n "${total_lines_header_user:-}" ] && [ -n "${total_lines_header_param:-}" ] && [ -n "${total_lines_header_key:-}" ]
		then
			### EXTRACT RECEIVED USERDATA ###############
			head -"${total_lines_header_user}" "${out_file}" >"${script_path}/server/dhuser_received_${unique_id}.tmp"

			### EXTRACT RECEIVED DHPARAMS ###############
			head -"${total_lines_header_param}" "${out_file}"|tail -"$total_lines_user_param" >"${script_path}/server/dhparams_${unique_id}.pem"

			### EXTRACT RECEIVED PUBLIC KEY #############
			head -"${total_lines_header_key}" "${out_file}"|tail -"$total_lines_key_param" >"${script_path}/server/dhpub_receive_${unique_id}.pem"

			### ADD FILES TO TRAP #######################
			register_cleanup "${script_path}/server/dhuser_received_${unique_id}.tmp"
			register_cleanup "${script_path}/server/dhparams_${unique_id}.pem"
			register_cleanup "${script_path}/server/dhpub_receive_${unique_id}.pem"

			### GENERATE DH KEY #########################
			openssl genpkey -paramfile "${script_path}/server/dhparams_${unique_id}.pem" -out - >"${script_path}/server/dhkey_send_${unique_id}.pem"
			rt_query=$?
			if [ "${rt_query}" -eq 0 ]
			then
				### ADD FILES TO TRAP #######################
				register_cleanup "${script_path}/server/dhkey_send_${unique_id}.pem"
	
				### GET DH PUBLIC KEY #######################
				openssl pkey -in "${script_path}/server/dhkey_send_${unique_id}.pem" -pubout -out - >"${script_path}/server/dhpub_send_${unique_id}.pem"
				rt_query=$?
				if [ "${rt_query}" -eq 0 ]
				then
					### ADD FILES TO TRAP #######################
					register_cleanup "${script_path}/server/dhpub_send_${unique_id}.pem"
				
					### CALCULATE SHARED SECRET #################
					openssl pkeyutl -derive -inkey "${script_path}/server/dhkey_send_${unique_id}.pem" -peerkey "${script_path}/server/dhpub_receive_${unique_id}.pem" -out - >"${script_path}/server/dhsecret_${unique_id}.dat"
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### ADD FILES TO TRAP #######################
						register_cleanup "${script_path}/server/dhsecret_${unique_id}.dat"
		
						### HASH SHARED SECRET ######################
						shared_secret=$(sha224sum <"${script_path}/server/dhsecret_${unique_id}.dat")
						shared_secret=${shared_secret%% *}

						### DECRYPT RECEIVED USERDATA ###############
						echo "${session_key}"|gpg --batch --no-tty --pinentry-mode loopback --output - --passphrase-fd 0 --decrypt "${script_path}/server/dhuser_received_${unique_id}.tmp" >"${script_path}/server/dhuser_received_${unique_id}.dat" 2>/dev/null
						if [ "${rt_query}" -eq 0 ]
						then
							### ADD FILES TO TRAP #######################
							register_cleanup "${script_path}/server/dhuser_received_${unique_id}.dat"

							### EXTRACT ID ##############################
							user_data="${script_path}/server/dhuser_received_${unique_id}.dat"
							user_requesting=$(head -1 "${user_data}")
							user_requesting_hash=$(echo "${user_requesting}"|sha224sum)
							user_requesting_hash=${user_requesting_hash%% *}

							### RENAME FILE TO ID #######################
							mv "${script_path}/server/dhsecret_${unique_id}.dat" "${script_path}/server/dhsecret_${user_requesting_hash}.dat"

							### EXTRACT RECEIVED INDEX DATA #############
							user_data_lines=$(wc -l <"${user_data}")
							user_data_lines=$(( user_data_lines - 1 ))
							user_index=$(tail -"${user_data_lines}" "${user_data}")

							### COMPARE INDEXES #########################
							gpg --output - --verify "${script_path}/proofs/${user_account}/${user_account}.txt" 2>/dev/null|grep -v "trx/" >"${script_path}/server/index_${unique_id}.dat"
							sha224sum "${script_path}"/trx/* 2>/dev/null|awk '{print $2 " " $1}'|sed "s#${script_path}/##g" >>"${script_path}/server/index_${unique_id}.dat"
							shared_dataset=$(echo "${user_index}"|sort - "${script_path}/server/index_${unique_id}.dat"|uniq -d)
							echo "${shared_dataset}"|sort - "${script_path}/server/index_${unique_id}.dat"|uniq -u|cut -d ' ' -f1 >"${user_path}"/files_list.tmp
							
							### ADD FILES TO TRAP #######################
							register_cleanup "${user_path}"/files_list.tmp
							register_cleanup "${script_path}/server/index_${unique_id}.dat"

							### AT LEAST SEND OWN INDEX #################
							if [ ! -s "${user_path}"/files_list.tmp ]
							then
								echo "proofs/${user_account}/${user_account}.txt" >"${user_path}"/files_list.tmp
							fi

							### PACK SYNCFILE ###########################
							tar -czf "${syncfile_staged}" -T "${user_path}"/files_list.tmp --dereference --hard-dereference
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### ADD FILES TO TRAP #######################
								register_cleanup "${syncfile_staged}"

								### WRITE INDEX FILE ########################
								gpg --output - --verify "${script_path}/proofs/${user_account}/${user_account}.txt" >"${script_path}/server/dhuser_${unique_id}.tmp" 2>/dev/null

								### ADD FILES TO TRAP #######################
								register_cleanup "${script_path}/server/dhuser_${unique_id}.tmp"

								### ENCRYPT DATA ############################
								echo "${shared_secret}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --armor --cipher-algo AES256 --output "${script_path}/server/dhuser_${unique_id}.dat" --passphrase-fd 0 "${script_path}/server/dhuser_${unique_id}.tmp" 2>/dev/null
								rt_query=$?
								if [ "${rt_query}" -eq 0 ]
								then
									### ADD FILES TO TRAP #######################
									register_cleanup "${script_path}/server/dhuser_${unique_id}.dat"

									### ENCRYPT SYNC FILE #######################
									echo "${shared_secret}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --armor --cipher-algo AES256 --output "${syncfile_staged_encrypted}" --passphrase-fd 0 "${syncfile_staged}" 2>/dev/null
									rt_query=$?
									if [ "${rt_query}" -eq 0 ]
									then
										### ADD FILES TO TRAP #######################
										register_cleanup "${syncfile_staged_encrypted}"

										### SEND HEADER AND SYNC FILE ################
										cat "${script_path}/server/dhuser_${unique_id}.dat" "${script_path}/server/dhpub_send_${unique_id}.pem" "${syncfile_staged_encrypted}"

										### WRITE ENTRY TO LOGFILE ###################
										log_message "successfully linked"
									fi
								fi
							else
								### WRITE ENTRY TO LOGFILE ##################
								log_message "could not create sync file"
							fi
						else
							### WRITE ENTRY TO LOGFILE ##################
							log_message "could not decrypt client info"
						fi
					else
						### WRITE ENTRY TO LOGFILE ##################
						log_message "could not calculate shared secret"
					fi
				else
					### WRITE ENTRY TO LOGFILE ##################
					log_message "could not generate public key"
				fi
			else
				### WRITE ENTRY TO LOGFILE ##################
				log_message "could not generate key"
			fi
		else
			### WRITE ENTRY TO LOGFILE ##########################
			log_message "invalid protocol"
		fi
	else
		if [ "${rt_query}" -eq 124 ]
		then
			### WRITE ENTRY TO LOGFILE ##################
			log_message "connection timed out"
		else
			### WRITE ENTRY TO LOGFILE ##################
			log_message "sent empty message"
		fi
	fi
else
	### WRITE ENTRY TO LOGFILE ##################
	log_message "controller not running. exiting"

	### CHECK IF PARENT PID IS STILL VALID ######
	if kill -0 "${PPID}" 2>/dev/null && ps -p "${PPID}" -o args=|grep -q "tcpserver"
	then
		### WRITE ENTRY TO LOGFILE ##################
		log_message "stopping sender.sh listener"

		### STOP LISTENER (PARENT) ##################
		kill "${PPID}"
	fi
	
	### STOP LISTENER (PARENT) ##################
	kill "${PPID}"
fi

