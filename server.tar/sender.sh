#!/bin/sh

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###SET LOGPAH AND DEFINE LOGFILE###########
sender_log="${script_path}/sender.log"
sender_date=`date -u`
sender_log_max_lines=10000
sender_log_curr_lines=`cat ${sender_log}|wc -l`

###CHECK IF LOG>MAX_LINES##################
if [ $sender_log_curr_lines -eq $sender_log_max_lines ]
then
	rm ${sender_log}
fi
echo "$TCPREMOTEIP:$TCPREMOTEPORT connected on ${sender_date}" >>${sender_log}

###SET AES256 SESSION KEY##################
session_key=`date -u +%Y%m%d`

###CALL OF UCS CLIENT TO SEND##############
client_output="${script_path}/client_out.tmp"
flock ${script_path}/ ${script_path}/ucs_client.sh -action create_sync -user testkonto1 -pin 62268 -password testpw >${client_output}
rt_query=$?
if [ $rt_query = 0 ]
then
	file_to_reply=`cat ${client_output}|grep "FILE"|cut -d ':' -f2`
	cat ${file_to_reply}|gpg --batch --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output - --passphrase ${session_key} -
fi

###REMOVE OUTPUT AFTER PROCESSING##########
rm ${client_output} 2>/dev/null

###REMOVE SYNC FILE########################
rm ${file_to_reply} 2>/dev/null
