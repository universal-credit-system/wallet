#!/bin/sh

### GET CONTROLLER.SH PID ###################
controller_pid=$1

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### GET CURRENT PID #########################
session_pid=$$

### SOURCE CONFIG ###########################
. ${script_path}/control/server.conf

### CHECK IF SERVER IS STILL RUNNING ########
ps --pid $controller_pid >/dev/null
controller_running=$?

if [ $controller_running = 0 ]
then
	### SET AES256 SESSION KEY ##################
	session_key=$(date -u +%Y%m%d)

	### SET FILE PATHS ##########################
	user_path="${script_path}/userdata/${user_account}"
	out_file="${script_path}/server/transaction_${session_pid}.dat"
	syncfile_staged="${script_path}/server/syncfile_staged_${session_pid}.sync"
	syncfile_staged_encrypted="${script_path}/server/server_syncfile_staged_${session_pid}.encr"

	### WRITE ENTRY TO LOGFILE ##################
	echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT connected" >>${script_path}/log/sender.log

	### ACCEPT CONNECTION AND WRITE TO FILE #####
	#cat - >${out_file}
	dd bs=1 status=none >${out_file}

	### CHECK IF ANY DATA WAS SENT ##############
	if [ -s ${out_file} ]
	then
		### GET SIZE OF HEADER AND BODY #############
		total_lines_header_user=$(grep -n "END PGP MESSAGE" ${out_file}|cut -d ':' -f1)
		total_lines_header_param=$(grep -n "DH PARAMETERS" ${out_file}|grep "END"|cut -d ':' -f1)
		total_lines_header_key=$(grep -n "END PUBLIC KEY" ${out_file}|cut -d ':' -f1)
		total_lines_user_param=$(( total_lines_header_param - total_lines_header_user ))
		total_lines_key_param=$(( total_lines_header_key - total_lines_header_param ))
		
		### EXTRACT RECEIVED USERNAME ###############
		head -$total_lines_header_user ${out_file} >${script_path}/server/dhuser_received_${session_pid}.tmp
		
		### EXTRACT RECEIVED DHPARAMS ###############
		head -$total_lines_header_param ${out_file}|tail -$total_lines_user_param >${script_path}/server/dhparams_${session_pid}.pem
		
		### EXTRACT RECEIVED PUBLIC KEY #############
		head -$total_lines_header_key ${out_file}|tail -$total_lines_key_param >${script_path}/server/dhpub_receive_${session_pid}.pem
			
		### GENERATE KEY ############################
		openssl genpkey -paramfile ${script_path}/server/dhparams_${session_pid}.pem -out - >${script_path}/server/dhkey_send_${session_pid}.pem
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			### GET PUBLIC KEY ##########################
			openssl pkey -in ${script_path}/server/dhkey_send_${session_pid}.pem -pubout -out - >${script_path}/server/dhpub_send_${session_pid}.pem
			rt_query=$?
			if [ $rt_query = 0 ]
			then
				### EXTRACT SHARED SECRET ###################
				openssl pkeyutl -derive -inkey ${script_path}/server/dhkey_send_${session_pid}.pem -peerkey ${script_path}/server/dhpub_receive_${session_pid}.pem -out - >${script_path}/server/dhsecret_${session_pid}.dat
				rt_query=$?
				if [ $rt_query = 0 ]
				then
					### HASH SHARED SECRET ######################
					shared_secret=$(sha224sum <${script_path}/server/dhsecret_${session_pid}.dat)
					shared_secret=${shared_secret%% *}
					
					### DECRYPT RECEIVED USERNAME ###############
					echo "${session_key}"|gpg --batch --no-tty --pinentry-mode loopback --output - --passphrase-fd 0 --decrypt ${script_path}/server/dhuser_received_${session_pid}.tmp >${script_path}/server/dhuser_received_${session_pid}.dat 2>/dev/null
					user_requesting=$(cat ${script_path}/server/dhuser_received_${session_pid}.dat)
					user_requesting_hash=$(sha224sum <${script_path}/server/dhuser_received_${session_pid}.dat)
					user_requesting_hash=${user_requesting_hash%% *}
					
					### MOVE SECRET FILE#### ####################
					mv ${script_path}/server/dhsecret_${session_pid}.dat ${script_path}/server/dhsecret_${user_requesting_hash}.dat
					
					### CHECK FOR INDEX FILE ####################
					receipient_index_file="${script_path}/proofs/${user_requesting}/${user_requesting}.txt"
					if [ -s $receipient_index_file ]
					then
						### GET ASSETS ##############################
						while read line
						do
							asset_there=$(grep -c "assets/${line}" $receipient_index_file)
							if [ $asset_there = 0 ]
							then
								echo "assets/${line}" >>${user_path}/files_list.tmp
							fi
						done <${user_path}/all_assets.dat

						### GET KEYS AND PROOFS #####################
						while read line
						do
							key_there=$(grep -c "keys/${line}" $receipient_index_file)
							if [ $key_there = 0 ]
							then
								echo "keys/${line}" >>${user_path}/files_list.tmp
							fi
							for tsa_file in $(ls -1 ${script_path}/proofs/${line}/*.ts*)
							do
								file=$(basename $tsa_file)
								tsa_file_there=$(grep -c "proofs/${line}/${file}" $receipient_index_file)
								if [ $tsa_file_there = 0 ]
								then
									echo "proofs/${line}/${file}" >>${user_path}/files_list.tmp
								fi
							done
							if [ -s ${script_path}/proofs/${line}/${line}.txt ]
							then
								echo "proofs/${line}/${line}.txt" >>${user_path}/files_list.tmp
							fi
						done <${user_path}/all_accounts.dat

						### GET TRX #################################
						while read line
						do
							trx_there=$(grep -c "trx/${line}" $receipient_index_file)
							if [ $trx_there = 0 ]
							then
								echo "trx/${line}" >>${user_path}/files_list.tmp
							fi
						done <${user_path}/all_trx.dat
					else
						### GET ASSETS ##############################
						awk '{print "assets/" $1}' ${user_path}/all_assets.dat >${user_path}/files_list.tmp

						### GET KEYS AND PROOFS #####################
						while read line
						do
							echo "keys/${line}" >>${user_path}/files_list.tmp
							for tsa_file in $(ls -1 ${script_path}/proofs/${line}/*.ts*)
							do
								file=$(basename $tsa_file)
								echo "proofs/${line}/${file}" >>${user_path}/files_list.tmp
							done
							if [ -s ${script_path}/proofs/${line}/${line}.txt ]
							then
								echo "proofs/${line}/${line}.txt" >>${user_path}/files_list.tmp
							fi
						done <${user_path}/all_accounts.dat

						### GET TRX #################################
						awk '{print "trx/" $1}' ${user_path}/all_trx.dat >>${user_path}/files_list.tmp
					fi
					
					### PACK SYNCFILE ###########################
					tar -czf ${syncfile_staged} -T ${user_path}/files_list.tmp --dereference --hard-dereference
					rm ${user_path}/files_list.tmp 2>/dev/null
					
					### ENCRYPT USERNAME ########################
					echo "${user_account}" >${script_path}/server/dhuser_${session_pid}.tmp
					echo "${shared_secret}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --armor --cipher-algo AES256 --output ${script_path}/server/dhuser_${session_pid}.dat --passphrase-fd 0 ${script_path}/server/dhuser_${session_pid}.tmp 2>/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### ENCRYPT SYNC FILE #######################
						echo "${shared_secret}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --armor --cipher-algo AES256 --output ${syncfile_staged_encrypted} --passphrase-fd 0 ${syncfile_staged} 2>/dev/null
						rt_query=$?
						if [ $rt_query = 0 ]
						then
							### SEND HEADER AND SYNC FILE ################
							cat ${script_path}/server/dhuser_${session_pid}.dat ${script_path}/server/dhpub_send_${session_pid}.pem ${syncfile_staged_encrypted}
							
							### WRITE ENTRY TO LOGFILE ###################
							echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT successfully linked" >>${script_path}/log/sender.log
						fi
						rm ${syncfile_staged} 2>/dev/null
						rm ${syncfile_staged_encrypted} 2>/dev/null
					fi
				else
					### WRITE ENTRY TO LOGFILE ##################
					echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT could not calculate shared secret" >>${script_path}/log/sender.log
				fi
			else
				### WRITE ENTRY TO LOGFILE ##################
				echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT could not generate public key" >>${script_path}/log/sender.log
			fi
		else
			### WRITE ENTRY TO LOGFILE ##################
			echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT could not generate key" >>${script_path}/log/sender.log
		fi
	else
		### WRITE ENTRY TO LOGFILE ##################
		echo "$(date -u): $TCPREMOTEIP $TCPREMOTEPORT sent empty message" >>${script_path}/log/sender.log
	fi
	rm ${script_path}/server/transaction_${session_pid}.dat 2>/dev/null
	rm ${script_path}/server/dhuser_${session_pid}.* 2>/dev/null
	rm ${script_path}/server/dhuser_received_${session_pid}.* 2>/dev/null
	rm ${script_path}/server/dhparams_${session_pid}.pem 2>/dev/null
	rm ${script_path}/server/dhkey_*.pem 2>/dev/null
	rm ${script_path}/server/dhpub_send_${session_pid}.pem 2>/dev/null
	rm ${script_path}/server/dhpub_receive_${session_pid}.pem 2>/dev/null
else
	parent_pid=$(ps --ppid ${session_pid}|tail -1|awk '{print $1}')
	kill ${parent_pid}
fi

