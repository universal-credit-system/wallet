#!/bin/sh

###GET START_SERVER.SH PID#################
controller_pid=$1

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))

###GET CURRENT PID#########################
session_pid=$$

###CHECK IF SERVER IS STILL RUNNING########
ps --pid $controller_pid >/dev/null
controller_running=$?

if [ $controller_running = 0 ]
then
	###SET AES256 SESSION KEY##################
	session_key=$(date -u +%Y%m%d)

	###WRITE ENTRY TO LOGFILE##################
	sender_date=$(date -u)
	echo "${sender_date}: $TCPREMOTEIP $TCPREMOTEPORT requested data" >>${script_path}/log/sender.log

	###CREATE SYNC FILE IF REQUIRED############
	syncfile_staged="${script_path}/server/server_syncfile_staged.sync"
	syncfile_staged_encrypted="${script_path}/server/server_syncfile_staged_${session_pid}.encr"
	if [ ! -s ${syncfile_staged} ]
	then
		flock ${script_path}/keys tar -czf ${syncfile_staged} keys/ proofs/ trx/ --dereference --hard-dereference
	fi

	###WRITE OUTPUT TO FILE#############################
	cat - >${script_path}/server/transaction_${session_pid}.dat

	###CHECK IF ANY DATA WAS SENT#######################
	if [ -s ${script_path}/server/transaction_${session_pid}.dat ]
	then
		###TRY TO DECRYPT HEADER################################
		head -6 ${script_path}/server/transaction_${session_pid}.dat|gpg --batch --no-tty --pinentry-mode loopback --output ${script_path}/server/transaction_${session_pid}_header.dat --passphrase ${session_key} --decrypt - 2>/dev/null
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			###CALCULATE SHARED-SECRET##################################
			userb_random_integer_unformatted=$(head -10 /dev/urandom|tr -dc "[:digit:]"|head -c 5)
			userb_random_integer_formatted=$(echo "${userb_random_integer_unformatted} / 1"|bc)
			header=$(head -1 ${script_path}/server/transaction_${session_pid}_header.dat)
			p_number=$(echo $header|cut -d ':' -f1)
			g_number=$(echo $header|cut -d ':' -f2)
			usera_sent=$(echo $header|cut -d ':' -f3)
			usera_session_id=$(echo $header|cut -d ':' -f4)
			if [ ! "${p_number}" = "" -a ! "${g_number}" = "" -a ! "${usera_sent}" = "" -a ! "${usera_session_id}" = "" ]
			then
				userb_send_tmp=$(echo "${g_number} ^ ${userb_random_integer_formatted}"|bc)
				userb_send=$(echo "${userb_send_tmp} % ${p_number}"|bc)
				ssecret_tmp=$(echo "${usera_sent} ^ ${userb_random_integer_formatted}"|bc)
				ssecret=$(echo "${ssecret_tmp} % ${p_number}"|bc)
				userb_string="${p_number}:${g_number}:${userb_send}:"

				###SET $SAVE_FILE VARIABLE TO STORE KEY########################
				session_id_token=$(echo ${usera_session_id}|sha224sum|cut -d ' ' -f1)
				save_file="${script_path}/server/${session_id_token}.key"

				###WRITE KEY###################################################
				printf "${ssecret}" >${save_file}

				###CALCULATE HSSECRET##########################################
				hssecret=$(echo "${ssecret}_${session_key}"|sha256sum|cut -d ' ' -f1)

				###SEND DATA###################################################
				printf "${userb_string}\n"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --armor --cipher-algo AES256 --output ${script_path}/server/transaction_${session_pid}_header.tmp --passphrase ${session_key} - 2>/dev/null
				rt_query=$?
				if [ $rt_query = 0 ]
				then
					gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --armor --cipher-algo AES256 --output ${syncfile_staged_encrypted} --passphrase ${hssecret} ${syncfile_staged} 2>/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						flock ${syncfile_staged_encrypted} cat ${script_path}/server/transaction_${session_pid}_header.tmp ${syncfile_staged_encrypted}
					fi
					###REMOVE TEMP FILES#######################
					rm ${syncfile_staged_encrypted} 2>/dev/null
				fi
				###REMOVE TEMP FILES#######################
				rm ${script_path}/server/transaction_${session_pid}_header.tmp 2>/dev/null
			fi
		fi
		###REMOVE TEMP FILE####################
		rm ${script_path}/server/transaction_${session_pid}_header.dat 2>/dev/null
	fi
	###REMOVE TEMP FILES###############
	rm ${script_path}/server/transaction_${session_pid}.dat 2>/dev/null
else
	parent_pid=$(ps --ppid ${session_pid}|tail -1|awk '{print $1}')
	kill ${parent_pid}
fi
