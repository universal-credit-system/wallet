#!/bin/sh

###GET DIR SCRIPT IS RUNNING IN############
script_path=$(dirname $(readlink -f ${0}))
cd ${script_path}/

###SET AES256 SESSION KEY##################
session_key=`date -u +%Y%m%d`

###SET LOGPAH AND DEFINE LOGFILE###########
sender_log="${script_path}/sender.log"
sender_date=`date -u`
sender_log_max_lines=10000
if [ -s ${sender_log} ]
then
	sender_log_curr_lines=`cat ${sender_log}|wc -l`
else
	sender_log_curr_lines=0
fi

###CHECK IF LOG>MAX_LINES##################
if [ $sender_log_curr_lines -eq $sender_log_max_lines ]
then
	rm ${sender_log}
fi
echo "${sender_date}: $TCPREMOTEIP $TCPREMOTEPORT requested data" >>${sender_log}

###CREATE SYNC FILE IF REQUIRED############
syncfile_staged="${script_path}/server_syncfile_staged.sync"
if [ ! -s ${syncfile_staged} ]
then
	flock ${script_path}/ tar -czf ${syncfile_staged} keys/ proofs/ trx/ --dereference --hard-dereference
fi

###SEND DATA###############################
flock ${syncfile_staged} cat ${syncfile_staged}|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output - --passphrase ${session_key} -
