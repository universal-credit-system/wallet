#!/bin/sh

### GET PID #################################
controller_pid=$1

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(cd "$(dirname "$0")" || exit 1; pwd)

### SET DEFAULT VALUES ######################
server_log_max_lines=500
sender_log_max_lines=10000
receiver_log_max_lines=10000
logwatch_interval_seconds=60

### SOURCE CONFIG FILE ######################
. "${script_path}"/control/server.conf

while kill -0 "${controller_pid}" 2>/dev/null && ps -p "${controller_pid}" -o args=|grep -q "controller.sh"
do
	### PURGE SENDER LOG ######################
	if [ -s "${script_path}"/log/sender.log ]
	then
		sender_log_size=$(wc -l <"${script_path}"/log/sender.log)
		if [ "${sender_log_size}" -gt "${sender_log_max_lines}" ]
		then
			rm "${script_path}"/log/sender.log
		fi
	fi

	### PURGE RECEIVER LOG ####################
	if [ -s "${script_path}"/log/receiver.log ]
	then
	       	receiver_log_size=$(wc -l <"${script_path}"/log/receiver.log)
	       	if [ "${receiver_log_size}" -gt "${receiver_log_max_lines}" ]
	       	then
	               	rm "${script_path}"/log/receiver.log
	       	fi
	fi

	### PURGE SERVER LOG ######################
	if [ -s "${script_path}"/log/server.log ]
	then
		server_log_size=$(wc -l <"${script_path}"/log/server.log)
		if  [ "${server_log_size}" -gt "${server_log_max_lines}" ]
		then
			rm "${script_path}"/log/server.log
		fi
	fi

	### WAIT ##################################
	sleep "${logwatch_interval_seconds}"
done

