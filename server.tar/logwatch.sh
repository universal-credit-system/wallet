#!/bin/sh

### GET VARIABLES ###########################
controller_pid=$1

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f "${0}"))

### SOURCE CONFIG FILE ######################
. "${script_path}"/control/server.conf

### CHECK PIDS ##############################
ps --pid $controller_pid >/dev/null
controller_running=$?

while [ "$controller_running" -eq 0 ]
do
	### PURGE SENDER LOG ######################
	if [ -s "${script_path}"/log/sender.log ]
	then
		sender_log_size=$(wc -l <"${script_path}"/log/sender.log)
		if [ "$sender_log_size" -gt "$sender_log_max_lines" ]
		then
			rm "${script_path}"/log/sender.log
		fi
	fi

	### PURGE RECEIVER LOG ####################
	if [ -s "${script_path}"/log/receiver.log ]
        then
               	receiver_log_size=$(wc -l <"${script_path}"/log/receiver.log)
               	if [ "$receiver_log_size" -gt "$receiver_log_max_lines" ]
               	then
                       	rm "${script_path}"/log/receiver.log
               	fi
        fi

	### PURGE SERVER LOG ######################
	server_log_size=$(wc -l <"${script_path}"/log/server.log)
	if  [ "$server_log_size" -gt "$server_log_max_lines" ]
	then
		rm "${script_path}"/log/server.log
	fi

	### WAIT ##################################
	sleep $logwatch_interval_seconds

	### CHECK PIDS ############################
	ps --pid $controller_pid >/dev/null
        controller_running=$?
done

