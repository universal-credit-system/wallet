#!/bin/sh

### GET VARIABLES ###########################
sender_pid=$1
receiver_pid=$2

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### SOURCE CONFIG FILE ######################
. ${script_path}/control/server.conf

### CHECK PIDS ##############################
ps --pid $sender_pid >/dev/null
sender_pid_check=$?
ps --pid $receiver_pid >/dev/null
receiver_pid_check=$?

while [ $sender_pid_check -eq 0 -o $receiver_pid_check -eq 0 ]
do
	### CHECK IF SENDER.SH IS RUNNING ###########
	if [ $sender_pid_check -eq 0 ]
	then
		if [ -s ${script_path}/log/sender.log ]
		then
			sender_log_size=`wc -l <${script_path}/log/sender.log`
			if [ $sender_log_size -gt $sender_log_max_lines ]
			then
				rm ${script_path}/log/sender.log
			fi
		fi
	fi
	### CHECK IF RECEIVER.SH IS RUNNING #########
	if [ $receiver_pid_check -eq 0 ]
	then
		if [ -s ${script_path}/log/receiver.log ]
        	then
                	receiver_log_size=`wc -l <${script_path}/log/receiver.log`
                	if [ $receover_log_size -gt $receiver_log_max_lines ]
                	then
                        	rm ${script_path}/log/receiver.log
                	fi
		fi
        fi

	### WAIT #################################
	sleep $logwatch_interval_seconds

	### CHECK PIDS ###########################
	ps --pid $sender_pid >/dev/null
	sender_pid_check=$?
	ps --pid $receiver_pid >/dev/null
	receiver_pid_check=$?
done
