#!/bin/sh

### GET VARIABLES ###########################
server_pid=$1
sender_pid=$2
receiver_pid=$3

### GET DIR SCRIPT IS RUNNING IN ############
script_path=$(dirname $(readlink -f ${0}))

### SOURCE CONFIG FILE ######################
. ${script_path}/control/server.conf

### CHECK PIDS ##############################
ps --pid $server_pid >/dev/null
server_pid_check=$?
ps --pid $sender_pid >/dev/null
sender_pid_check=$?
ps --pid $receiver_pid >/dev/null
receiver_pid_check=$?

while [ $server_pid_check = 0 -a $sender_pid_check = 0 -a $receiver_pid_check = 0 ]
do
	### PURGE SENDER LOG ######################
	if [ -s ${script_path}/log/sender.log ]
	then
		sender_log_size=`wc -l <${script_path}/log/sender.log`
		if [ $sender_log_size -gt $sender_log_max_lines ]
		then
			rm ${script_path}/log/sender.log
		fi
	fi

	### PURGE RECEIVER LOG ####################
	if [ -s ${script_path}/log/receiver.log ]
        then
               	receiver_log_size=`wc -l <${script_path}/log/receiver.log`
               	if [ $receiver_log_size -gt $receiver_log_max_lines ]
               	then
                       	rm ${script_path}/log/receiver.log
               	fi
        fi

	### PURGE SERVER LOG ######################
	server_log_size=`wc -l <${script_path}/log/server.log`
	if  [ $server_log_size -gt $server_log_max_lines ]
	then
		rm ${script_path}/log/server.log
	fi

	### WAIT ##################################
	sleep $logwatch_interval_seconds

	### CHECK PIDS ############################
	ps --pid $server_pid >/dev/null
        server_pid_check=$?
	ps --pid $sender_pid >/dev/null
	sender_pid_check=$?
	ps --pid $receiver_pid >/dev/null
	receiver_pid_check=$?
done
