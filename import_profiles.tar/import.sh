#!/bin/sh -xv
script_name=${0}
script_path=$(dirname $(readlink -f ${0}))
ls -1 *.asc >${script_path}/keys.tmp
while read line
do
	gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --import ${script_path}/${line}
done <${script_path}/keys.tmp
rm ${script_path}/keys.tmp
