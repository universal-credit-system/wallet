#!/bin/sh

### ASSIGN VARIABLES ########################
wwwpath=$1
specific_env=$2

### GET SCRIPT PATH #########################
script_path=$(dirname $(readlink -f "${0}"))

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

### SET VARIABLES ############
error_detected=0

###CHECK DEPENDENCIES#######
while read line
do
	###CHECK IF PROGRAMM IS UNKNOWN####
        type "$line" >/dev/null
        rt_query=$?
        if [ $rt_query -gt 0 ]
        then
                echo "$line" >>"${script_path}"/webapi_install_dep.tmp
        fi
done <"${script_path}"/control/webapi_install.dep
if [ -f ${script_path}/webapi_install_dep.tmp ] && [ -s ${script_path}/webapi_install_dep.tmp ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case $specific_env in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				if [ -x "$(command -v apk)" ]
				then
					pkg_mngr="apk";
				else
					if [ -x "$(command -v apt-get)" ]
					then
						pkg_mngr="apt-get";
					else
						if [ -x "$(command -v dnf)" ]
						then
							pkg_mngr="dnf";
						else
							if [ -x "$(command -v pacman)" ]
							then
								pkg_mngr="pacman";
							else
								if [ -x "$(command -v pkg)" ]
								then
									pkg_mngr="pkg";
								else
									if [ -x "$(command -v yum)" ]
									then
										pkg_mngr="yum";
									else
										if [ -x "$(command -v zypper)" ]
										then
											pkg_mngr="zypper";
										else
											###IF PACKAGING MANAGER DETECTION FAILED####
											error_detected=1
											no_of_programs=$(wc -l <${script_path}/webapi_install_dep.tmp)
											echo "ERROR: Couldn't detect the package management system used on this machine!"
											echo "Found ${no_of_programs} programs that need to be installed:"
											cat ${script_path}/webapi_install_dep.tmp
											echo "Install these programms first using your package management system and then run install_webapi.sh again."
											############################################
										fi
									fi
								fi
							fi
						fi
					fi
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ $error_detected = 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read line
		do
			printf "%b" "INFO: Trying to install ${line} using ${pkg_mngr}...\n"
			case $pkg_mngr in
				"apk")		apk add $line ;;
				"apt-get")	apt-get -y install $line ;;
				"dnf")		dnf -y install $line ;;
				"pacman")	pacman --noconfirm -S $line ;;
				"pkg")		pkg install -y $line ;;
				"yum")		yum -y install $line ;;
				"zypper")	zypper -n install $line ;;
			esac
			rt_query=$?
			if [ ! $rt_query = 0 ]
			then
				error_detected=1
				echo "Error running the following command: ${pkg_mngr} install ${line}"
				echo "Maybe the program ${line} is available in a package with different name."
			fi
		done <${script_path}/webapi_install_dep.tmp
		############################
	fi
fi
###REMOVE TMP FILE##########
rm ${script_path}/webapi_install_dep.tmp 2>/dev/null
if [ $error_detected = 0 ]
then
	### CHECK IF DIRECTORY-VARIABLE EMPTY #######
	if [ -n "${wwwpath}" ]
	then
		### CHECK IF DIRECTROY EXISTS ###############
		if [ -d "${wwwpath}" ]
		then
			### COPY WEBAPI.PHP TO WEBSERVER ROOT #######
			cp "${script_path}"/webapi.php "${wwwpath}"/webapi.php

			### WRITE PATH TO WEBAPI.PHP ################
			sed -i "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" "${wwwpath}"/webapi.php
			#############################################
			### TARGET ENVIRONMENT SPECIFIC TASKS #######
			#############################################

			### TERMUX ##################################
			is_termux=$(echo "${specific_env}"|grep -c "termux")
			if [ "${is_termux}" = 1 ]
			then
				termux-fix-shebang "${script_path}"/ucs_client.sh "${script_path}"/webapi.sh
			fi
			#############################################
		else
			### WRITE ERROR MESSAGE #####################
			echo "ERROR: the folder $wwwpath does not exist!"
		fi
	else
		### WRITE HELP MESSAGE ######################
		echo "ERROR:    You have to handover the path to www! See below example:"
		echo "          ./install_webapi.sh /var/www/html"
	fi
fi
###REMOVE TMP FILE##########
rm "${script_path}"/webapi_install_dep.tmp
