#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
print_message(){
		message="$1"
		if [ -n "${message}" ]
		then
			printf "%b" "${message}"|tee -a "${script_path}/install_client_${timestamp}.log"
		else
			if [ "${rt_query}" -eq 0 ]
			then
				printf "%s\n" "DONE"|tee -a "${script_path}/install_client_${timestamp}.log"
			else
				printf "%s\n" "FAILED"|tee -a "${script_path}/install_client_${timestamp}.log"
				error_counter=$(( error_counter + 1 ))
			fi
		fi
		rt_query=0
}

### SET VARIABLES ###########################
wwwpath=$1
specific_env=$2
timestamp=$(date -u +%Y%m%d_%H%M%S)
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "${0}")
error_counter=0

### CREATE TMP ##############
add_trap_command '[ -n "${install_dep:-}" ] && rm -f -- "${install_dep}"'
install_dep=$(mktemp "${script_path}/tmp/install_webapi.XXXXXX") || exit 1

###CHECK DEPENDENCIES#######
while read program
do
	###CHECK IF PROGRAMM IS UNKNOWN####
        type "${program}" >/dev/null
        rt_query=$?
        if [ "${rt_query}" -gt 0 ]
        then
                echo "${program}" >>"${install_dep}"
        fi
done <"${script_path}"/control/webapi_install.dep
if [ -f "${install_dep}" ] && [ -s "${install_dep}" ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case "${specific_env}" in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				for pmgr in apk apt-get brew dnf pacman pkg pkg_add pkgin swinstall yum zypper
				do
					if [ -x "$(command -v "${pmgr}")" ]
					then
						pkg_mngr="${pmgr}";
					fi
				done
				if [ -z "${pkg_mngr}" ]
				then
					###IF PACKAGING MANAGER DETECTION FAILED####
					error_counter=1
					no_of_programs=$(wc -l <"${install_dep}")
					print_message "[${script_name}][ERROR][package] Couldn't detect the package management system used on this machine!\n"
					print_message "[${script_name}][ERROR][package] Found ${no_of_programs} programs that need to be installed:\n"
					awk -v script_name="${script_name}" '{print "[" script_name "][ERROR][package] -> " $1}' "${install_dep}"
					print_message "[${script_name}][ERROR][package] Install these programms first using your package management system and then run ${script_name} again.\n"
					############################################
				fi
				;;
	esac
	############################

	if [ -n "${pkg_mngr}" ] && [ "${error_counter}" -eq 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read program
		do
			print_message "[${script_name}][INFO] Trying to install ${program} using ${pkg_mngr}...\n"
			case "${pkg_mngr}" in
				"apk")		apk add "${program}" ;;
				"apt-get")	apt-get -y install "${program}" ;;
				"brew")		brew install "${program}" ;;
				"dnf")		dnf -y install "${program}" ;;
				"pacman")	pacman --noconfirm -S "${program}" ;;
				"pkg")		pkg install -y "${program}" ;;
				"pkg_add")	env BATCH=Yes pkg_add -I -D automated "${program}" ;;
				"pkgin")	pkgin -y install "${program}" ;;
				"swinstall")	swinstall -x autoreboot=false "${program}" ;;
				"yum")		yum -y install "${program}" ;;
				"zypper")	zypper -n install "${program}" ;;
			esac
			rt_query=$?
			if [ "${rt_query}" -gt 0 ]
			then
				print_message "[${script_name}][ERROR][packages] Error during installation of ${program} using ${pkg_mngr}\n"
				print_message "[${script_name}][ERROR][packages] Maybe the program ${program} is available in a package with different name\n"
				error_counter=$(( error_counter + 1 ))
			fi
		done <"${install_dep}"
		############################
	fi
fi
if [ "${error_counter}" -eq 0 ]
then
	### CHECK IF DIRECTORY-VARIABLE EMPTY #######
	if [ -n "${wwwpath}" ]
	then
		### CHECK IF DIRECTROY EXISTS ###############
		if [ -d "${wwwpath}" ]
		then
			### CREATE TMP ##############
			add_trap_command '[ -n "${config_tmp:-}" ] && rm -f -- "${config_tmp}"'
			config_tmp=$(mktemp "${script_path}/tmp/install_webapi.XXXXXX") || exit 1

			### WRITE PATH TO WEBAPI.PHP ################
			rt_query=0
			print_message "[${script_name}][INFO] Write wallet install path to webapi.php..."
			sed "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" "${script_path}"/webapi.php >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/webapi.php || rt_query=1
			print_message

			### COPY WEBAPI.PHP TO WEBSERVER ROOT #######
			rt_query=0
			print_message "[${script_name}][INFO] Copy webapi.php to ->\"${wwwpath}\"..."
			cp "${script_path}"/webapi.php "${wwwpath}"/webapi.php || rt_query=1
			print_message

			#############################################
			### TARGET ENVIRONMENT SPECIFIC TASKS #######
			#############################################

			### TERMUX ##################################
			is_termux=$(echo "${specific_env}"|grep -c "termux")
			if [ "${is_termux}" -eq 1 ]
			then
				rt_query=0
				print_message "[${script_name}][INFO] termux-fix-shebang ucs_client.sh and webwapi.sh..."
				termux-fix-shebang "${script_path}"/ucs_client.sh "${script_path}"/webapi.sh || rt_query=1
				print_message
			fi
		else
			### WRITE ERROR MESSAGE #####################
			print_message "[${script_name}][ERROR] Directory \"${wwwpath}\" does not exist!\n"
			error_counter=1
		fi
	else
		### WRITE HELP MESSAGE ######################
		print_message "[${script_name}][ERROR] missing path to www root directory! example: ./install_webwallet.sh /var/www/html\n"
		error_counter=1
	fi
fi
### DISPLAY OUTPUT #######################
print_message "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})\n"
