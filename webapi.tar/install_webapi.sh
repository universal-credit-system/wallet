#!/bin/sh

### ASSIGN VARIABLES ########################
wwwpath=$1
targetenv=$2

### GET SCRIPT PATH #########################
script_path=$(dirname $(readlink -f "${0}"))

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

###CHECK DEPENDENCIES#######
while read line
do
	###CHECK IF PROGRAMM IS UNKNOWN####
        type "$line" >/dev/null
        rt_query=$?
        if [ $rt_query -gt 0 ]
        then
                echo "$line" >>"${script_path}"/webapi_install_dep.tmp
        fi
done <"${script_path}"/control/webapi_install.dep
if [ ! -s "${script_path}"/webapi_install_dep.tmp ]
then
	### CHECK IF DIRECTORY-VARIABLE EMPTY #######
	if [ -n "${wwwpath}" ]
	then
		### CHECK IF DIRECTROY EXISTS ###############
		if [ -d "${wwwpath}" ]
		then
			### COPY WEBAPI.PHP TO WEBSERVER ROOT #######
			cp "${script_path}"/webapi.php "${wwwpath}"/webapi.php

			### WRITE PATH TO WEBAPI.PHP ################
			sed -i "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" "${wwwpath}"/webapi.php
			#############################################
			### TARGET ENVIRONMENT SPECIFIC TASKS #######
			#############################################

			### TERMUX ##################################
			is_termux=$(echo "${targetenv}"|grep -c "termux")
			if [ "${is_termux}" = 1 ]
			then
				termux-fix-shebang "${script_path}"/ucs_client.sh "${script_path}"/webapi.sh
			fi
			#############################################
		else
			### WRITE ERROR MESSAGE #####################
			echo "ERROR: the folder $wwwpath does not exist!"
		fi
	else
		### WRITE HELP MESSAGE ######################
		echo "ERROR:    You have to handover the path to www! See below example:"
		echo "          ./install_webapi.sh /var/www/html"
	fi
else
	###DISPLAY APPS TO INSTALL##
	no_of_programs=$(wc -l <"${script_path}"/webapi_install_dep.tmp)
        echo "Found ${no_of_programs} program(s) that need to be installed:"
        cat "${script_path}"/webapi_install_dep.tmp
	echo "Install these programms first, then run install_webapi.sh again."

	###REMOVE TMP FILE##########
        rm "${script_path}"/webapi_install_dep.tmp
fi
