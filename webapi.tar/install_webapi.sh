#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
print_message(){
		if [ "$rt_query" -eq 0 ]
		then
			printf "%b" "DONE\n"
		else
			printf "%b" "FAILED\n"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}

### SET VARIABLES ###########################
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "${0}")
my_pid=$$
wwwpath=$1
specific_env=$2
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')
error_counter=0

### CREATE TMP ##############
add_trap_command '[ -n "${install_dep:-}" ] && rm -f -- "${install_dep}"'
install_dep=$(mktemp "${script_path}/tmp/install_webapi_dep.XXXXXX") || exit 1

###CHECK DEPENDENCIES#######
while read program
do
	###CHECK IF PROGRAMM IS UNKNOWN####
        type "${program}" >/dev/null
        rt_query=$?
        if [ "${rt_query}" -gt 0 ]
        then
                echo "${program}" >>"${install_dep}"
        fi
done <"${script_path}"/control/webapi_install.dep
if [ -f "${install_dep}" ] && [ -s "${install_dep}" ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case "${specific_env}" in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				for pmgr in apk apt-get dnf pacman pkg yum zipper
				do
					if [ -x "$(command -v "${pmgr}")" ]
					then
						pkg_mngr="${pmgr}";
					fi
				done
				if [ -z "${pkg_mngr}" ]
				then
					###IF PACKAGING MANAGER DETECTION FAILED####
					error_counter=1
					no_of_programs=$(wc -l <"${install_dep}")
					printf "%b" "[ ERROR ][package] Couldn't detect the package management system used on this machine!\n"
					printf "%b" "[ ERROR ][package] Found ${no_of_programs} programs that need to be installed:\n"
					awk '{print "[ ERROR ][package] -> " $1}' ${install_dep}
					printf "%b" "[ ERROR ][package] Install these programms first using your package management system and then run install_webapi.sh again.\n"
					############################################
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ "${error_counter}" -eq 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read program
		do
			printf "%b" "[ INFO ] Trying to install ${program} using ${pkg_mngr}...\n"
			case "${pkg_mngr}" in
				"apk")		apk add "${program}" ;;
				"apt-get")	apt-get -y install "${program}" ;;
				"dnf")		dnf -y install "${program}" ;;
				"pacman")	pacman --noconfirm -S "${program}" ;;
				"pkg")		pkg install -y "${program}" ;;
				"yum")		yum -y install "${program}" ;;
				"zypper")	zypper -n install "${program}" ;;
			esac
			rt_query=$?
			if [ "${rt_query}" -gt 0 ]
			then
				printf "%b" "[ ERROR ] Error running the following command: ${pkg_mngr} install ${program}\n"
				printf "%b" "[ ERROR ] Maybe the program ${program} is available in a package with different name.\n"
				error_counter=$(( error_counter + 1 ))
			fi
		done <"${install_dep}"
		############################
	fi
fi
if [ "${error_counter}" -eq 0 ]
then
	### CHECK IF DIRECTORY-VARIABLE EMPTY #######
	if [ -n "${wwwpath}" ]
	then
		### CHECK IF DIRECTROY EXISTS ###############
		if [ -d "${wwwpath}" ]
		then
			### WRITE PATH TO WEBAPI.PHP ################
			rt_query=0
			printf "%b" "[ INFO ] Write wallet install path to wepapi.php..."
			sed -i."${my_pid}".bak "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" "${script_path}"/webapi.php && rm "${script_path}"/webapi.php."${my_pid}".bak 2>/dev/null || rt_query=1
			print_message
			
			### COPY WEBAPI.PHP TO WEBSERVER ROOT #######
			rt_query=0
			printf "%b" "[ INFO ] Copy webapi.php to ->${wwwpath}..."
			cp "${script_path}"/webapi.php "${wwwpath}"/webapi.php || rt_query=1
			print_message
	
			#############################################
			### TARGET ENVIRONMENT SPECIFIC TASKS #######
			#############################################

			### TERMUX ##################################
			is_termux=$(echo "${specific_env}"|grep -c "termux")
			if [ "${is_termux}" -eq 1 ]
			then
				rt_query=0
				printf "%b" "[ INFO ] termux-fix-shebang ucs_client.sh and webwapi.sh..."
				termux-fix-shebang "${script_path}"/ucs_client.sh "${script_path}"/webapi.sh || rt_query=1
				print_message
			fi
		else
			### WRITE ERROR MESSAGE #####################
			printf "%b" "[ ERROR ] the folder $wwwpath does not exist!\n"
			error_counter=1
		fi
	else
		### WRITE HELP MESSAGE ######################
		printf "%b" "[ ERROR ] You have to handover the path to www root: ./install_webapi.sh /var/www/html\n"
		error_counter=1
	fi
fi
### DISPLAY OUTPUT #######################
printf "%b" "[ INFO ] $script_name finished (errors:$error_counter)\n"

