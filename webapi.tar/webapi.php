<?php
function push_download($file_output) {
	$file = str_replace(array("\n"), '', $file_output);
	if (file_exists($file)) {
		$filesize = filesize($file);
		header('Content-Description: WebAPI File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename="'.basename($file).'"');
		header('Expires: 0');
		header('Cache-Control: no-cache');
		header('Content-Length: ' . filesize($file));
		readfile($file);
		unlink($file);
		exit();
	} else {
		global $wallet_path;
		$output = shell_exec('echo "-action print_status -purpose 500"|'.$wallet_path.'/webapi.sh');
		echo "$output";
	}
}
function print_status($status_code) {
	global $wallet_path;
	$output = shell_exec('echo "-action print_status -purpose "'.$status_code.'""|'.$wallet_path.'/webapi.sh');
	echo "$output";
}
$wallet_path = "<<WALLET_INSTALL_PATH>>";
$target_dir = $wallet_path."/webapi/tmp/";
$upload_max_size = 500000;
$ipaddr = $_SERVER['REMOTE_ADDR'];
header('Content-Description: WebAPI Response');
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if ($_SERVER["CONTENT_TYPE"] === 'application/json') {
		$raw_request = file_get_contents('php://input');
		$request = json_decode($raw_request, true);
		if (!is_null($request)) {
			if (isset($request['session_id'])) {
				$session_id = preg_replace("/[^A-Za-z0-9]/", "", $request['session_id']);
			} else {
				$session_id = '';
			}
			if (isset($request['session_key'])) {
				$session_key = preg_replace("/[^A-Za-z0-9]/", "", $request['session_key']);
			} else {
				$session_key = '';
			}
			if (isset($request['action'])) {
				$action = preg_replace("/[^A-Za-z0-9_]/", "", $request['action']);
				switch ($action)
				{
					case 'check_name';
						if (isset($request['name'])) {
							$uname = preg_replace("/[^A-Za-z0-9]/", "", $request['name']);
							$output = shell_exec('echo "-action "'.$action.'" -user "'.$uname.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'create_account';
						if (isset($request['name'])) {
							$uname = preg_replace("/[^A-Za-z0-9]/", "", $request['name']);
						} else {
							$uname = '';
						}
						if (isset($request['pin'])) {
							$pin = preg_replace("/[^A-Za-z0-9]/", "", $request['pin']);
						} else {
							$pin = '';
						}
						if (isset($request['password'])) {
							$password = preg_replace("/[^A-Za-z0-9]/", "", $request['password']);
						} else {
							$password = '';
						}
						if (isset($request['multi_signature'])) {
		                                        $multi_signature = '';
		                                        $multi_sig_count = count($request['multi_signature']);
		                                        for($i=0;$i<$multi_sig_count;$i++)
		                                        {
		        					$multi_signature_checked = preg_replace("/[^A-Za-z0-9]/", "", $request['multi_signature'][$i]);
		                                                $multi_signature .= "$multi_signature_checked\n";
		                                        }
		                                } else {
		                                        $multi_signature = '';
		                                }
		                                $tmp_id = uniqid();
						$file_multi_sig = $wallet_path."/webapi/tmp/multi_sig".$tmp_id.".tmp";
						file_put_contents($file_multi_sig,$multi_signature);
						$output = shell_exec('echo "-action "'.$action.'" -user "'.$uname.'" -pin "'.$pin.'" -password "'.$password.'" -ip "'.$ipaddr.'" -file "'.$file_multi_sig.'""|'.$wallet_path.'/webapi.sh');
						echo "$output";
						unlink($file_multi_sig);
						break;
					case 'create_asset';
						if (isset($request['asset_description']) && isset($request['asset_fungible']) && isset($request['asset_name']) && isset($request['asset_quantity']) && isset($request['asset_owner']) && isset($request['asset_symbol']) || isset($request['asset_description']) && isset($request['asset_fungible']) && isset($request['asset_name']) && isset($request['asset_price']) && isset($request['asset_symbol'])) {
							$asset_description = preg_replace("/[^A-Za-z0-9%+]/", "", $request['asset_description']);
							$asset_description = preg_replace("/[+]/", "%20", $asset_description);
							$asset_fungible = preg_replace("/[^A-Za-z0-9]/", "", $request['asset_fungible']);
							$asset_name = preg_replace("/[^A-Za-z0-9\s]/", "", $request['asset_name']);
							$asset_symbol = preg_replace("/[^A-Za-z0-9]/", "", $request['asset_symbol']);
							$asset_string = 'asset_name="'.$asset_name.'"\n';
							$asset_string .= 'asset_fungible="'.$asset_fungible.'"\n';
							if (isset($request['asset_quantity'])) {
								$asset_quantity = preg_replace("/[^A-Za-z0-9.,]/", "", $request['asset_quantity']);
								$asset_quantity = preg_replace("/[,]/", ".", $asset_quantity);
								$asset_string .= 'asset_quantity='.$asset_quantity.'\n';
								$asset_owner = preg_replace("/[^A-Za-z0-9]/", "", $request['asset_owner']);
								$asset_string .= 'asset_owner="'.$asset_owner.'"\n';
							} else {
								$asset_price = preg_replace("/[^A-Za-z0-9.,]/", "", $request['asset_price']);
								$asset_price = preg_replace("/[,]/", ".", $asset_price);
								$asset_string .= 'asset_price='.$asset_price.'\n';
							}
							$asset_string .= 'asset_description="'.$asset_description.'"\n';
							$asset_string .= 'asset_symbol="'.$asset_symbol.'"\n';
							$tmp_id = uniqid();
							$file = $wallet_path."/webapi/tmp/asset_".$tmp_id.".tmp";
							file_put_contents($file,$asset_string);
							$output = shell_exec('echo "-action "'.$action.'" -path "'.$file.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
							unlink($file);
						} else {
							print_status(400);
						}
						break;
					case 'create_trx';
						if (isset($request['session_id']) && isset($request['session_key']) && isset($request['amount']) && isset($request['receiver'])) {
							$amount = preg_replace("/[^0-9.,]/", "", $request['amount']);
							$receiver = preg_replace("/[^A-Za-z0-9.]/", "", $request['receiver']);
							if (isset($request['asset'])) {
								$asset = preg_replace("/[^A-Za-z0-9.]/", "", $request['asset']);
							} else {
								$asset = '';
							}
							if (isset($request['message_type'])) {
							$message_type = preg_replace("/[^A-Za-z0-9]/", "", $request['message_type']);
							} else {
								$message_type = '100';
							}
							if (isset($request['multi_signature'])) {
                                                                $multi_signature = '';
                                                                $multi_sig_count = count($request['multi_signature']);
                                                                for($i=0;$i<$multi_sig_count;$i++)
                                                                {
                                					$multi_signature_checked = preg_replace("/[^A-Za-z0-9]/", "", $request['multi_signature'][$i]);
                                                                        $multi_signature .= "$multi_signature_checked\n";
                                                                }
                                                        } else {
                                                                $multi_signature = '';
                                                        }
							if (isset($request['purpose'])) {
								$purpose = $request['purpose'];
							} else {
								$purpose = '';
							}
							$tmp_id = uniqid();
							$file_multi_sig = $wallet_path."/webapi/tmp/multi_sig".$tmp_id.".tmp";
							file_put_contents($file_multi_sig,$multi_signature);
							$purpose = urlencode($purpose);
							$tmp_id = uniqid();
							$file_purpose = $wallet_path."/webapi/tmp/encoded_purpose_".$tmp_id.".tmp";
							file_put_contents($file_purpose,$purpose);
							$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'" -asset "'.$asset.'" -message_type "'.$message_type.'" -amount "'.$amount.'" -receiver "'.$receiver.'" -path "'.$file_purpose.'" -file "'.$file_multi_sig.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
							unlink($file_multi_sig);
							unlink($file_purpose);
						} else {
							print_status(500);
						}
						break;
					case 'decline_trx';
						if (isset($request['session_id']) && isset($request['session_key']) && isset($request['trx_file'])) {
							if (isset($request['trx_file'])) {
								$trxfile = preg_replace("/[^A-Za-z0-9]/", "", $request['trx_file']);
							}
							$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'" -path "'.$trxfile.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'delete_account';
						if (isset($request['session_id']) && isset($request['session_key'])) {
							$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'download_account';
						if (isset($request['session_id']) && isset($request['session_key'])) {
							$output_array = [];
							$return_code = true;
							exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh', $output_array, $return_code);
							switch($return_code)
							{
								case '0';
									$file_output = $output_array[0];
									push_download($file_output);
									break;
								case '1';
									print_status(500);
									break;
								case '2';
									print_status(401);
									break;
								case '3';
									print_status(403);
									break;
								default ;
									print_status(500);
									break;
							}
						} else {
							print_status(400);
						}
						break;
					case 'download_purpose';
						if (isset($request['session_id']) && isset($request['session_key']) && isset($request['path'])) {
							$path = $request['path'];
							$output_array = [];
							$return_code = true;
							exec('echo "-action "'.$action.'" -path "'.$path.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh', $output_array, $return_code);
							switch($return_code)
							{
								case '0';
									$file_output = $output_array[0];
									push_download($file_output);
									break;
								case '1';
									print_status(500);
									break;
								case '2';
									print_status(500);
									break;
								case '3';
									print_status(400);
									break;
								case '4';
									print_status(401);
									break;
								case '5';
									print_status(400);
									break;
								case '6';
									print_status(400);
									break;
								case '7';
									print_status(403);
									break;
								default ;
									print_status(500);
									break;
							}
						} else {
							print_status(400);
						}
						break;
					case 'download_sync';
						if (isset($request['session_id']) && isset($request['session_key'])) {
							$output_array = [];
							$return_code = true;
							exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh', $output_array, $return_code);
							switch($return_code)
							{
								case '0';
									$file_output = $output_array[0];
									push_download($file_output);
									break;
								case '1';
									print_status(500);
									break;
								case '2';
									print_status(401);
									break;
								case '3';
									print_status(403);
									break;
								default ;
									print_status(500);
									break;
							}
						} else {
							print_status(400);
						}
						break;
					case 'list_assets';
						$output = shell_exec('echo "-action "'.$action.'""|'.$wallet_path.'/webapi.sh');
						echo "$output";
						break;
					case 'list_trx';
						$output = shell_exec('echo "-action "'.$action.'""|'.$wallet_path.'/webapi.sh');
						echo "$output";
						break;
					case 'login_account';
						if (isset($request['name']) && isset($request['pin']) && isset($request['password'])) {
							$uname = preg_replace("/[^A-Za-z0-9]/", "", $request['name']);
							$pin = preg_replace("/[^A-Za-z0-9]/", "", $request['pin']);
							$password = preg_replace("/[^A-Za-z0-9]/", "", $request['password']);
							$output = shell_exec('echo "-action "'.$action.'" -user "'.$uname.'" -pin "'.$pin.'" -password "'.$password.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} elseif (isset($request['address']) && isset($request['password'])){
							$address = preg_replace("/[^A-Za-z0-9]/", "", $request['address']);
							$password = preg_replace("/[^A-Za-z0-9]/", "", $request['password']);
							$output = shell_exec('echo "-action "'.$action.'" -sender "'.$address.'" -password "'.$password.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'logout_account';
						if (isset($request['session_id']) && isset($request['session_key'])) {
							$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'show_addressbook';
						$output = shell_exec('echo "-action "'.$action.'""|'.$wallet_path.'/webapi.sh');
						echo "$output";
						break;
					case 'show_asset';
						if (isset($request['asset'])) {
							$asset = $request['asset'];
							$output = shell_exec('echo "-action "'.$action.'" -asset "'.$asset.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'show_balance';
						if (isset($request['name']) && isset($request['pin']) || isset($request['address']) || isset($request['session_id']) && isset($request['session_key'])) {
							if (isset($request['name']) && isset($request['pin'])) {
								$uname = preg_replace("/[^A-Za-z0-9]/", "", $request['name']);
								$pin = preg_replace("/[^A-Za-z0-9]/", "", $request['pin']);
							} else {
								$uname = '';
								$pin = '';
							}
							if (isset($request['address'])) {
								$address = preg_replace("/[^A-Za-z0-9]/", "", $request['address']);
							} else {
								$address = '';
							}
							if (isset($request['asset'])) {
								$asset = preg_replace("/[^A-Za-z0-9]/", "", $request['asset']);
							} else {
								$asset = '';
							}
							if (isset($request['session_id'])) {
								$session_id = preg_replace("/[^A-Za-z0-9]/", "", $request['session_id']);
							} else {
								$session_id = '';
							}
							if (isset($request['session_key'])) {
								$session_key = preg_replace("/[^A-Za-z0-9]/", "", $request['session_key']);
							} else {
								$session_key = '';
							}
							$output = shell_exec('echo "-action "'.$action.'" -user "'.$uname.'" -pin "'.$pin.'" -sender "'.$address.'" -asset "'.$asset.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'show_msig_trx';
						if (isset($request['session_id']) && isset($request['session_key'])) {
							$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'show_stats';
						$output = shell_exec('echo "-action "'.$action.'""|'.$wallet_path.'/webapi.sh');
						echo "$output";
						break;
					case 'show_trx';
						if (isset($request['amount'])) {
							$amount = preg_replace("/[^A-Za-z0-9.,]/", "", $request['amount']);
						} else {
							$amount = '';
						}
						if (isset($request['asset'])) {
							$asset = preg_replace("/[^A-Za-z0-9.]/", "", $request['asset']);
						} else {
							$asset = '';
						}
						if (isset($request['message_type'])) {
							$message_type = preg_replace("/[^A-Za-z0-9]/", "", $request['message_type']);
						} else {
							$message_type = '100';
						}
						if (isset($request['sender'])) {
							$sender = preg_replace("/[^A-Za-z0-9]/", "", $request['sender']);
						} else {
							$sender = '';
						}
						if (isset($request['receiver'])) {
							$receiver = preg_replace("/[^A-Za-z0-9.]/", "", $request['receiver']);
						} else {
							$receiver = '';
						}
						if (isset($request['path'])) {
							$path = preg_replace("/[^A-Za-z0-9.]/", "", $request['path']);
						} else {
							$path = '';
						}
						$output = shell_exec('echo "-action "'.$action.'" -asset "'.$asset.'" -message_type "'.$message_type.'" -amount "'.$amount.'" -sender "'.$sender.'" -receiver "'.$receiver.'" -path "'.$path.'""|'.$wallet_path.'/webapi.sh');
						echo "$output";
						break;
					case 'show_version';
						$output = shell_exec('echo "-action "'.$action.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
						echo "$output";
						break;
					case 'sign_trx';
						if (isset($request['session_id']) && isset($request['session_key']) && isset($request['trx_file'])) {
							if (isset($request['trx_file'])) {
								$trxfile = preg_replace("/[^A-Za-z0-9]/", "", $request['trx_file']);
							}
							$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'" -path "'.$trxfile.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'sync_uca';
						if (isset($request['session_id']) && isset($request['session_key'])) {
							$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(400);
						}
						break;
					case 'update';
						$output = shell_exec('echo "-action "'.$action.'" -ip "'.$ipaddr.'""|'.$wallet_path.'/webapi.sh');
						echo "$output";
						break;
					default;
						print_status(400);
						break;
				}
			} else {
				print_status(400);
			}
		} else {
			print_status(400);
		}
	} else {
		if (isset($_POST['action']) && str_contains($_SERVER["CONTENT_TYPE"], 'multipart/form-data;')) {
			if (isset($_POST['session_id']) && isset($_POST['session_key']) && $_POST['action'] === 'upload') {
				$target_dir = $wallet_path."/webapi/tmp/";
				$session_id = preg_replace("/[^A-Za-z0-9]/", "", $_POST['session_id']);
				$session_key = preg_replace("/[^A-Za-z0-9]/", "", $_POST['session_key']);
				$fname = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
				$filetype = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
				$target_file = $target_dir.$fname.'.'.$filetype;
				if ($_FILES["file"]["size"] > $upload_max_size) {
					print_status(413);
				} else {
					if (file_exists($target_file)) {
						$id = 1;
						do {
							$target_file = $target_dir.$fname.'_'.$id.'.'.$filetype;
							$id++;
						} while(file_exists($target_file));
					}
					if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
						$filetype_ok = 0;
						switch ($filetype)
						{
							case 'trx';
								$action = 'read_trx';
								break;
							case 'sync';
								$action = 'read_sync';
								break;
							default;
								$filetype_ok = 1;
								break;
						}
						if($filetype_ok  == 0) {
							$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'" -path "'.$target_file.'""|'.$wallet_path.'/webapi.sh');
							echo "$output";
						} else {
							print_status(415);
						}
						unlink($target_file);
					} else {
						print_status(500);
					}
				}
			} else {
				print_status(400);
			}
		} else {
			print_status(400);
		}
	}
} else {
	print_status(400);
}
?>

