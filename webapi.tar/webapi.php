<?php
function push_download($file_output) {
	$file = str_replace(array("\n"), '', $file_output);
	if (file_exists($file)) {
		$filesize = filesize($file);
		header('Content-Description: WebAPI File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename="'.basename($file).'"');
		header('Expires: 0');
		header('Cache-Control: no-cache');
		header('Content-Length: ' . filesize($file));
		readfile($file);
		unlink($file);
		exit();
	} else {
		$output = shell_exec('echo "-action print_status -purpose 500"|<<WALLET_INSTALL_PATH>>/webapi.sh');
		echo "$output";
	}
}
function print_status($status_code) {
	$output = shell_exec('echo "-action print_status -purpose "'.$status_code.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
	echo "$output";
}
$target_dir = "<<WALLET_INSTALL_PATH>>/webapi/tmp/";
$upload_max_size = 500000;
$ipaddr = $_SERVER['REMOTE_ADDR'];
header('Content-Description: WebAPI Response');
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	switch($_SERVER["CONTENT_TYPE"])
	{
		case 'application/json';
			$raw_request = file_get_contents('php://input');
			$request = json_decode($raw_request, true);
			if (!is_null($request)) {
				if (isset($request['session_id'])) {
					$session_id = preg_replace("/[^A-Za-z0-9]/", "", $request['session_id']);
				} else {
					$session_id = '';
				}
				if (isset($request['session_key'])) {
					$session_key = preg_replace("/[^A-Za-z0-9]/", "", $request['session_key']);
				} else {
					$session_key = '';
				}
				if (isset($request['action'])) {
					$action = preg_replace("/[^A-Za-z0-9_]/", "", $request['action']);
					switch ($action)
					{	
						case 'check_name';
							if (isset($request['name'])) {
								$uname = preg_replace("/[^A-Za-z0-9]/", "", $request['name']);
								$output = shell_exec('echo "-action "'.$action.'" -user "'.$uname.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
								echo "$output";
							} else {
								print_status(400);
							}
							break;
						case 'create_account';
							if (isset($request['name'])) {
								$uname = preg_replace("/[^A-Za-z0-9]/", "", $request['name']);
							} else {
								$uname = '';
							}
							if (isset($request['pin'])) {
								$pin = preg_replace("/[^A-Za-z0-9]/", "", $request['pin']);
							} else {
								$pin = '';
							}
							if (isset($request['password'])) {
								$password = preg_replace("/[^A-Za-z0-9]/", "", $request['password']);
							} else {
								$password = '';
							}
							$output = shell_exec('echo "-action "'.$action.'" -user "'.$uname.'" -pin "'.$pin.'" -password "'.$password.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
							echo "$output";
							break;
						case 'create_trx';
							if (isset($request['session_id']) && isset($request['session_key']) && isset($request['amount']) && isset($request['receiver'])) {
								$amount = preg_replace("/[^0-9.]/", "", $request['amount']);
								$receiver = preg_replace("/[^A-Za-z0-9.]/", "", $request['receiver']);
								if (isset($request['asset'])) {
									$asset = preg_replace("/[^A-Za-z0-9.]/", "", $request['asset']);
								} else {
									$asset = '';
								}
								if (isset($request['purpose'])) {
									$purpose = $request['purpose'];
								} else {
									$purpose = '';
								}
								$purpose = urlencode($purpose);
								$tmp_id = uniqid();
								$file = "<<WALLET_INSTALL_PATH>>/webapi/tmp/encoded_purpose_".$tmp_id.".tmp";
								file_put_contents($file,$purpose);
								$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'" -asset "'.$asset.'" -amount "'.$amount.'" -receiver "'.$receiver.'" -path "'.$file.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
								echo "$output";
								unlink($file);
							} else {
								print_status(500);
							}
							break;
						case 'delete_account';
							if (isset($request['session_id']) && isset($request['session_key'])) {
								$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
								echo "$output";
							} else {
								print_status(400);
							}
							break;
						case 'download_account';
							if (isset($request['session_id']) && isset($request['session_key'])) {
								$output_array = [];
								$return_code = true;
								exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh', $output_array, $return_code);
								switch($return_code)
								{
									case '0';
										$file_output = $output_array[0];
										push_download($file_output);
										break;
									case '1';
										print_status(500);
										break;
									case '2';
										print_status(500);
										break;
									case '3';
										print_status(401);
										break;
									case '4';
										print_status(403);
										break;
									default ;
										print_status(500);
										break;
								}
							} else {
								print_status(400);
							}
							break;
						case 'download_purpose';
							if (isset($request['session_id']) && isset($request['session_key']) && isset($request['path'])) {
								$path = $request['path'];
								$output_array = [];
								$return_code = true;
								exec('echo "-action "'.$action.'" -path "'.$path.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh', $output_array, $return_code);
								switch($return_code)
								{
									case '0';
										$file_output = $output_array[0];
										push_download($file_output);
										break;
									case '1';
										print_status(500);
										break;
									case '2';
										print_status(500);
										break;
									case '3';
										print_status(400);
										break;
									case '4';
										print_status(400);
										break;
									case '5';
										print_status(401);
										break;
									case '6';
										print_status(400);
										break;
									case '7';
										print_status(400);
										break;
									case '8';
										print_status(403);
										break;
									default ;
										print_status(500);
										break;
								}
							} else {
								print_status(400);
							}
							break;
						case 'download_sync';
							if (isset($request['session_id']) && isset($request['session_key'])) {
								$output_array = [];
								$return_code = true;
								exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh', $output_array, $return_code);
								switch($return_code)
								{
									case '0';
										$file_output = $output_array[0];
										push_download($file_output);
										break;
									case '1';
										print_status(500);
										break;
									case '2';
										print_status(401);
										break;
									case '3';
										print_status(403);
										break;
									default ;
										print_status(500);
										break;
								}
							} else {
								print_status(400);
							}
							break;
						case 'login_account';
							if (isset($request['name']) && isset($request['pin']) && isset($request['password'])) {
								$uname = preg_replace("/[^A-Za-z0-9]/", "", $request['name']);
								$pin = preg_replace("/[^A-Za-z0-9]/", "", $request['pin']);
								$password = preg_replace("/[^A-Za-z0-9]/", "", $request['password']);
								$output = shell_exec('echo "-action "'.$action.'" -user "'.$uname.'" -pin "'.$pin.'" -password "'.$password.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
								echo "$output";
							} elseif (isset($request['address']) && isset($request['password'])){
								$address = preg_replace("/[^A-Za-z0-9]/", "", $request['address']);
								$password = preg_replace("/[^A-Za-z0-9]/", "", $request['password']);
								$output = shell_exec('echo "-action "'.$action.'" -sender "'.$address.'" -password "'.$password.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
								echo "$output";
							} else {	
								print_status(400);
							}
							break;
						case 'logout_account';
							if (isset($request['session_id']) && isset($request['session_key'])) {
								$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
								echo "$output";
							} else {
								print_status(400);
							}
							break;
						case 'show_addressbook';
							$output = shell_exec('echo "-action "'.$action.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
							echo "$output";
							break;
						case 'show_balance';
							if (isset($request['session_id']) && isset($request['session_key'])) {
								if (isset($request['asset'])) {
									$asset = preg_replace("/[^A-Za-z0-9]/", "", $request['asset']);
								} else {
									$asset = '';
								}
								$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -asset "'.$asset.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
								echo "$output";
							} else {
								print_status(400);
							}
							break;
						case 'show_stats';
							$output = shell_exec('echo "-action "'.$action.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
							echo "$output";
							break;
						case 'show_trx';
							if (isset($request['amount'])) {
								$amount = preg_replace("/[^A-Za-z0-9]/", "", $request['amount']);
							} else {
								$amount = '';
							}
							if (isset($request['asset'])) {
								$asset = preg_replace("/[^A-Za-z0-9]/", "", $request['asset']);
							} else {
								$asset = '';
							}
							if (isset($request['sender'])) {
								$sender = preg_replace("/[^A-Za-z0-9]/", "", $request['sender']);
							} else {
								$sender = '';
							}
							if (isset($request['receiver'])) {
								$receiver = preg_replace("/[^A-Za-z0-9]/", "", $request['receiver']);
							} else {
								$receiver = '';
							}
							if (isset($request['path'])) {	
								$path = preg_replace("/[^A-Za-z0-9.]/", "", $request['path']);
							} else {
								$path = '';
							}
							$output = shell_exec('echo "-action "'.$action.'" -asset "'.$asset.'" -amount "'.$amount.'" -sender "'.$sender.'" -receiver "'.$receiver.'" -path "'.$path.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
							echo "$output";
							break;
						case 'sync_uca';
							if (isset($request['session_id']) && isset($request['session_key'])) {
								$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
								echo "$output";
							} else {
								print_status(400);
							}
							break;
						default;
							print_status(400);
							break;
					}
				} else {
					print_status(400);
				}
			} else {
				print_status(400);
			}
			break;
		case 'multipart/form-data';
			if (isset($_POST['action'])) {
				if (isset($request['session_id']) && isset($request['session_key']) && $request['action'] === 'upload') {
					$fname = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
					$filetype = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
					$target_file = $target_dir.$fname.'.'.$filetype;
					if ($_FILES["file"]["size"] > $upload_max_size) {
						print_status(413);
					} else {
						if (file_exists($target_file)) {
							$id = 1;
							do {
								$target_file = $target_dir.$fname.'_'.$id.'.'.$filetype;
								$id++;
							} while(file_exists($target_file));
							if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
								$filetype_ok = 0;
								switch ($filetype)
								{
									case 'trx';
										$action = 'read_trx';
										break;
									case 'sync';
										$action = 'read_sync';
										break;
									default;
										$filetype_ok = 1;
										break;
								}		
								if($filetype_ok  == 0) {
									$output = shell_exec('echo "-action "'.$action.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -ip "'.$ipaddr.'" -path "'.$target_file.'""|<<WALLET_INSTALL_PATH>>/webapi.sh');
									echo "$output";
								} else {
									print_status(415);
								}
								unlink($target_file);
							} else {
								print_status(500);
							}
						} else {
							print_status(500);
						}
					}
				} else {
					print_status(400);
				}
			} else {
				print_status(400);
			}
			break;
		default;
			print_status(400);
			break;
	}
} else {
	print_status(400);
}
?>
