#!/bin/sh
show_balance(){
			### GET BALANCES #####################################
			out_var=$(echo "-action show_balance -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -asset ${cmd_asset}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null)
			rt_query=$?

			### RETURNCODE ######################################
			return ${rt_query}
}
check_session(){
		### SET RT_QUERY ############################################
		rt_query=1

		### GET NOW STAMP ###########################################
		now_stamp=$(date +%s)

		### CHECK IF VARIABLES ARE EMPTY ############################
		if [ -n "${cmd_session_id}" ] && [ -n "${cmd_session_key}" ] && [ -n "${cmd_ip_address}" ]
		then
			### CHECK IF SESSION FILE EXISTS ############################
			if [ -s "${script_path}/webapi/sessions/${cmd_session_id}.sid" ]
			then
				### TRY TO DECRYPT SESSION FILE #############################
				echo "${cmd_session_key}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${script_path}/webapi/tmp/${cmd_session_id}.sid" --decrypt "${script_path}/webapi/sessions/${cmd_session_id}.sid" 1>/dev/null 2>/dev/null
				rt_query=$?
				if [ "${rt_query}" -eq 0 ]
				then
					### CHECK IF SESSION IS TIMED OUT ###########################
					session_string=$(head -1 "${script_path}/webapi/tmp/${cmd_session_id}.sid")
					check_ip=${session_string%%,*}
					if [ "${check_ip}" = "${cmd_ip_address}" ]
					then
						### SET VARIABLES ###########################################
						session_string=${session_string#*,}
						session_stamp=${session_string%%,*}

						### REMOVE SID FILE #########################################
						rm -f -- "${script_path}/webapi/sessions/${cmd_session_id}.sid"

						### IF SESSION IS NOT EXPIRED ###############################
						if [ $(( now_stamp - session_stamp )) -le $(( minutes_logoff * 60 )) ]
						then
							### SET VARIABLES ###########################################
							session_string=${session_string#*,}
							cmd_user=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_pin=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_pw=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_sender=${session_string%%,*}
							
							### SECURE VARIABLES ########################################
							readonly cmd_user cmd_pin cmd_pw cmd_sender cmd_ip_address cmd_session_key cmd_session_id

							### RENEW STAMP #############################################
							echo "${cmd_ip_address},${now_stamp},${cmd_user},${cmd_pin},${cmd_pw},${cmd_sender}" >"${script_path}/webapi/tmp/${cmd_session_id}.sid"

							### ENCRYPT AND WRITE NEW SESSION FILE ######################
							echo "${cmd_session_key}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output "${script_path}/webapi/sessions/${cmd_session_id}.sid" --passphrase-fd 0 "${script_path}/webapi/tmp/${cmd_session_id}.sid" 2>/dev/null
							rt_query=$?
						else
							rt_query=1
						fi
					else
						rt_query=1
					fi
				fi
				rm -f -- "${script_path}/webapi/tmp/${cmd_session_id}.sid"
			fi
		fi
		if [ "${rt_query}" -gt 0 ]
		then
			### SET STATUS CODE ########################################
			status_code=401
		fi
		return ${rt_query}
}
create_session(){
		### SET RT_QUERY ############################################
		rt_query=1

		### CHECK IF IP_ADDRESS IS EMPTY ############################
		if [ -n "${cmd_ip_address}" ]
		then
			###TEST KEY BY ENCRYPTING A MESSAGE##########################
			echo "1" >"${script_path}/webapi/tmp/account_${my_pid}.tmp"
			echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --local-user "${cmd_sender}" -r "${cmd_sender}" --passphrase-fd 0 --pinentry-mode loopback --sign "${script_path}/webapi/tmp/account_${my_pid}.tmp" 1>/dev/null 2>/dev/null
			rt_query=$?
			if [ "${rt_query}" -eq 0 ]
			then
				###REMOVE ENCRYPTION SOURCE FILE#############################
				rm -f -- "${script_path}/webapi/tmp/account_${my_pid}.tmp"

				####TEST KEY BY DECRYPTING THE MESSAGE#######################
				gpg --batch --status-fd 1 --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --verify "${script_path}/webapi/tmp/account_${my_pid}.tmp.gpg" 2>/dev/null|grep -q -- "GOODSIG.*${cmd_sender}"
				rt_query=$?
			fi
			find "${script_path}"/webapi/tmp -type f -name "account_${my_pid}.*" -exec rm -f -- {} +
			if [ "${rt_query}" -eq 0 ]
			then
				### CREATE A SESSION ID #####################################
				session_id=$(basename --suffix=.sid "$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.sid -p "${script_path}"/webapi/sessions/)")

				### SET SESSION KEY #########################################
				session_key=$(head -c 100 /dev/urandom|tr -dc A-Za-z0-9|head -c 20|sha224sum)
				session_key=${session_key%% *}

				### GET CURRENT TIMESTAMP ###################################
				now_stamp=$(date +%s)

				### WRITE CREDENTIALS TO FILE################################
				echo "${cmd_ip_address},${now_stamp},${cmd_user},${cmd_pin},${cmd_pw},${cmd_sender}" >"${script_path}/webapi/tmp/${session_id}.tmp"

				### WRITE SID FILE ##########################################
				echo "${session_key}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output "${script_path}/webapi/tmp/${session_id}.sid" --passphrase-fd 0 "${script_path}/webapi/tmp/${session_id}.tmp" 2>/dev/null
				rt_query=$?
				if [ "${rt_query}" -eq 0 ]
				then
					### SET SESSION ID AND SESSION KEY ##########################
					cmd_session_id=${session_id}
					cmd_session_key=${session_key}
					
					### SECURE VARIABLES ########################################
					readonly cmd_user cmd_pin cmd_pw cmd_sender cmd_ip_address cmd_session_key cmd_session_id

					### MOVE SESSION FILE INTO SESSION FOLDER ###################
					mv -- "${script_path}/webapi/tmp/${session_id}.sid" "${script_path}/webapi/sessions/${session_id}.sid"
				else
					rm -f -- "${script_path}/webapi/sessions/${session_id}.sid"
				fi
				rm -f -- "${script_path}/webapi/tmp/${session_id}.tmp"
			else
				rt_query=1
			fi
		fi
		return ${rt_query}
}
get_address(){
		### SET RT_QUERY ############################################
		rt_query=1

		###IF CMD SENDER IS SET HAND OVER############################
		if [ -z "${cmd_sender}" ]
		then
			if  [ -n "${cmd_user}" ] && [ -n "${cmd_pin}" ]
			then
				###CREATE FIFO###############################################
				logon_fifo=$(mktemp -u "${script_path}"/webapi/tmp/logon.XXXXXXXXXX)
				mkfifo "${logon_fifo}"

				###WRITE LIST TO FIFO########################################
				find "${script_path}"/control/keys -maxdepth 1 -type f -name "*.sct"|awk -F/ '{print $NF}' > "${logon_fifo}" &
				
				###FOR EACH SECRET###########################################
				while IFS= read -r secret_file
				do
					###GET ADDRESS OF SECRET#####################################
					key_file=${secret_file%%.*}

					###IF CMD_SENDER NOT SET#####################################
					###CALCULATE ADDRESS#########################################
					random_secret=$(cat "${script_path}/control/keys/${secret_file}")
					key_login=$(echo "${cmd_user}_${random_secret}_${cmd_pin}"|sha224sum)
					key_login=${key_login%% *}
					key_login=$(echo "${key_login}_${cmd_pin}"|sha224sum)
					key_login=${key_login%% *}

					###IF ACCOUNT MATCHES########################################
					if [ "${key_file}" = "${key_login}" ]
					then
						cmd_sender=${key_file}
						rt_query=0
						break
					fi
				done <"${logon_fifo}"
				rm -f -- "${logon_fifo}"
			fi
		else
			rt_query=0
		fi

		### SET STATUS CODE ########################################
		if [ "${rt_query}" -gt 0 ]
		then
			status_code=400
		fi

		### RETURN IF FOUND #########################################
		return ${rt_query}
}
build_json(){
		### GET TOTAL LINES ###########################
		total_lines=$(echo "${out_var}"|wc -l)

		### GET PATTERN FOR FIRST ITEM ################
		entity_start=$(echo "${out_var}"|head -1)
		entity_start=${entity_start%%:*}
		entity_start=${entity_start%% *}

		if [ -n "${entity_start}" ]
		then
			### CALCULATE TOTAL NUMBER OF ENTITIES ########
			number_entities=$(echo "${out_var}"|grep -cFw -- "${entity_start}")
			number_last=$(( total_lines / number_entities ))

			### GET PATTERN FOR LAST ITEM #################
			entity_end=$(echo "${out_var}"|head -"${number_last}"|tail -1)
			entity_end=${entity_end%%:*}
			entity_end=${entity_end%% *}

			### BUILD JSON ################################
			json_object_end=""
			json_array_end=""
			json_array_placeh=""
			if [ "${number_entities}" -gt 1 ]
			then
				json_array_placeh="  "
				json_array_start="["
				json_array_end="${json_array_placeh}]\n"
			else
				json_array_start="{"
			fi
			json_body="  \"${cmd_action}\": ${json_array_start}\n"

			### SET INITAL VALUES OF COUNTER VARIABLES ####
			line_counter=0
			entity_counter=0
			end_reached=0

			### GO TROUGH OUTPUT LINE BY LINE #############
			while [ "${end_reached}" -eq 0 ]
			do
				### RAISE COUNTER #############################
				line_counter=$(( line_counter + 1 ))

				### EXTRACT LINE ##############################
				output_line=$(echo "${out_var}"|head -"${line_counter}"|tail -1)

				### GET KEY AND VALUE #########################
				key=${output_line%%:*}
				key=$(printf "%b" "${key}"|sed 's/ //g')
				value=${output_line#*:}
				if [ "$(echo "${output_line}"|grep -cF -- "${entity_start}")" -eq 1 ] && [ "${number_entities}" -gt 1 ]
				then
					json_body="${json_body}${json_array_placeh}  {\n"
				fi

				if [ ! "$(echo "${output_line}"|grep -cF -- "${entity_end}")" -eq 1 ]
				then
					### CHECK IF STRING OR NUMBER #################
					if [ "$(echo "${value}"|grep -c -- '[^0-9.,]')" -eq 0 ] && [ "$(echo "${value}"|grep -c -- "^0.")" -eq 0 ]
					then
						json_body="${json_body}${json_array_placeh}    \"${key}\": ${value},\n"
					else
						json_body="${json_body}${json_array_placeh}    \"${key}\": \"${value}\",\n"
					fi
				else
					entity_counter=$(( entity_counter + 1 ))
					if [ "${number_entities}" -gt 1 ] && [ "${entity_counter}" -lt "${number_entities}" ]
					then
						json_object_end=","
					else
						if [ "${number_entities}" -gt 1 ]
						then
							json_array_end="${json_array_placeh}],\n"
							json_object_end=""
						else
							json_object_end=","
						fi
					fi
					### CHECK IF STRING OR NUMBER #################
					if [ "$(echo "${value}"|grep -c -- '[^0-9.,]')" -eq 0 ] && [ "$(echo "${value}"|grep -c -- "^0.")" -eq 0 ]
					then
						json_body="${json_body}${json_array_placeh}    \"${key}\": ${value}\n${json_array_placeh}  }${json_object_end}\n"
					else
						json_body="${json_body}${json_array_placeh}    \"${key}\": \"${value}\"\n${json_array_placeh}  }${json_object_end}\n"
					fi
				fi
				if [ "${line_counter}" -eq "${total_lines}" ]
				then
					end_reached=1
				fi
			done
			out_json="${json_body}${json_array_end}"
		else
			out_json="  \"${cmd_action}\": {\n  },\n" 
		fi
}
print_json(){
		printf "%b" "{\n${out_json}  \"status\": {\n    \"status_code\": ${status_code}\n  }\n}\n"
}
### GET SCRIPT PATH ##################################
readonly script_path=$(cd "$(dirname "$0")" && pwd)

### SET DEFAULT VARIABLES ############################
max_failed_logons=0
minutes_to_watch=30
minutes_to_block=30
minutes_logoff=30
minutes_housekeeping=5
enable_create_account=1
enable_create_asset=1
enable_create_trx=1
enable_delete_account=1
enable_download_account=1
enable_download_purpose=1
enable_download_sync=1
enable_read_sync=1
enable_read_trx=1
enable_sign_trx=1
debug=0
trace=0
cmd_var=""
cmd_action=""
cmd_user=""
cmd_pin=""
cmd_pw=""
cmd_sender=""
cmd_receiver=""
cmd_amount=""
cmd_asset=""
cmd_message_type=100
cmd_purpose=""
cmd_path=""
cmd_file=""
cmd_session_id=""
cmd_session_key=""
cmd_ip_address=""

### SOURCE CONFIG FILE ###############################
. "${script_path}"/control/webapi.conf

### GET PID FOR TMP FILES ############################
my_pid=$$

### DEFINE DEFAULT HTTP RT CODE ######################
status_code=200

### DEFINE DEFAULT OUTPUT VARIABLE ###################
out_var=""
out_json=""

###CHECK FOR STDIN INPUT##############################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi

### CHECK IF GUI MODE OR CMD MODE AND ASSIGN VARIABLES ###
if [ $# -gt 0 ]
then
	### GO THROUGH PARAMETERS ONE BY ONE ##########################
	while [ $# -gt 0 ]
	do
		### GET TARGET VARIABLES ######################################
		case $1 in
			"-action")	cmd_var=$1
					;;
			"-user")	cmd_var=$1
					;;
			"-pin")		cmd_var=$1
					;;
			"-password")	cmd_var=$1
					;;
			"-sender")	cmd_var=$1
					;;
			"-receiver")	cmd_var=$1
					;;
			"-amount")	cmd_var=$1
					;;
			"-asset")	cmd_var=$1
					;;
			"-message_type")cmd_var=$1
					;;
			"-purpose")	cmd_var=$1
					;;
			"-path")	cmd_var=$1
					;;
			"-file")	cmd_var=$1
					;;
			"-session_id")	cmd_var=$1
					;;
			"-session_key")	cmd_var=$1
					;;
			"-ip")		cmd_var=$1
					;;
			"-debug")	set -v
					readonly debug=1
					;;
			"-trace")	set -x
					readonly trace=1
					;;
			"-help")	more "${script_path}"/control/webapi_HELP.txt
					exit 0
					;;
			*)		### SET TARGET VARIABLES ######################################
					case "${cmd_var}" in
						"-action")	cmd_action=$1
								;;
						"-user")	cmd_user=$1
								;;
						"-pin")		cmd_pin=$1
								;;
						"-password")	cmd_pw=$1
								;;
						"-sender")	cmd_sender=$1
								;;
						"-receiver")	cmd_receiver=$1
								;;
						"-amount")	cmd_amount=$1
								;;
						"-asset")	cmd_asset=$1
								;;
						"-message_type")cmd_message_type=$1
								;;
						"-purpose")	cmd_purpose=$1
								;;
						"-path")	cmd_path=$1
								;;
						"-file")	cmd_file=$1
								;;
						"-session_id")	cmd_session_id=$1
								;;
						"-session_key")	cmd_session_key=$1
								;;
						"-ip")		cmd_ip_address=$1
								;;
						*)		### SET STATUS CODE ########################################
								status_code=400

								### DISPLAY JSON RESPONSE ################################
								print_json
								exit
								;;
					esac
					cmd_var=""
					;;
		esac
		shift
	done

	### STEP INTO SCRIPT HOMEDIR #######################
	cd "${script_path}"/ || exit 2

	### CHECK USER ACTION ##############################
	case "${cmd_action}" in
		"check_name")		### CHECK USERNAME IS STILL AVAILABLE ######################
					if [ -n "${cmd_user}" ]
					then
						name_hash=$(echo "${cmd_user}"|sha224sum)
						name_hash=${name_hash%% *}
						already_there=$(grep -cFw -- "${name_hash}" "${script_path}"/control/accounts.db)

						### ANSWER IS FOR AJAX #####################################
						if [ "${already_there}" -eq 0 ]
						then
							### SET STATUS CODE ########################################
							status_code=200
						else
							### SET STATUS CODE ########################################
							status_code=208
						fi
					else
						### SET STATUS CODE ########################################
						status_code=400
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"create_account")	### IF ENABLED ############################################
					if [ "${enable_create_account}" -eq 1 ]
					then
						rt_query=0
						msig_string=""
						### IF MULTI-SIGNATURE WALLET #############################
						if [ -f "${cmd_file}" ] && [ -s "${cmd_file}" ]
						then
							### MULTI-SIGNATURE########################################
							counter=0
							while read line
							do
								user=${line}
								if [ "$(echo "${user}"|grep -c -- "[^a-zA-Z0-9]")" -eq 0 ] && [ "$(find "${script_path}"/keys -maxdepth 1 -type f|awk -F/ '{print $NF}'|grep -cFw -- "${user}")" -gt 0 ] && [ "${counter}" -lt 10 ]
								then
									msig_string="${msig_string}-msig ${user} "
									counter=$(( counter + 1 ))
								else
									rt_query=1
									break
								fi
							done <"${cmd_file}"
						fi
						if [ "${rt_query}" -eq 0 ]
						then
							### TRIGGER USER CREATION #################################
							out_var=$(echo "-action create_user -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw}${msig_string}"|./ucs_client.sh 2>/dev/null|sed -e 's/<//g' -e 's/>//g')
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### BUILDOBJECT ##########################################
								build_json

								### SET STATUS CODE ########################################
								status_code=201
							else
								### SET STATUS CODE ########################################
								status_code=500
							fi
						else
							### SET STATUS CODE ########################################
							status_code=400
						fi
					else
						### SET STATUS CODE ########################################
						status_code=403
					fi
					### DISPLAY JSON RESPONSE ##################################
					print_json
					;;
		"create_asset")		if [ "${enable_create_asset}" -eq 1 ]
					then
						if [ -f "${cmd_path}" ] && [ -s "${cmd_path}" ]
						then
							### EXTRACT DATA FROM FILE ####################################
							asset_file=$(basename "${cmd_path}")
							asset_data=$(cat "${script_path}/webapi/tmp/${asset_file}")
							asset_data=$(printf "%s" "${asset_data}"|grep -- "asset_*"|sed 's/\"//g')
							asset_description=$(echo "${asset_data}"|grep -F -- "asset_description")
							asset_description=${asset_description#*=}
							asset_symbol=$(echo "${asset_data}"|grep -F -- "asset_symbol")
							asset_symbol=${asset_symbol#*=}
							asset_stamp=${asset_file#*.}
							asset_price=$(echo "${asset_data}"|grep -F -- "asset_price"|sed 's/,/./g')
							asset_price=${asset_price#*=}
							asset_quantity=$(echo "${asset_data}"|grep -F -- "asset_quantity"|sed 's/,/./g')
							asset_quantity=${asset_quantity#*=}
							asset_fungible=$(echo "${asset_data}"|grep -F -- "asset_fungible")
							asset_fungible=${asset_fungible#*=}

							### CHECK IF VARIABLES ARE SET ################################
							if [ -n "${asset_description}" ] && [ -n "${asset_fungible}" ]
							then
								### CHECK FOR ALNUM CHARS AND SIZE ############################
								symbol_check=$(echo "${asset_symbol}"|grep -c -- '[^[:alnum:]]')
								symbol_size=${#asset_symbol}
								if [ "${symbol_check}" -eq 0 ] && [ "${symbol_size}" -le 10 ] && [ "${symbol_size}" -ge 1 ]
								then
									### CHECK IF FUNGIBLE VARIABLE SET CORRECTLY ##################
									if [ "${asset_fungible}" -eq 0 ] || [ "${asset_fungible}" -eq 1 ]
									then
										asset_owner_ok=0
										if [ "${asset_fungible}" -eq 0 ]
										then
											asset_owner=$(echo "${asset_data}"|grep -F -- "asset_owner")
											asset_owner=${asset_owner#*=}
											if [ -n "${asset_owner}" ]
											then
												test -f "${script_path}"/keys/"${asset_owner}"
												rt_query=$?
												if [ "${rt_query}" -eq 0 ] && [ -n "${asset_quantity}" ]
												then
													check_value=${asset_quantity}
													asset_owner_ok=1
												fi
											fi
										else
											if [ -n "${asset_price}" ]
											then
												check_value=${asset_price}
												asset_owner_ok=1
											fi
										fi
										if [ "${asset_owner_ok}" -eq 1 ]
										then
											### CHECK ASSET PRICE ###################################
											case "${check_value}" in
												*[!0-9.]*|*.*.*|.*|*.) 	asset_acknowledged=1 ;;
												*)			int=${check_value%%.*}
															frac=${check_value#*.}
															[ "${frac}" = "${check_value}" ] && frac=""
															[ ${#frac} -eq 9 ] && [ "$(echo "${int}.${frac} > 0"|bc)" -eq 1 ] && asset_acknowledged=0
															;;
											esac
											if [ "${asset_acknowledged}" -eq 0 ]
											then
												### SET STATUS CODE ########################################
												status_code=201

												### GET STAMP ##############################################
												now=$(date +%s)

												### WRITE ASSET ############################################
												printf "%b" "$(cat "${cmd_path}")"|grep -F -- "asset_"|grep -Fv -- "asset_symbol" >"${script_path}/assets/${asset_symbol}.${now}"
												out_var=$(echo "ASSET:assets/${asset_symbol}.${now}"|cat - "${script_path}/assets/${asset_symbol}.${now}"|sed -e 's/=/:/g' -e 's/\"//g')
											else
												### SET STATUS CODE ########################################
												status_code=400
											fi
										else
											### SET STATUS CODE ########################################
											status_code=400
										fi
									else
										### SET STATUS CODE ########################################
										status_code=400
									fi
								else
									### SET STATUS CODE ########################################
									status_code=400
								fi
							else
								### SET STATUS CODE ########################################
								status_code=400
							fi
						else
							### SET STATUS CODE ########################################
							status_code=500
						fi
					else
						### SET STATUS CODE ########################################
						status_code=403
					fi
					### BUILD OBJECT ##########################################
					build_json

					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"create_trx")		### IF ENABLED ############################################
					if [ "${enable_create_trx}" -eq 1 ]
					then
						### CHECK IF SESSION IS ACTIVE ############################
						check_session
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							if [ -e "${cmd_path}" ] && [ -e "${cmd_file}" ]
							then
								compliant=0
								rt_query=0
								msig_string=""
								### MULTI-SIGNATURE########################################
								counter=0
								while read line
								do
									user=${line}
									if [ "$(echo "${user}"|grep -c -- "[^a-zA-Z0-9]")" -eq 0 ] && [ "$(find "${script_path}"/keys -maxdepth 1 -type f|awk -F/ '{print $NF}'|grep -cFw -- "${user}")" -gt 0 ] && [ "${counter}" -lt 10 ]
									then
										msig_string="${msig_string}-msig ${user} "
										counter=$(( counter + 1 ))
									else
										compliant=1
										rt_query=1
										break
									fi
								done <"${cmd_file}"
								if [ "${rt_query}" -eq 0 ]
								then
									compliant=1
									### URLDECODE PURPOSE #####################################
									awk -niord '{printf RT?$0chr("0x"substr(RT,2)):$0}' RS=%.. "${cmd_path}" >"${script_path}/webapi/tmp/decoded_purpose_${my_pid}.tmp"
									rt_query=$?
									if [ "${rt_query}" -eq 0 ]
									then
										### CONVERT ###############################################
										dos2unix -f "${script_path}/webapi/tmp/decoded_purpose_${my_pid}.tmp" 2>/dev/null
										rt_query=$?
										if [ "${rt_query}" -eq 0 ]
										then
											### TRIGGER CLIENT ACTION #################################
											out_var=$(echo "-action create_trx -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -password ${cmd_pw} -asset ${cmd_asset} ${msig_string}-message_type ${cmd_message_type} -amount ${cmd_amount} -receiver ${cmd_receiver} -file ${script_path}/webapi/tmp/decoded_purpose_${my_pid}.tmp"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null)
											rt_query=$?
											if [ "${rt_query}" -eq 0 ]
											then
												compliant=0
												### BUILDOBJECT ##########################################
												build_json

												### SET STATUS CODE ########################################
												status_code=201
											fi
										fi
									fi
								fi
								if [ "${rt_query}" -gt 0 ]
								then
									if [ "${compliant}" -eq 0 ]
									then
										### SET STATUS CODE ########################################
										status_code=500
									else
										### SET STATUS CODE ########################################
										status_code=400
									fi
								fi
								### DELETE TMP FILE #######################################
								rm -f -- "${script_path}/webapi/tmp/decoded_purpose_${my_pid}.tmp"
							else
								### SET STATUS CODE ########################################
								status_code=400
							fi
						fi
					else
						### SET STATUS CODE ########################################
						status_code=403
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"decline_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						out_var=$(echo "-action decline -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null)
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### BUILDOBJECT ##########################################
							build_json
						else
							### SET STATUS CODE ########################################
							status_code=500
						fi
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"delete_account")	### IF ENABLED ############################################
					if [ "${enable_delete_account}" -eq 1 ]
					then
						### CHECK IF SESSION IS ACTIVE ############################
						check_session
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### REMOVE USER ENTRY FROM ACCOUNTS.DB ###################
							cmd_user_hash=$(echo "${cmd_user}"|sha224sum)
							cmd_user_hash=${cmd_user_hash%% *}
							if grep -q -- "${cmd_user_hash}" "${script_path}"/control/accounts.db
							then
								sed "/${cmd_user_hash}/d" "${script_path}"/control/accounts.db >"${script_path}"/control/accounts.db."${my_pid}".bak && mv -- "${script_path}"/control/accounts.db."${my_pid}".bak "${script_path}"/control/accounts.db
							fi

							### GET FINGERPRINT OF PRIVATE KEY #######################
							key_fp=$(gpg --no-default-keyring --keyring="${script_path}"/control/keyring.file --with-colons --list-keys "${cmd_sender}" 2>/dev/null|sed -n 's/^fpr:::::::::\([[:alnum:]]\+\):/\1/p')
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### DELETE PRIVATE KEY FROM KEYRING ######################
								gpg --batch --yes --no-default-keyring --keyring="${script_path}"/control/keyring.file --delete-secret-keys "${key_fp}" 2>/dev/null
								rt_query=$?
								if [ "${rt_query}" -eq 0 ]
								then
									### DELETE ################################################
									rm -f -- "${script_path}/control/keys/${cmd_sender}"
									rm -f -- "${script_path}/control/keys/${cmd_sender}.sct"
									rm -rf -- "${script_path}/userdata/${cmd_sender}"

									### DELETE SESSION ########################################
									rm -f -- "${script_path}/webapi/sessions/${cmd_session_id}.sid"
								else
									### SET STATUS CODE ########################################
									status_code=500
								fi
							else
								### SET STATUS CODE ########################################
								status_code=500
							fi
						fi
					else
						### SET STATUS CODE ########################################
						status_code=403
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"download_account")	### IF ENABLED ############################################
					if [ "${enable_download_account}" -eq 1 ]
					then
						### CHECK IF SESSION IS ACTIVE ############################
						check_session
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### PACK TAR FILE #########################################
							{
							printf "%s\n" "keys/${cmd_sender}" \
								"control/keys/${cmd_sender}" \
								"control/keys/${cmd_sender}".sct \
								"proofs/${cmd_sender}" \
								"userdata/${cmd_sender}"
							find trx/ -maxdepth 1 -type f -name "${cmd_sender}.*"
							}>"${script_path}/webapi/tmp/${cmd_sender}_profile.tmp"
							flock "${script_path}/userdata/${cmd_sender}" tar -czf "${script_path}/webapi/tmp/${cmd_sender}_profile.tar" -T "${script_path}/webapi/tmp/${cmd_sender}_profile.tmp" 2>/dev/null
							rt_query=$?
							###########################################################
							if [ "${rt_query}" -eq 0 ]
							then
								### HANDOVER FILE PATH TO TRIGGER DOWNLOAD ################
								echo "${script_path}/webapi/tmp/${cmd_sender}_profile.tar"
							else
								rt_query=1
							fi
							rm -f -- "${script_path}/webwallet/tmp/${cmd_sender}_profile.tmp"
						else
							rt_query=2
						fi
					else
						rt_query=3
					fi
					if [ "${rt_query}" -gt 0 ]
					then
						exit ${rt_query}
					fi
					;;
		"download_purpose")	### IF ENABLED ############################################
					if [ "${enable_download_purpose}" -eq 1 ]
					then
						### CHECK IF PATH IS SET ##################################
						if [ -n "${cmd_path}" ]
						then
							exist=1
							### CHECK IF PATH EXISTS ##################################
							if [ -s "${script_path}"/trx/"${cmd_path}" ] && [ -f "${script_path}/trx/${cmd_path}" ]
							then
								trx_file_path="${script_path}"/trx/"${cmd_path}"
							else
								if [ -s "${script_path}/${cmd_path}" ] && [ -f "${script_path}/${cmd_path}" ]
								then
									trx_file_path="${script_path}"/"${cmd_path}"
								else
									if [ -s "${cmd_path}" ] && [ -f "${cmd_path}" ]
									then
										trx_file_path="${cmd_path}"
									else
										exist=0
									fi
								fi
							fi
							if [ "${exist}" -eq 1 ]
							then
								### CHECK IF SESSION IS ACTIVE ############################
								check_session
								rt_query=$?
								if [ "${rt_query}" -eq 0 ]
								then
									### CHECK IF USER IS RECEIVER #############################
									is_own_trx=$(grep -c -- "RCVR:${cmd_sender}" "${trx_file_path}")
									if [ "${is_own_trx}" -eq 1 ]
									then
										### EXTRACT TRANSACTION DATA ##############################
										IFS='|' read -r purpose_key_start purpose_start purpose_end <<-EOF
										$(awk -F: '
											/^:PRPK:/ {prpk=NR}
											/^:PRPS:/ {prps=NR}
											/BEGIN PGP SIGNATURE/ {prpe=NR}
											END { printf "%s|%s|%s\n", prpk, prps, prpe }
										' "${trx_file_path}")
										EOF

										### EXTRACT PURPOSE KEY ###################################
										purpose_key_start=$(( purpose_key_start + 1 ))
										purpose_key_end=${purpose_start}
										purpose_key_end=$(( purpose_key_end - 1 ))
										purpose_key_encrypted=$(sed -n "${purpose_key_start},${purpose_key_end}p" "${trx_file_path}")

										### REBUILD PGP MESSAGE ###################################
										printf "%b" "-----BEGIN PGP MESSAGE-----\n\n${purpose_key_encrypted}\n-----END PGP MESSAGE-----\n"  >"${script_path}"/webapi/tmp/history_purpose_key_encrypted_${my_pid}.tmp
										echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${script_path}"/webapi/tmp/history_purpose_key_decrypted_${my_pid}.tmp --decrypt "${script_path}"/webapi/tmp/history_purpose_key_encrypted_${my_pid}.tmp 2>/dev/null
										rt_query=$?
										if [ "${rt_query}" -eq 0 ]
										then
											### EXTRACT PURPOSE #######################################
											purpose_key=$(cat "${script_path}/webapi/tmp/history_purpose_key_decrypted_${my_pid}.tmp")
											purpose_start=$(( purpose_start + 1 ))
											purpose_end=$(( purpose_end - 1 ))
											purpose_encrypted=$(sed -n "${purpose_start},${purpose_end}p" "${trx_file_path}")

											### REBUILD PGP MESSAGE ###################################
											printf "%b" "-----BEGIN PGP MESSAGE-----\n\n${purpose_encrypted}\n-----END PGP MESSAGE-----\n" >"${script_path}/webapi/tmp/history_purpose_encrypted_${my_pid}.tmp"
											file_name=$(basename "${trx_file_path}")
											echo "${purpose_key}"|gpg --batch --no-tty --pinentry-mode loopback --output "${script_path}/webapi/tmp/purpose_decrypted_${file_name}" --passphrase-fd 0 --decrypt "${script_path}/webapi/tmp/history_purpose_encrypted_${my_pid}.tmp" 2>/dev/null
											rt_query=$?
											if [ "${rt_query}" -eq 0 ]
											then
												### OUTPUT FILEPATH #######################################
												echo "${script_path}/webapi/tmp/purpose_decrypted_${file_name}"
											else
												rt_query=1
											fi
										else
											rt_query=2
										fi
										rm -f -- "${script_path}/webapi/tmp/history_purpose_key_decrypted_${my_pid}.tmp"
										rm -f -- "${script_path}/webapi/tmp/history_purpose_key_encrypted_${my_pid}.tmp"
										rm -f -- "${script_path}/webapi/tmp/history_purpose_encrypted_${my_pid}.tmp"
									else
										rt_query=3
									fi
								else
									rt_query=4
								fi
							else
								rt_query=5
							fi
						else
							rt_query=6
						fi
					else
						rt_query=7
					fi
					if [ "${rt_query}" -gt 0 ]
					then
						exit ${rt_query}
					fi
					;;
		"download_sync")	### IF ENABLED ############################################
					if [ "${enable_download_sync}" -eq 1 ]
					then
						### CHECK IF SESSION IS ACTIVE ############################
						check_session
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### TRIGGER CLIENT ACTION #################################
							syncfile=$(echo "-action create_sync -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -password ${cmd_pw} -type partial"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null|tail -1|cut -d ':' -f2)
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### HANDOVER PATH TO WEBAPI.PHP TO TRIGGER DOWNLOAD #######
								echo "${syncfile}"
							else
								rt_query=1
							fi
						else
							rt_query=2
						fi
					else
						rt_query=3
					fi
					if [ "${rt_query}" -gt 0 ]
					then
						exit ${rt_query}
					fi
					;;
		"list_assets")		### GET LIST OF ALL ASSETS #################################
					rt_query=0
					out_var=$(find "${script_path}"/assets -maxdepth 1 -type f|sort -t. -k2|awk '{ print "ASSET:" $1 }') || rt_query=1
					if [ "${rt_query}" -gt 0 ]
					then
						### EMPTY OUT_VAR ##########################################
						out_var=""

						### SET STATUS CODE ########################################
						status_code=500
					fi

					### BUILD OBJECT ##########################################
					build_json

					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"list_trx")		rt_query=0
					### GET LIST OF ALL TRX ###################################
					out_var=$(find "${script_path}"/trx -maxdepth 1 -type f|sort -t. -k2 -k3|awk -F/ '{print "TRX:" $NF}') || rt_query=1
					if [ "${rt_query}" -gt 0 ]
					then
						### EMPTY OUT_VAR ##########################################
						out_var=""

						### SET STATUS CODE ########################################
						status_code=500
					fi
					### BUILD OBJECT ##########################################
					build_json

					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"login_account")	### BUILD STRING TO IDENTIFY USER ##########################
					if [ -z "${cmd_sender}" ]
					then
						logger_var="${cmd_sender}"
					else
						logger_var="${cmd_user}"
					fi
					logger_string=$(echo "${cmd_ip_address}_${logger_var}"|sha224sum)
					logger_string=${logger_string%% *}

					### GET STAMP FOR SESSION LOGGER FILE EXTENSION ############
					now_stamp=$(date +%s)

					### DELETE ALL LOCKS OLDER THAN ############################
					find "${script_path}"/webapi/logger -maxdepth 1 -type f -mmin +"${minutes_to_block}" -exec rm -f -- {} + >/dev/null 2>/dev/null

					### DELETE ALL LOGGER FILES OLDER THAN #####################
					find "${script_path}"/webapi/logger/tmp -maxdepth 1 -type f -mmin +"${minutes_to_watch}" -exec rm -f -- {} + >/dev/null 2>/dev/null

					### GET NUMBER OF SESSION LOGGER FILES FOR THIS USER #######
					total_failed_logons=$(find "${script_path}"/webapi/logger/tmp -maxdepth 1 -type f -name "${logger_string}.*"|wc -l)
					if [ "${total_failed_logons}" -gt "${max_failed_logons}" ]
					then
						touch "${script_path}/webapi/logger/${logger_string}.${now_stamp}"
						find "${script_path}"/webapi/logger/tmp -maxdepth 1 -type f -name "${logger_string}.*" -exec rm -f -- {} +
					fi

					### CHECK IF USER IS LOCKED ################################
					rt_query=$(find "${script_path}"/webapi/logger -maxdepth 1 -type f -name "${logger_string}.*"|wc -l)
					if [ "${rt_query}" -eq 0 ]
					then
						### GET USER ADDRESS ######################################
						get_address
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### CREATE SESSION ########################################
							create_session
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### SHOW BALANCE ##########################################
								show_balance
								rt_query=$?
								if [ "${rt_query}" -eq 0 ]
								then
									### BUILD OBJECT ##########################################
									build_json

									### DELETE LOGGER SESSION FILES ###########################
									find "${script_path}"/webapi/logger/tmp -maxdepth 1 -type f -name "${logger_string}.*" -exec rm -f -- {} +

									### DISPLAY SESSION INFO ##################################
									out_json="${out_json}  \"session\": {\n"
									out_json="${out_json}    \"session_id\": \"${cmd_session_id}\",\n"
									out_json="${out_json}    \"session_key\": \"${cmd_session_key}\"\n"
									out_json="${out_json}  },\n"
								else
									### SET STATUS CODE ########################################
									status_code=500
								fi
							else
								### WRITE SESSION LOGGER FILE FOR FAILED LOGON ############
								touch "${script_path}/webapi/logger/tmp/${logger_string}.${now_stamp}"

								### SET STATUS CODE ########################################
								status_code=401
							fi
						else
							### SET STATUS CODE ########################################
							status_code=401
						fi
					else
						### SET STATUS CODE ########################################
						status_code=423
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"logout_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### REMOVE SESSION ########################################
						rm -f -- "${script_path}/webapi/sessions/${cmd_session_id}.sid"
					fi

					### DISPLAY JSON RESPONSE ################################
					print_json
					;;
		"print_status")		### SET STATUS CODE ########################################
					if [ -z "${cmd_purpose}" ]
					then
						status_code=400
					else
						status_code="${cmd_purpose}"
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"read_sync")		### IF ENABLED ############################################
					if [ "${enable_read_sync}" -eq 1 ]
					then
						### CHECK IF SESSION IS ACTIVE ############################
						check_session
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### TRIGGER CLIENT ACTION #################################
							out_var=$(echo "-action read_sync -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null)
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### BUILD OBJECT ##########################################
								build_json
							else
								### SET STATUS CODE ########################################
								status_code=500
							fi
						fi
					else
						### SET STATUS CODE ########################################
						status_code=403
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"read_trx")		### IF ENABLED ############################################
					if [ "${enable_read_trx}" -eq 1 ]
					then
						### CHECK IF SESSION IS ACTIVE ############################
						check_session
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### TRIGGER CLIENT ACTION #################################
							out_var=$(echo "-action read_trx -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null)
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### BUILD OBJECT ##########################################
								build_json
							else
								### SET STATUS CODE ########################################
								status_code=500
							fi
						fi
					else
						### SET STATUS CODE ########################################
						status_code=403
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"show_addressbook")	### CHECK IF SESSION IS ACTIVE ############################
					out_var=$(echo "-action show_addressbook"|./ucs_client.sh 2>/dev/null)
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### BUILD OBJECT ##########################################
						build_json
					else
						### SET STATUS CODE ########################################
						status_code=500
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"show_asset")		### LOOK FOR ASSET ########################################
					asset=$(find "${script_path}"/assets -maxdepth 1 -type f|awk -F/ '{print $NF}'|grep -cFw -- "${cmd_asset}")
					if [ -n "${asset}" ]
					then
						out_var=$(echo "ASSET:assets/${asset}"|cat - "${script_path}/assets/${asset}"|sed -e 's/=/:/g' -e 's/\"//g')
					else
						### SET STATUS CODE #######################################
						status_code=404
					fi
					### BUILD OBJECT ##########################################
					build_json

					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"show_balance")		rt_query=0
					if [ -n "${cmd_session_id}" ] && [ -n "${cmd_session_key}" ]
					then
						check_session
						rt_query=$?
					else
						get_address
						rt_query=$?
					fi
					if [ "${rt_query}" -eq 0 ]
					then
						### SHOW BALANCE ##########################################
						show_balance
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### BUILD OBJECT ##########################################
							build_json
						else
							### SET STATUS CODE ########################################
							status_code=500
						fi
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"show_msig_trx")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						out_var=$(echo "-action show_msig_trx -sender ${cmd_sender} -path ${cmd_path}"|./ucs_client.sh 2>/dev/null)
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### BUILD OBJECT ##########################################
							build_json
						else
							### SET STATUS CODE ########################################
							status_code=500
						fi
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"show_stats")		out_var=$(echo "-action show_stats"|./ucs_client.sh 2>/dev/null)
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### BUILD OBJECT ##########################################
						build_json
					else
						### SET STATUS CODE ########################################
						status_code=500
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"show_trx")		out_var=$(echo "-action show_trx -asset ${cmd_asset} -message_type ${cmd_message_type} -amount ${cmd_amount} -sender ${cmd_sender} -receiver ${cmd_receiver} -file ${cmd_path}"|./ucs_client.sh 2>/dev/null)
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### BUILD OBJECT ##########################################
						build_json
					else
						### SET STATUS CODE ########################################
						status_code=500
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"sign_trx")		### IF ENABLED ############################################
					if [ "${enable_sign_trx}" -eq 1 ]
					then
						### CHECK IF SESSION IS ACTIVE ############################
						check_session
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### TRIGGER CLIENT ACTION #################################
							out_var=$(echo "-action sign -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null)
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### BUILDOBJECT ##########################################
								build_json
							else
								### SET STATUS CODE ########################################
								status_code=500
							fi
						fi
					else
						### SET STATUS CODE ########################################
						status_code=403
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"sync_uca")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						out_var=$(echo "-action sync_uca -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -password ${cmd_pw}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null)
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### BUILD OBJECT ##########################################
							build_json
						else
							### SET STATUS CODE ########################################
							status_code=500
						fi
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"show_version")		out_var=$(./ucs_client.sh -version 2>/dev/null)
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### BUILD OBJECT ##########################################
						build_json
					else
						### SET STATUS CODE ########################################
						status_code=500
					fi
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		"update")		### IF AVAILABLE PERFORM GIT PULL #########################
					git pull >/dev/null 2>/dev/null
					rt_query=$?

					### CHECK RETURN CODES #####################################
					case "${rt_query}" in
						127)	### SET STATUS CODE ########################################
							status_code=404
							;;
						128)	### SET STATUS CODE ########################################
							status_code=501
							;;
						*)	if [ "${rt_query}" -gt 0 ]
							then
								### SET STATUS CODE ########################################
								status_code=500
							fi
							;;
					esac
					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
		*)			### SET STATUS CODE ########################################
					status_code=400

					### DISPLAY JSON RESPONSE #################################
					print_json
					;;
	esac

	### AUTO LOGOFF ################################################################################
	find "${script_path}"/webapi/sessions -maxdepth 1 -type f -mmin +"${minutes_logoff}" -exec rm -f -- {} +

	### DO HOUSEKEEPING AND DELETE ALL TMP SESSION FILES OLDER THAN 5 MINUTES ######################
	find "${script_path}"/webapi/tmp -maxdepth 1 -type f -mmin +"${minutes_housekeeping}" -exec rm -f -- {} +
else
	### SET STATUS CODE ########################################
	status_code=400

	### DISPLAY STATUS IN JSON ################################
	print_json
fi
