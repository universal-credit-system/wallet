#!/bin/sh
### CHECK FOR STDIN INPUT ##############################
if [ ! -t 0 ]
then
	### IF PARAMETERS VIA PIPED STDIN ######################
	set -- $(cat) "$@"
	
	### HANDOVER ###########################################
	request_string="$@"
else
	if [ "$#" -eq 0 ]
	then
		### IF NOT APPENDED READ STDIN #########################
		printf "%s" "ENTER JSON REQUEST :"
		read request_string
	else
		### IF APPENDED HANDOVER ###############################
		request_string="$@"
	fi
fi
### DISPLAY OUTPUT FOR REQUEST #################################
printf "%s\n" "Request :"

### FEED REQUEST TO JQ FOR CHECK AND PROPER FORMATTING #########
if echo "${request_string}"|jq
then
	### DISPLAY OUTPUT FOR RESPONSE ################################
	printf "%s\n" "Response :"
	
	### SEND REQUEST USING CURL ####################################
	curl -H "Content-Type: application/json" http://127.0.0.1:8080/webapi -d "${request_string}" --output -	
fi
