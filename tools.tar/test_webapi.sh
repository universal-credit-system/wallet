#!/bin/sh
### CHECK FOR STDIN INPUT ##############################
if [ ! -t 0 ]
then
	### IF PARAMETERS VIA PIPED STDIN ######################
	set -- $(cat) "$@"
	
	### HANDOVER ###########################################
	request_string="$@"
else
	if [ "$#" = 0 ]
	then
		### IF NOT APPENDED READ STDIN #########################
		printf "%b" "ENTER JSON REQUEST :"
		read request_string
	else
		### IF APPENDED HANDOVER ###############################
		request_string="$@"
	fi
fi
### DISPLAY OUTPUT FOR REQUEST #################################
printf "%b" "Request :\n"

### FEED REQUEST TO JQ FOR CHECK AND PROPER FORMATTING #########
rt_query=0
echo "${request_string}"|jq || rt_query=1
if [ $rt_query = 0 ]
then
	### DISPLAY OUTPUT FOR RESPONSE ################################
	printf "%b" "Response :\n"
	
	### SEND REQUEST USING CURL ####################################
	curl -H "Content-Type: application/json" http://127.0.0.1:8080/webapi -d "$request_string" --output -	
fi
