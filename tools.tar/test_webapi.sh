#!/bin/sh
###CHECK FOR STDIN INPUT##############################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
	request_string="$@"
else
	if [ "$#" = 0 ]
	then
		printf "%b" "ENTER JSON REQUEST :"
		read request_string
	else
		request_string="$@"
	fi
fi
printf "%b" "Request :\n"
echo "${request_string}"|jq
printf "%b" "Response :\n"
rt_query=$?
if [ $rt_query = 0 ]
then
	curl -H "Content-Type: application/json" http://127.0.0.1:8080/webapi -d "$request_string" --output -
fi
