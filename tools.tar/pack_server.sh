#!/bin/sh
print_message(){
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%s\n" "DONE"
		else
			printf "%s\n" "FAILED"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}
###SET VARIABLES###################
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "${0}")
copy_path=$(echo "${1}"|sed 's/\/$//g')

if [ -n "${copy_path}" ] && [ -d "${copy_path}" ]
then
	###CREATE TAR FILE#################
	printf "%s" "[${script_name}][INFO] Create tar file..."
	tar -cf server.tar log/ server/ control/server.conf uca.service controller.sh filewatch.sh logwatch.sh receiver.sh sender.sh start_server.sh stop_server.sh
	print_message
	if [ "${rt_query}" -eq 0 ]
	then
		if [ -n "${copy_path}" ] && [ -d "${copy_path}" ]
		then
			printf "%s" "[${script_name}][INFO] Copy tar file to \"${copy_path}\"..."
			cp -- server.tar "${copy_path}"/server.tar
			print_message
		fi
	fi
else
	printf "%s\n" "[${script_name}][ERROR] missing path! Example: ./${script_name} PATH"
fi
### DISPLAY OUTPUT #######################
printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})"
