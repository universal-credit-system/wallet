#!/bin/sh
copy_path=$(echo "${1}"|sed 's/\/$//g')
echo "[ INFO ] Create tar file..."
tar -cf server.tar log/ server/ control/server.conf uca.service controller.sh filewatch.sh logwatch.sh receiver.sh sender.sh start_server.sh stop_server.sh
rt_query=$?
if [ "${rt_query}" -eq 0 ]
then
	echo "[ INFO ] Tar file created..."
	if [ ! -z "${copy_path}" ] && [ -d "${copy_path}" ]
	then
		echo "[ INFO ] Copy tar file to ${copy_path}..."
		cp -- server.tar "${copy_path}"/server.tar
		rt_query=$?
		if [ "${rt_query}" -eq 0 ]
		then
		        echo "[ INFO ] File copied..."
                else
			echo "[ ERROR ] Could not copy file..."
                fi
        fi
else
	echo "[ ERROR ] Could not copy file..."
fi
echo "[ INFO ] EXIT (${rt_query})"
