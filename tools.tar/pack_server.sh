#!/bin/sh
copy_path=$1
echo "INFO: CREATE TAR-FILE..."
tar -cf server.tar log/ server/ control/server.conf uca.service controller.sh filewatch.sh logwatch.sh receiver.sh sender.sh start_server.sh stop_server.sh
rt_query=$?
if [ $rt_query = 0 ]
then
	echo "INFO: TAR-FILE SUCCESSFULLY CREATED..."
	if [ ! -z $copy_path -a -d $copy_path ]
	then
		echo "INFO: COPY ARCHIVE..."
		cp server.tar ${copy_path}/server.tar
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			echo "INFO: ARCHIVE SUCCESSFULLY COPIED..."
		else
			echo "ERROR: COULD NOT COPY ARCHIVE TO ${copy_path}!"
			rm server.tar
		fi
	else
		echo "ERROR: COULD NOT COPY ARCHIVE TO ${copy_path}!"
		rm server.tar
	fi
else
	echo "ERROR: COULD NOT CREATE ARCHIVE!"
fi
echo "INFO: EXIT (${rt_query})"
