#!/bin/sh
###GET VARIABLES########################
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")
script_option=$1
rt_query=0

###MAKE CLEAN START#####################
rm -f -- /data/data/com.termux/files/usr/var/log/php-fpm.log

###DISPLAY OUTPUT#######################
printf "%s\n" "${script_name}: $(date -u): start nginx and php-fpm..."

###START NGINX AND PHP-FPM##############
nginx && php-fpm || rt_query=1

if [ "${rt_query}" -eq 0 ]
then
	###DISPLAY OUTPUT#######################
	printf "%s\n" "${script_name}: $(date -u): nginx and php-fpm started"
	printf "%s\n" "${script_name}: $(date -u): IP_ADRESS is : $(ifconfig|grep "wlan" -A1|grep "inet"|awk '{print $2}')"

	###DISPLAY PHP LOG IF REQUIRED##########
	if printf "%s" "${script_option}"|grep -qF "debug"
	then
		###DISPLAY OUTPUT#######################
		printf "%s\n" "${script_name}: $(date -u): open php-fpm.log..."
		tail -f /data/data/com.termux/files/usr/var/log/php-fpm.log
	fi
else
	###DISPLAY OUTPUT#######################
	printf "%s\n" "${script_name}: $(date -u): error starting nginx & php-fpm! aborting..."
fi
###DISPLAY OUTPUT#######################
printf "%s\n" "${script_name}: $(date -u): bye bye"
