#!/bin/sh

###ASSIGN PARAMETER IF THERE############
script_option=$1

###MAKE CLEAN START#####################
rm /data/data/com.termux/files/usr/var/log/php-fpm.log 2>/dev/null

###DISPLAY OUTPUT#######################
printf "termux_webwallet_start.sh: $(date -u): start nginx and php-fpm...\n"

###START NGINX AND PHP-FPM##############
nginx && php-fpm

###DISPLAY OUTPUT#######################
printf "termux_webwallet_start.sh: $(date -u): nginx and php-fpm started\n"
printf "termux_webwallet_start.sh: $(date -u): IP_ADRESS is : $(ifconfig|grep "wlan" -A1|grep "inet"|awk '{print $2}')\n"

###DISPLAY PHP LOG IF REQUIRED##########
is_debug=`printf "${script_option}"|grep -c "debug"`
if [ $is_debug -gt 0 ]
then
	###DISPLAY OUTPUT#######################
	printf "termux_webwallet_start.sh: $(date -u): open php-fpm.log...\n"
	tail -f /data/data/com.termux/files/usr/var/log/php-fpm.log
fi

###DISPLAY OUTPUT#######################
printf "termux_webwallet_start.sh: $(date -u): bye bye\n"
