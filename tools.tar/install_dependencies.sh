#!/bin/sh

### SET VARIABLES ############
specific_env=$1
specific_env=$(echo "${specific_env}"|tr '[A-Z]' '[a-z]')
script_path=$(cd "$(dirname "$0")" && pwd)
error_detected=0

### CHECK DEPENDENCIES #######
while read program
do
	### CHECK IF PROGRAMM IS UNKNOWN ####
        type "${program}" >/dev/null 2>/dev/null
        rt_query=$?
        if [ "${rt_query}" -gt 0 ]
        then
        	### QUERY TO REPLACE COMMANDS WITH PACKAGE NAME ###########
        	case "${program}" in
        		"netcat")	echo "netcat-openbsd" >>"${script_path}"/tmp/install_dep.tmp
        				;;
        		"gpg")		echo "gnupg"  >>"${script_path}"/tmp/install_dep.tmp
        				;;
        		"openssl")	if [ "${specific_env}" = "termux" ]
        				then
        					echo "openssl-tool"  >>"${script_path}"/tmp/install_dep.tmp
        				else
        					echo "${program}"  >>"${script_path}"/tmp/install_dep.tmp
        				fi
        				;;
        		*)		echo "${program}"  >>"${script_path}"/tmp/install_dep.tmp
        				;;
        	esac
        fi
done <"${script_path}"/control/install.dep
if [ -f "${script_path}"/tmp/install_dep.tmp ] && [ -s "${script_path}"/tmp/install_dep.tmp ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case "${specific_env}" in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				for pmgr in apk apt-get dnf pacman pkg yum zipper
				do
					if [ -x "$(command -v "${pmgr}")" ]
					then
						pkg_mngr="${pmgr}";
					fi
				done
				if [ -z "${pkg_mngr}" ]
				then
					###IF PACKAGING MANAGER DETECTION FAILED####
					error_detected=1
					no_of_programs=$(wc -l <"${script_path}"/install_dep.tmp)
					echo "[ ERROR ] Couldn't detect the package management system used on this machine!"
					echo "[ ERROR ] Found ${no_of_programs} programs that need to be installed:"
					cat "${script_path}"/install_dep.tmp
					echo "[ ERROR ] Install these programms first using your package management system and then run install.sh again."
					error_detected=1
					############################################
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ]
	then
		### INSTALL MISSING PKGS #####
		while read program
		do
			printf "%b" "[ INFO ] Trying to install ${program} using ${pkg_mngr}...\n"
			case "${pkg_mngr}" in
				"apk")		apk add "${program}" ;;
				"apt-get")	apt-get -y install "${program}" ;;
				"dnf")		dnf -y install "${program}" ;;
				"pacman")	pacman --noconfirm -S "${program}" ;;
				"pkg")		pkg install -y "${program}" ;;
				"yum")		yum -y install "${program}" ;;
				"zypper")	zypper -n install "${program}" ;;
			esac
			rt_query=$?
			if [ "$rt_query" -gt 0 ]
			then
				echo "[ ERROR ] Error running the following command: ${pkg_mngr} install ${program}"
				echo "[ ERROR ] Maybe the program ${program} is available in a package with different name."
				error_detected=1
			fi
		done <"${script_path}"/tmp/install_dep.tmp
		############################
	fi
fi
###REMOVE TMP FILE##########
rm -f -- "${script_path}"/tmp/install_dep.tmp

### DISPLAY OUTPUT ##########
error_text="with errors"
if [ "${error_detected}" -eq 0 ]
then
	error_text="without errors"
fi
printf "%b" "[ INFO ] install_dependencies.sh finished $error_text. exiting...\n"
