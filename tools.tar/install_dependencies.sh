#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
### SET VARIABLES ############
specific_env=$1
specific_env=$(echo "${specific_env}"|tr '[A-Z]' '[a-z]')
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")
error_counter=0

### CREATE TMP ##############
add_trap_command '[ -n "${install_dep:-}" ] && rm -f -- "${install_dep}"'
install_dep=$(mktemp "${script_path}/install_dep.XXXXXX") || exit 1

### CHECK DEPENDENCIES #######
while read program
do
	### CHECK IF PROGRAMM IS UNKNOWN ####
        type "${program}" >/dev/null 2>/dev/null
        rt_query=$?
        if [ "${rt_query}" -gt 0 ]
        then
        	### QUERY TO REPLACE COMMANDS WITH PACKAGE NAME ###########
        	case "${program}" in
        		"netcat")	printf "%s\n" "netcat-openbsd" >>"${install_dep}"
        				;;
        		"gpg")		printf "%s\n" "gnupg"  >>"${install_dep}"
        				;;
        		"openssl")	if [ "${specific_env}" = "termux" ]
        				then
        					printf "%s\n" "openssl-tool"  >>"${install_dep}"
        				else
        					printf "%s\n" "${program}"  >>"${install_dep}"
        				fi
        				;;
        		*)		printf "%s\n" "${program}"  >>"${install_dep}"
        				;;
        	esac
        fi
done <"${script_path}"/control/install.dep
if [ -f "${install_dep}" ] && [ -s "${install_dep}" ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case "${specific_env}" in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				for pmgr in apk apt-get dnf pacman pkg yum zipper
				do
					if [ -x "$(command -v "${pmgr}")" ]
					then
						pkg_mngr="${pmgr}";
					fi
				done
				if [ -z "${pkg_mngr}" ]
				then
					###IF PACKAGING MANAGER DETECTION FAILED####
					error_counter=1
					no_of_programs=$(wc -l <"${script_path}"/install_dep.tmp)
					printf "%s\n" "[${script_name}][ERROR][package] Couldn't detect the package management system used on this machine!"
					printf "%s\n" "[${script_name}][ERROR][package] Found ${no_of_programs} programs that need to be installed:"
					awk '{print "[${script_name}][ERROR][package] -> " $1}' "${install_dep}"
					printf "%s\n" "[${script_name}][ERROR][package] Install these programms first using your package management system and then run ${script_name} again."
					############################################
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ]
	then
		### INSTALL MISSING PKGS #####
		while read program
		do
			printf "%s\n" "[${script_name}][INFO] Trying to install ${program} using ${pkg_mngr}..."
			case "${pkg_mngr}" in
				"apk")		apk add "${program}" ;;
				"apt-get")	apt-get -y install "${program}" ;;
				"dnf")		dnf -y install "${program}" ;;
				"pacman")	pacman --noconfirm -S "${program}" ;;
				"pkg")		pkg install -y "${program}" ;;
				"yum")		yum -y install "${program}" ;;
				"zypper")	zypper -n install "${program}" ;;
			esac
			rt_query=$?
			if [ "${rt_query}" -gt 0 ]
			then
				printf "%s\n" "[${script_name}][ERROR][packages] Error during installation of ${program} using ${pkg_mngr}"
				printf "%s\n" "[${script_name}][ERROR][packages] Maybe the program ${program} is available in a package with different name."
				error_counter=$(( error_counter + 1 ))
			fi
		done <"${install_dep}"
		############################
	fi
fi
### DISPLAY OUTPUT ##########
printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})"
