#!/bin/sh

### GET PATH #################
script_path=$(dirname $(readlink -f "${0}"))

### GET ENVIRONMENT###########
specific_env=$1
specific_env=$(echo "${specific_env}"|tr '[A-Z]' '[a-z]')

### CHECK DEPENDENCIES #######
while read program
do
	### CHECK IF PROGRAMM IS UNKNOWN ####
        type "$program" >/dev/null 2>/dev/null
        rt_query=$?
        if [ $rt_query -gt 0 ]
        then
        	### QUERY TO REPLACE COMMANDS WITH PACKAGE NAME ###########
        	case $program in
        		"netcat")	echo "netcat-openbsd" >>"${script_path}"/install_dep.tmp
        				;;
        		"gpg")		echo "gnupg"  >>"${script_path}"/install_dep.tmp
        				;;
        		"openssl")	if [ "${specific_env}" = "termux" ]
        				then
        					echo "openssl-tool"  >>"${script_path}"/install_dep.tmp
        				else
        					echo "${program}"  >>"${script_path}"/install_dep.tmp
        				fi
        				;;
        		*)		echo "${program}"  >>"${script_path}"/install_dep.tmp
        				;;
        	esac
        fi
done <"${script_path}"/control/install.dep
if [ -f ${script_path}/install_dep.tmp ] && [ -s ${script_path}/install_dep.tmp ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case $specific_env in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				if [ -x "$(command -v apk)" ]
				then
					pkg_mngr="apk";
				else
					if [ -x "$(command -v apt-get)" ]
					then
						pkg_mngr="apt-get";
					else
						if [ -x "$(command -v dnf)" ]
						then
							pkg_mngr="dnf";
						else
							if [ -x "$(command -v pkg)" ]
							then
								pkg_mngr="pkg";
							else
								if [ -x "$(command -v yum)" ]
								then
									pkg_mngr="yum";
								else
									if [ -x "$(command -v zypper)" ]
									then
										pkg_mngr="zypper";
									else
										###IF PACKAGING MANAGER DETECTION FAILED####
										error_detected=1
										no_of_programs=$(wc -l <${script_path}/install_dep.tmp)
										echo "ERROR: Couldn't detect the package management system used on this machine!"
										echo "Found ${no_of_programs} programs that need to be installed:"
										cat ${script_path}/install_dep.tmp
										echo "Install these programms first using your package management system and then run install.sh again."
										############################################
									fi
								fi
							fi
						fi
					fi
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ $error_detected = 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read line
		do
			printf "%b" "INFO: Trying to install ${line} using ${pkg_mngr}...\n"
			case $pkg_mngr in
				"apk")		apk add $line ;;
				"apt-get")	apt-get -y install $line ;;
				"dnf")		dnf install $line ;;
				"pkg")		pkg install -y $line ;;
				"yum")		yum install $line ;;
				"zypper")	zypper install $line ;;
			esac
			rt_query=$?
			if [ ! $rt_query = 0 ]
			then
				error_detected=1
				echo "Error running the following command: ${pkg_mngr} install ${line}"
				echo "Maybe the program ${line} is available in a package with different name."
			fi
		done <${script_path}/install_dep.tmp
		############################
	fi
fi
###REMOVE TMP FILE##########
rm ${script_path}/install_dep.tmp 2>/dev/null
