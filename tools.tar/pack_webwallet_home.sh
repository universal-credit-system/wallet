#!/bin/sh
print_message(){
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%s\n" "DONE"
		else
			printf "%s\n" "FAILED"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}
###SET VARIABLES###################
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")
copy_path=$(echo "${1}"|sed 's/\/$//g')

if [ -n "${copy_path}" ] && [ -d "${copy_path}" ]
then
	###REMOVE OLD SESSIONS#############
	printf "%s" "[${script_name}][INFO] Purge old sessions..."
	find "${script_path}"/webwallet/sessions -maxdepth 1 -type f -exec rm -f -- {} + || rt_query=1
	chmod +x "${script_path}"/webwallet.sh "${script_path}"/install_webwallet.sh || rt_query=1
	print_message

	###CREATE TAR FILE#################
	printf "%s" "[${script_name}][INFO] Create tar file..."
	tar -cf webwallet_home.tar control/webwallet.conf control/webwallet_HELP.txt install_webwallet.sh webwallet.sh webwallet/ nginx_webwallet_default.conf >/dev/null 2>/dev/null || rt_query=1
	print_message
	if [ "${rt_query}" -eq 0 ]
	then
		if [ -n "${copy_path}" ] && [ -d "${copy_path}" ]
		then
			printf "%s" "[${script_name}][INFO] Copy tar file to ${copy_path}..."
			cp -- webwallet_home.tar "${copy_path}"/webwallet_home.tar || rt_query=1
			print_message
		fi
	fi
else
	printf "%s\n" "[${script_name}][ERROR] missing path! Example: ./${script_name} PATH"
fi
### DISPLAY OUTPUT #######################
printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})"
