#!/bin/sh
script_path=$(cd "$(dirname "$0")" && pwd)
copy_path=$(echo "${1}"|sed 's/\/$//g')
echo "[ INFO ] Create tar file..."
rm -f -- "${script_path}"/webwallet/sessions/* 2>/dev/null
chmod +x "${script_path}"/webwallet.sh "${script_path}"/install_webwallet.sh
tar -cf webwallet_home.tar control/webwallet.conf control/webwallet_HELP.txt install_webwallet.sh webwallet.sh webwallet/
rt_query=$?
if [ "${rt_query}" -eq 0 ]
then
	echo "[ INFO ] Tar file created..."
	if [ ! -z "${copy_path}" ] && [ -d "${copy_path}" ]
	then
		echo "[ INFO ] Copy tar file to ${copy_path}..."
		cp -- webwallet_home.tar "${copy_path}"/webwallet_home.tar
		rt_query=$?
		if [ "${rt_query}" -eq 0 ]
		then
		        echo "[ INFO ] File copied..."
                else
			echo "[ ERROR ] Could not copy file..."
                fi
        fi
else
	echo "[ ERROR ] Could not copy file..."
fi
echo "[ INFO ] EXIT (${rt_query})"
