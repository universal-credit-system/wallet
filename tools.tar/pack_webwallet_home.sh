#!/bin/sh
copy_path=$(echo "${1}"|sed 's/\/$//g')
echo "INFO: CREATE TAR-FILE..."
rm webwallet/sessions/* 2>/dev/null
tar -cf webwallet_home.tar control/webwallet.conf control/webwallet_HELP.txt install_webwallet.sh webwallet.sh webwallet/
rt_query=$?
if [ $rt_query = 0 ]
then
	echo "INFO: TAR-FILE SUCCESSFULLY CREATED..."
	if [ ! -z $copy_path -a -d $copy_path ]
	then
		echo "INFO: COPY ARCHIVE..."
		cp webwallet_home.tar ${copy_path}/webwallet_home.tar
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			echo "INFO: ARCHIVE SUCCESSFULLY COPIED..."
		else
			echo "ERROR: COULD NOT COPY ARCHIVE TO ${copy_path}!"
			rm server.tar
		fi
	else
		echo "ERROR: COULD NOT COPY ARCHIVE TO ${copy_path}!"
		rm server.tar
	fi
else
	echo "ERROR: COULD NOT CREATE ARCHIVE!"
fi
echo "INFO: EXIT (${rt_query})"
