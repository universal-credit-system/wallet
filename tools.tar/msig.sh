#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
make_signature(){
			write_message=$1

			###SET DEFAULT VALUES############################################
			rt_query=0
			message_blank="${user_path}"/message_blank.dat
			touch "${message_blank}"

			###WRITE MULTI SIG USER##########################################
			message="${script_path}/proofs/${handover_account}/multi.sig"
			printf "%b" "${write_message}" >>"${message_blank}" || rt_query=1
			if [ "${rt_query}" -eq 0 ]
			then
				###SIGN FILE#####################################################
				echo "${login_password}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --digest-algo SHA512 --local-user "${handover_account}" --clearsign "${message_blank}" 2>/dev/null
				rt_query=$?
				if [ "${rt_query}" -eq 0 ]
				then
					mv -- "${message_blank}".asc "${message}"
				fi

				###PURGE FILES###################################################
				rm -f --"${message_blank}"
				rm -f --"${message_blank}".asc
			fi

			return "${rt_query}"
}
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "${0}")
handover_account=$1
login_password=$2
if [ -n "${handover_account}" ] && [ -n "${login_password}" ]
then
	if [ -d "${script_path}/userdata/${handover_account}" ]
	then
		if [ ! -e "${script_path}/proofs/${handover_account}/multi.sig" ]
		then
			###SET USER PATH################################
			user_path="${script_path}/userdata/${handover_account}"

			###DEFINE GUI VARIABLES#########################
			core_system_name="Universal Credit System"
			core_system_version=$(cat "${script_path}"/control/version_info)

			###SOURCE LANG FILE#############################
			. "${script_path}"/lang/lang_EN_ENGLISH.conf

			###CREATE TEMP FILE#############################
			add_trap_command '[ -n "${lang_list:-}" ] && rm -f -- "${lang_list}"'
			lang_list=$(mktemp "${script_path}/tmp/lang.XXXXXX") || exit 1

			###CREATE LIST OF LANGUAGES#####################
			for language_file in $(find "${script_path}"/lang -maxdepth 1 -type f|awk -F/ '{print $NF}')
			do
				lang_ex_short=$(echo "${language_file}"|cut -d '_' -f2)
				lang_ex_full=$(echo "${language_file}"|cut -d '_' -f3|cut -d '.' -f1)
				printf "%s" "${lang_ex_short} ${lang_ex_full} " >>"${lang_list}"
			done

			###SHOW GUI FOR LANGUAGE SELECTION##############
			lang_selection=$(dialog --ok-label "${dialog_main_choose}" --cancel-label "${dialog_cancel}" --title "${dialog_main_lang}" --backtitle "${core_system_name} ${core_system_version}" --output-fd 1 --menu "${dialog_lang}" 0 0 0 --file "${lang_list}")
			rt_query=$?
			if [ "${rt_query}" -eq 0 ]
			then
				###SOURCE LANG FILE#############################
				lang_file=$(find "${script_path}"/lang -maxdepth 1 -type f|awk -F/ '{print $NF}'|grep -F -- "lang_${lang_selection}_")
				. "${script_path}/lang/${lang_file}"

				multi_sig_loop=0
				while [ "${multi_sig_loop}" -eq 0 ]
				do
					###ASK IF MULTI SIGNATURE OR NOT################
					dialog --yes-label "${dialog_yes}" --no-label "${dialog_no}" --title "${dialog_main_create}" --backtitle "${core_system_name} ${core_system_version}" --yesno "MULTI-SIGNATURE?" 0 0
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						###CREATE TEMP FILES############################
						add_trap_command '[ -n "${users_tmp:-}" ] && rm -f -- "${users_tmp}"'
						users_tmp=$(mktemp "${script_path}/tmp/msig.XXXXXX") || exit 1
						add_trap_command '[ -n "${keys_tmp:-}" ] && rm -f -- "${keys_tmp}"'
						keys_tmp=$(mktemp "${script_path}/tmp/msig.XXXXXX") || exit 1
						
						###WRITE LISTS##################################
						echo "0" >"${users_tmp}"
						find "${script_path}"/keys -maxdepth 1 -type f|awk -F/ '{print $NF}' >"${keys_tmp}"

						###LOOP TO ADD USERS FOR MULTI SIGNATURE########
						add_multi_sig_user=0
						while [ "${add_multi_sig_user}" -eq 0 ]
						do
							###ADDED USERS OVERVIEW#########################
							user=$(dialog --ok-label "${dialog_next}" --help-button --help-label "${dialog_main_back}" --cancel-label "${dialog_add}" --title "${dialog_main_create} : MULTI SIGNATURE : ${dialog_add}" --backtitle "${core_system_name} ${core_system_version}" --default-item "${user}" --no-items --output-fd 1 --scrollbar --menu "${dialog_overview}:" 0 0 0 --file "${users_tmp}")
							rt_query=$?
							if [ "${rt_query}" -eq 1 ] && [ "$(wc -l <"${users_tmp}")" -lt 10 ]
							then
								###SHOW LIST OF USERS TO ADD FOR MULTI-SIGNATURE###
								user=$(dialog --ok-label "${dialog_add}" --cancel-label "${dialog_main_back}" --title "${dialog_main_create} : MULTI SIGNATURE : ${dialog_add}" --backtitle "${core_system_name} ${core_system_version}" --no-items --output-fd 1 --scrollbar --menu "${dialog_overview}:" 0 0 0 --file "${keys_tmp}")
								rt_query=$?
								if [ "${rt_query}" -eq 0 ]
								then
									###CHECK IF FILE NEEDS TO BE PURGED################
									if [ "$(head -1 "${users_tmp}")" = "0" ]
									then
										rm -f --"${users_tmp}"
										touch "${users_tmp}"
									fi
									###CHECK IF USER HAS ALREADY BEEN ADDED############
									if ! grep -qF -- "${user}" "${users_tmp}"
									then
										sed "/${user}/d" "${keys_tmp}" >"${keys_tmp}".tmp && mv -- "${keys_tmp}".tmp "${keys_tmp}"
										echo "${user}" >>"${users_tmp}"
									fi
								fi
							else
								if [ "${rt_query}" -eq 0 ] && [ ! "${user}" = "0" ]
								then
									add_multi_sig_user=1
									multi_sig_loop=1

									###ASSIGN LIST OF KEYS TO VARIABLE#################
									multi_sig_keys=$(awk '{print ":MSIG:" $1}' "${users_tmp}")

									###WRITE FILE INDICATING A MULTI-SIGNATURE KEY#####
									make_signature "${multi_sig_keys}"
									rt_query=$?
								else
									if [ "${rt_query}" -eq 2 ]
									then
										add_multi_sig_user=1
									fi
								fi
							fi
						done
					else
						multi_sig_loop=1
						rt_query=0
					fi
				done
			fi
		else
			printf "%s\n" "[${script_name}][ERROR] user \"${handover_account}\" is already a multi-signature address"
		fi
	else
		printf "%s\n" "[${script_name}][ERROR] userdata folder for user \"${handover_account}\" does not exist"
	fi
else
	printf "%s\n" "[${script_name}][ERROR] address and/or password empty. example: ./${script_name} ADDRESS PASSWORD"
fi
