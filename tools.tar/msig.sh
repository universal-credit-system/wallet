#!/bin/sh
make_signature(){
			write_message=$1
			trx_now=$2
			signature_mode=$3

			###SET DEFAULT VALUES############################################
			rt_query=0
			message_blank="${user_path}"/message_blank.dat
			touch "${message_blank}"

			###CHECK IF INDEX FILE NEEDS TO BE CREATED#######################
			case "$signature_mode" in
				0)	###WRITE TRX MESSAGE#############################################
					message="${script_path}/trx/${handover_account}.${trx_now}"
					printf "%b" "${write_message}" >>"${message_blank}"
					;;
				1)	###INDEX FILE####################################################
					message="${script_path}/proofs/${handover_account}/${handover_account}.txt"

					###WRITE ASSETS TO INDEX FILE####################################
					for asset in $(cat "${user_path}"/all_assets.dat)
					do
						asset_hash=$(sha256sum "${script_path}/assets/${asset}")
						asset_hash=${asset_hash%% *}
						echo "assets/${asset} ${asset_hash}" >>"${message_blank}"
					done

					for key_file in $(cat "${user_path}"/all_accounts.dat)
					do
						###WRITE KEYFILE TO INDEX FILE###################################
						key_hash=$(sha256sum "${script_path}/keys/${key_file}")
						key_hash=${key_hash%% *}
						echo "keys/${key_file} ${key_hash}" >>"${message_blank}"

						###ADD TSA FILES#################################################
						for tsa_file in $(ls -1 "${script_path}/proofs/${key_file}"/*.ts*)
						do
							file=$(basename "${tsa_file}")
							file_hash=$(sha256sum "${script_path}/proofs/${key_file}/${file}")
							file_hash=${file_hash%% *}
							echo "proofs/${key_file}/${file} ${file_hash}" >>"${message_blank}"
						done

						###ADD INDEX FILE IF EXISTING####################################
						if [ -f "${script_path}/proofs/${key_file}/${key_file}.txt" ] && [ -s "${script_path}/proofs/${key_file}/${key_file}.txt" ]
						then
							file_hash=$(sha256sum "${script_path}/proofs/${key_file}/${key_file}.txt")
							file_hash=${file_hash%% *}
							echo "proofs/${key_file}/${key_file}.txt ${file_hash}" >>"${message_blank}"
						fi

						###ADD INDEX FILE IF EXISTING####################################
						if [ -f "${script_path}/proofs/${key_file}/multi.sig" ] && [ -s "${script_path}/proofs/${key_file}/multi.sig" ]
						then
							file_hash=$(sha256sum "${script_path}/proofs/${key_file}/multi.sig")
							file_hash=${file_hash%% *}
							echo "proofs/${key_file}/multi.sig ${file_hash}" >>"${message_blank}"
						fi
					done

					####WRITE TRX LIST TO INDEX FILE#################################
					cat "${user_path}"/*_index_trx.dat >>"${message_blank}" 2>/dev/null
					;;
				2)	###WRITE MULTI SIG USER##########################################
					message="${script_path}/proofs/${handover_account}/multi.sig"
					printf "%b" "${write_message}" >>"${message_blank}"
					;;
				*)	rt_query=1
					;;
			esac

			if [ "$rt_query" -eq 0 ]
			then
				###SIGN FILE#####################################################
				echo "${login_password}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --digest-algo SHA512 --local-user "${handover_account}" --clearsign "${message_blank}" 2>/dev/null
				rt_query=$?
				if [ "$rt_query" -eq 0 ]
				then
					mv "${message_blank}".asc "${message}"
				fi

				###PURGE FILES###################################################
				rm "${message_blank}" 2>/dev/null
				rm "${message_blank}".asc 2>/dev/null
			fi

			return $rt_query
}
script_path=$(dirname "$(readlink -f "${0}")")
handover_account=$1
login_password=$2
if [ -n "${handover_account}" ] && [ -n "${login_password}" ]
then
	user_path="${script_path}/userdata/${handover_account}"

	###SOURCE FILES#################################
	. ${script_path}/control/version_info
	. ${script_path}/lang/lang_EN_ENGLISH.conf


	multi_sig_loop=0
	while [ "$multi_sig_loop" -eq 0 ]
	do
		###ASK IF MULTI SIGNATURE OR NOT#########################
		dialog --yes-label "$dialog_yes" --no-label "$dialog_no" --title "$dialog_main_create" --backtitle "$core_system_name $core_system_version" --yesno "MULTI-SIGNATURE?" 0 0
		rt_query=$?
		if [ "$rt_query" -eq 0 ]
		then
			add_multi_sig_user=0
			###WRITE LISTS###########################################
			echo "0" >"${user_path}"/msig_users.tmp
			ls -1 "${script_path}"/keys >"${user_path}"/msig_keys.tmp

			###LOOP TO ADD USERS FOR MULTI SIGNATURE#################
			while [ "$add_multi_sig_user" -eq 0 ]
			do
				###ADDED USERS OVERVIEW########################################
				user=$(dialog --ok-label "$dialog_next" --help-button --help-label "$dialog_main_back" --cancel-label "$dialog_add" --title "$dialog_main_create : MULTI SIGNATURE : $dialog_add" --backtitle "$core_system_name $core_system_version" --default-item "${user}" --no-items --output-fd 1 --scrollbar --menu "$dialog_overview:" 0 0 0 --file "${user_path}"/msig_users.tmp)
				rt_query=$?
				if [ "$rt_query" -eq 1 ] && [ "$(wc -l <"${user_path}"/msig_users.tmp)" -lt 10 ]
				then
					###SHOW LIST OF USERS TO ADD FOR MULTI-SIGNATURE###############
					user=$(dialog --ok-label "$dialog_add" --cancel-label "$dialog_main_back" --title "$dialog_main_create : MULTI SIGNATURE : $dialog_add" --backtitle "$core_system_name $core_system_version" --no-items --output-fd 1 --scrollbar --menu "$dialog_overview:" 0 0 0 --file "${user_path}"/msig_keys.tmp)
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						###CHECK IF FILE NEEDS TO BE PURGED############################
						if [ "$(head -1 "${user_path}/msig_users.tmp")" = "0" ]
						then
							rm "${user_path}/msig_users.tmp"
							touch "${user_path}/msig_users.tmp"
						fi
						###CHECK IF USER HAS ALREADY BEEN ADDED########################
						if [ "$(grep -c "${user}" "${user_path}/msig_users.tmp")" -eq 0 ]
						then
							sed -i."${my_pid}".bak "/${user}/d" "${user_path}"/msig_keys.tmp
							echo "${user}" >>"${user_path}/msig_users.tmp"
						fi
					fi
				else
					if [ "$rt_query" -eq 0 ] && [ ! "$user" = "0" ]
					then
						add_multi_sig_user=1
						multi_sig_loop=1

						###ASSIGN LIST OF KEYS TO VARIABLE#############################
						multi_sig_keys=$(awk '{print ":MSIG:" $1}' "${user_path}/msig_users.tmp")

						###WRITE FILE INDICATING A MULTI-SIGNATURE KEY#################
						make_signature "$multi_sig_keys" "none" 2
						rt_query=$?
					else
						if [ "$rt_query" -eq 2 ]
						then
							add_multi_sig_user=1
						fi
					fi
				fi
			done
			rm "${user_path}"/msig_keys.tmp
			rm "${user_path}"/msig_users.tmp
		else
			multi_sig_loop=1
			rt_query=0
		fi
	done
fi
