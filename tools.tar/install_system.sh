#!/bin/sh
print_message(){
		if [ "$rt_query" -eq 0 ]
		then
			printf "%b" "DONE\n"
		else
			printf "%b" "FAILED\n"
			error_detected=1
		fi
		rt_query=0
}

### SET VARIABLES ############
user=$1
script_path=$(dirname $(readlink -f "${0}"))
rt_query=0
error_detected=0
	
### CREATE DIRECTORIES #######
printf "%b" "[ INFO ] Creating directories..."
mkdir -p "${script_path}"/backup || rt_query=1
mkdir -p "${script_path}"/control/keys || rt_query=1
mkdir -p "${script_path}"/keys || rt_query=1
mkdir -p "${script_path}"/proofs || rt_query=1
mkdir -p "${script_path}"/trx || rt_query=1
mkdir -p "${script_path}"/userdata || rt_query=1
print_message "$rt_query"

### SAVE UMASK SETTINGS ######
printf "%b" "[ INFO ] Getting umask..."
user_umask=$(umask) || rt_query=1
permissions_directories=$(echo "777 - ${user_umask}"|bc) || rt_query=1
touch "${script_path}"/test.tmp || rt_query=1
permissions_files=$(stat -c '%a' "${script_path}"/test.tmp) || rt_query=1
rm "${script_path}"/test.tmp || rt_query=1
print_message "$rt_query"

### IF OLD CONFIG THERE ######
if [ -s "${script_path}"/control/config.conf ]
then
	printf "%b" "[ INFO ] Backup old config ( ->control/config.bak )..."
	mv "${script_path}"/control/config.conf "${script_path}"/control/config.bak || rt_query=1
	print_message "$rt_query"
fi

### COPY TO PLACE ############
printf "%b" "[ INFO ] Copy install_config.conf to config.conf..."
cp "${script_path}"/control/install_config.conf "${script_path}"/control/config.conf || rt_query=1
print_message "$rt_query"

### WRITE PERMISSIONS ########
printf "%b" "[ INFO ] Write umask to config.conf..."
sed -i "s/permissions_directories=permissions_directories/permissions_directories=${permissions_directories}/g" "${script_path}"/control/config.conf || rt_query=1
sed -i "s/permissions_files=permissions_files/permissions_files=${permissions_files}/g" "${script_path}"/control/config.conf || rt_query=1
print_message "$rt_query"

### SET DEFAULT THEME ########
printf "%b" "[ INFO ] Set default theme 'debian.rc' in config.conf..."
sed -i "s#theme_file=theme_file#theme_file=debian.rc#g" "${script_path}"/control/config.conf || rt_query=1
print_message "$rt_query"

### SET PATHS ################
printf "%b" "[ INFO ] Define paths in config.conf..."
sed -i "s#trx_path_input=trx_path_input#trx_path_input=${script_path}#g" "${script_path}"/control/config.conf || rt_query=1
sed -i "s#trx_path_output=trx_path_output#trx_path_output=${script_path}#g" "${script_path}"/control/config.conf || rt_query=1
sed -i "s#sync_path_input=sync_path_input#sync_path_input=${script_path}#g" "${script_path}"/control/config.conf || rt_query=1
sed -i "s#sync_path_output=sync_path_output#sync_path_output=${script_path}#g" "${script_path}"/control/config.conf || rt_query=1
print_message "$rt_query"

### REWRITE CONFIG ###########
if [ -s "${script_path}"/control/config.bak ]
then
	### GET VARIABLES ###########
	printf "%b" "[ INFO ] Get old configuration of config.bak..."
	grep "\path_input\|path_output\|theme_file" "${script_path}"/control/config.bak >"${script_path}"/control/config.tmp || rt_query=1
	print_message "$rt_query"

	### READ OLD CONFIG #########
	while read config_line
	do
		if [ -n "${config_line}" ]
		then
			conf_var=$(echo "${config_line}"|cut -d '=' -f1)
			conf_var_val=$(echo "${config_line}"|cut -d '=' -f2)
			if [ "$(grep -c "${conf_var}" "${script_path}"/control/config.conf)" -gt 0 ]
			then
				printf "%b" "[ INFO ] Configure var \$${conf_var} in config.conf..."
				conf_line=$(grep "${conf_var}" "${script_path}"/control/config.conf)
				if [ ! "${conf_line}" = "${conf_var}=${conf_var_val}" ]
				then
					sed -i "s/${conf_line}/${conf_var}=${conf_var_val}/g" "${script_path}"/control/config.conf || rt_query=1
				fi
				print_message "$rt_query"
			fi
		fi
	done <"${script_path}"/control/config.tmp
	rm "${script_path}"/control/config.tmp
fi

if [ ! "${user}" = "docker" ]
then
	### GET USER $HOME PATH #####
	if [ -z "${user}" ]
	then
		path_set=~
		if [ -z "${path_set}" ]
		then
			user=$(logname)
			echo "[ ERROR ] Variable \$HOME of user $user not set. Aborting..."
			exit 1
		fi
	else
		path_set="/home/${user}"
	fi

	### IF USER NEVER RAN GPG ###
	if [ ! -d "${path_set}"/.gnupg/ ]
	then
		### RUN GPG #################
		printf "%b" "[ INFO ] Wake up gpg-agent..."
		gpgconf --launch gpg-agent >/dev/null 2>/dev/null || rt_query=1
		print_message "$rt_query"
	fi

	### CONFIGURE GPG ###########
	if [ -s "${path_set}"/.gnupg/gpg-agent.conf ]
	then
		printf "%b" "[ INFO ] Checking gpg-agent.conf configuration..."
		while read config_line
		do
			if [ "$(grep -c "${config_line}" ${path_set}/.gnupg/gpg-agent.conf)" -eq 0 ]
			then
				echo "${config_line}" >>${path_set}/.gnupg/gpg-agent.conf
			fi
		done <"${script_path}"/control/gpg-agent.conf
		print_message "$rt_query"
	else
		printf "%b" "[ INFO ] Copy gpg-agent.conf to ${path_set}/.gnupg/ folder..."
		cp "${script_path}"/control/gpg-agent.conf "${path_set}"/.gnupg/gpg-agent.conf || rt_query=1
		print_message "$rt_query"
	fi

	### REMOVE USAGE OF KEYBOX ##
	if [ -s "${path_set}"/.gnupg/common.conf ]
	then
		printf "%b" "[ INFO ] Remove 'use-keyboxd' entry in ${path_set}/.gnupg/common.conf..."
		sed -i 's/use-keyboxd//g' "${path_set}"/.gnupg/common.conf || rt_query=1
		print_message "$rt_query"
	fi

	### DISPLAY OUTPUT ##########
	error_text="with errors"
	if [ "$error_detected" -eq 0 ]
	then
		error_text="without errors"
	fi
	printf "%b" "[ INFO ] install_system.sh finished $error_text. exiting...\n"
fi
