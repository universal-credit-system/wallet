#!/bin/sh
print_message(){
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%s\n" "DONE"
		else
			printf "%s\n" "FAILED"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}
### SET VARIABLES ############
user=$1
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")
rt_query=0
error_counter=0
	
### CREATE DIRECTORIES #######
printf "%s" "[${script_name}][INFO] Creating directories..."
mkdir -p "${script_path}"/backup \
	"${script_path}"/control/keys \
	"${script_path}"/keys \
	"${script_path}"/proofs \
	"${script_path}"/tmp \
	"${script_path}"/trx \
	"${script_path}"/userdata || rt_query=1
print_message

### SAVE UMASK SETTINGS ######
printf "%s" "[${script_name}][INFO] Getting umask..."
permissions_directories=$(printf "%03o" $(( 0777 & ~$(umask) ))) || rt_query=1
permissions_files=$(printf "%03o" $(( 0666 & ~$(umask) ))) || rt_query=1
print_message

### IF OLD CONFIG THERE ######
if [ -s "${script_path}"/control/config.conf ]
then
	printf "%s" "[${script_name}][INFO] Backup old config ( ->control/config.bak )..."
	mv -- "${script_path}"/control/config.conf "${script_path}"/control/config.bak || rt_query=1
	print_message
fi

### COPY TO PLACE ############
printf "%s" "[${script_name}][INFO] Copy install_config.conf to config.conf..."
cp -- "${script_path}"/control/install_config.conf "${script_path}"/control/config.conf || rt_query=1
print_message

### CREATE TMP FILE ##########
add_trap_command '[ -n "${config_tmp:-}" ] && rm -f -- "${config_tmp}"'
config_tmp=$(mktemp "${script_path}/tmp/system_config.XXXXXX") || exit 1

### WRITE PERMISSIONS ########
printf "%s" "[${script_name}][INFO] Write umask to config.conf..."
sed "s/permissions_directories=permissions_directories/permissions_directories=${permissions_directories}/g" "${script_path}"/control/config.conf >"${config_tmp}" && mv -- "${config_tmp}"  "${script_path}"/control/config.conf || rt_query=1
sed "s/permissions_files=permissions_files/permissions_files=${permissions_files}/g" "${script_path}"/control/config.conf >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/control/config.conf || rt_query=1
print_message

### SET DEFAULT THEME ########
printf "%s" "[${script_name}][INFO] Set default theme 'debian.rc' in config.conf..."
sed "s#theme_file=theme_file#theme_file=debian.rc#g" "${script_path}"/control/config.conf >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/control/config.conf || rt_query=1
print_message

### SET PATHS ################
printf "%s" "[${script_name}][INFO] Define paths in config.conf..."
sed "s#trx_path_input=trx_path_input#trx_path_input=${script_path}#g" "${script_path}"/control/config.conf >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/control/config.conf || rt_query=1
sed "s#trx_path_output=trx_path_output#trx_path_output=${script_path}#g" "${script_path}"/control/config.conf >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/control/config.conf || rt_query=1
sed "s#sync_path_input=sync_path_input#sync_path_input=${script_path}#g" "${script_path}"/control/config.conf >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/control/config.conf || rt_query=1
sed "s#sync_path_output=sync_path_output#sync_path_output=${script_path}#g" "${script_path}"/control/config.conf >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/control/config.conf || rt_query=1
print_message

### REWRITE CONFIG ###########
if [ -s "${script_path}"/control/config.bak ]
then
	### CREATE TMP FILE ##########
	add_trap_command '[ -n "${config_tmp:-}" ] && rm -f -- "${config_tmp}"'
	old_config_tmp=$(mktemp "${script_path}/tmp/old_system_config.XXXXXX") || exit 1

	### GET VARIABLES ###########
	printf "%s" "[${script_name}][INFO] Get old configuration of config.bak..."
	grep "\path_input\|path_output\|theme_file" "${script_path}"/control/config.bak >"${old_config_tmp}" || rt_query=1
	print_message

	### READ OLD CONFIG #########
	while read config_line
	do
		if [ -n "${config_line}" ]
		then
			conf_var=$(echo "${config_line}"|cut -d '=' -f1)
			conf_var_val=$(echo "${config_line}"|cut -d '=' -f2)
			if grep -qF -- "${conf_var}" "${script_path}"/control/config.conf
			then
				### RECONFIGURE #########
				printf "%s" "[${script_name}][INFO] Configure var \$${conf_var} in config.conf..."
				conf_line=$(grep "${conf_var}" "${script_path}"/control/config.conf)
				if [ ! "${conf_line}" = "${conf_var}=${conf_var_val}" ]
				then
					sed "s/${conf_line}/${conf_var}=${conf_var_val}/g" "${script_path}"/control/config.conf >"${config_tmp}" && mv -- "${config_tmp}" "${script_path}"/control/config.conf || rt_query=1
				fi
				print_message
			fi
		fi
	done <"${old_config_tmp}"
fi

if [ ! "${user}" = "docker" ]
then
	if [ "${error_counter}" -eq 0 ]
	then
		### GET USER $HOME PATH #####
		if [ -z "${user}" ]
		then
			path_set=~
			if [ -z "${path_set}" ]
			then
				user=$(logname)
				printf "%s\n" "[${script_name}][ERROR] Variable \$HOME of user $user not set. Aborting..."
				exit 1
			fi
		else
			path_set="/home/${user}"
		fi

		### IF USER NEVER RAN GPG ###
		if [ ! -d "${path_set}"/.gnupg/ ]
		then
			### RUN GPG #################
			printf "%s" "[${script_name}][INFO] Wake up gpg-agent..."
			gpgconf --launch gpg-agent >/dev/null 2>/dev/null || rt_query=1
			print_message
		fi

		### CONFIGURE GPG ###########
		if [ -s "${path_set}"/.gnupg/gpg-agent.conf ]
		then
			printf "%s" "[${script_name}][INFO] Checking gpg-agent.conf configuration..."
			while read config_line
			do
				if ! grep -qF -- "${config_line}" "${path_set}"/.gnupg/gpg-agent.conf
				then
					printf "%s\n" "${config_line}" >>"${path_set}"/.gnupg/gpg-agent.conf || rt_query=1
				fi
			done <"${script_path}"/control/gpg-agent.conf
			print_message
		else
			printf "%s" "[${script_name}][INFO] Copy gpg-agent.conf to folder .gnupg (path ->\"${path_set}\")..."
			cp -- "${script_path}"/control/gpg-agent.conf "${path_set}"/.gnupg/gpg-agent.conf || rt_query=1
			print_message
		fi

		### REMOVE USAGE OF KEYBOX ##
		if [ -s "${path_set}"/.gnupg/common.conf ]
		then
			printf "%s" "[${script_name}][INFO] Remove 'use-keyboxd' entry in .gnupg/common.conf (path ->\"${path_set}\")..."
			sed 's/use-keyboxd//g' "${path_set}"/.gnupg/common.conf >"${config_tmp}" && mv -- "${config_tmp}" "${path_set}"/.gnupg/common.conf || rt_query=1
			print_message
		fi
	fi
fi
#### DISPLAY OUTPUT ##########
printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})"
