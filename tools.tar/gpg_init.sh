#!/bin/sh
print_message(){
		if [ "$rt_query" -eq 0 ]
		then
			printf "%b" "DONE\n"
		else
			printf "%b" "FAILED\n"
			error_detected=1
		fi
		rt_query=0
}

### SET VARIABLES ############
script_path=$(dirname $(readlink -f "${0}"))
my_pid=$$
error_detected=0
rt_query=0

### USER $HOME PATH ##########
if [ -z "$HOME" ]
then
	user=$(logname)
	echo "[ ERROR ] Variable \$HOME of user $user not set. Aborting..."
	exit 1
else
	path_set=$HOME
fi

### IF USER NEVER RAN GPG ####
if [ ! -d "${path_set}"/.gnupg/ ]
then
	### RUN GPG ##################
	printf "%b" "[ INFO ] Wake up gpg-agent..."
	gpgconf --launch gpg-agent >/dev/null 2>/dev/null || rt_query=1
	print_message "$rt_query"
fi

### CONFIGURE GPG ############
if [ -s "${path_set}"/.gnupg/gpg-agent.conf ]
then
	printf "%b" "[ INFO ] Checking gpg-agent.conf configuration..."
	while read config_line
	do
		if [ "$(grep -c "${config_line}" "${path_set}"/.gnupg/gpg-agent.conf)" -eq 0 ]
		then
			echo "${config_line}" >>"${path_set}"/.gnupg/gpg-agent.conf
		fi
	done <"${script_path}"/control/gpg-agent.conf
	print_message "$rt_query"
else
	printf "%b" "[ INFO ] Copy gpg-agent.conf to ${path_set}/.gnupg/ folder..."
	cp "${script_path}"/control/gpg-agent.conf "${path_set}"/.gnupg/gpg-agent.conf || rt_query=1
	print_message "$rt_query"
fi

### REMOVE USAGE OF KEYBOX ###
if [ -s "${path_set}"/.gnupg/common.conf ]
then
	printf "%b" "[ INFO ] Remove 'use-keyboxd' entry in "${path_set}"/.gnupg/common.conf..."
	sed -i."${my_pid}".tmp 's/use-keyboxd//g' "${path_set}"/.gnupg/common.conf && rm "${path_set}"/.gnupg/common.conf."${my_pid}".tmp 2>/dev/null || rt_query=1
	print_message "$rt_query"
fi

### DISPLAY OUTPUT ###########
error_text="with errors"
if [ "$error_detected" -eq 0 ]
then
	error_text="without errors"
fi
printf "%b" "[ INFO ] gpg_init finished $error_text. exiting...\n"

exec "$@"

