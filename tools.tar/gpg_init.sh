#!/bin/sh

### GET PATH #################
script_path=$(dirname $(readlink -f "${0}"))

### IF USER NEVER RAN GPG UNTIL NOW ######
if [ -z $HOME ]
then
	exit 1
else
	path_set=$HOME
fi
if [ ! -d ${path_set}/.gnupg/ ]
then
	### RUN GPG ###################
	gpg '?' 2>/dev/null
fi
if [ -s ${path_set}/.gnupg/gpg-agent.conf ]
then
	while read config_line
	do
		if [ "$(grep -c "${config_line}" ${path_set}/.gnupg/gpg-agent.conf)" -eq 0 ]
		then
			echo "${config_line}" >>${path_set}/.gnupg/gpg-agent.conf
		fi
	done <"${script_path}"/control/gpg-agent.conf
else
	cp "${script_path}"/control/gpg-agent.conf ${path_set}/.gnupg/gpg-agent.conf
fi
if [ -s ${path_set}/.gnupg/common.conf ]
then
	sed -i 's/use-keyboxd//g' ${path_set}/.gnupg/common.conf
fi
exec "$@"

