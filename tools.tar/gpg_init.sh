#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
print_message(){
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%s\n" "DONE"
		else
			printf "%s\n" "FAILED"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}

### SET VARIABLES ############
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")
my_pid=$$
error_counter=0
rt_query=0

### USER $HOME PATH ##########
if [ -z "${HOME}" ]
then
	user=$(logname)
	printf "%s\n" "[${script_name}][ERROR] Variable \$HOME of user ${user} not set. Aborting..."
	exit 1
else
	path_set=$HOME
fi

### IF USER NEVER RAN GPG ####
if [ ! -d "${path_set}"/.gnupg/ ]
then
	### RUN GPG ##################
	printf "%s" "[${script_name}][INFO] Wake up gpg-agent..."
	gpgconf --launch gpg-agent >/dev/null 2>/dev/null || rt_query=1
	print_message
fi

### CONFIGURE GPG ############
if [ -s "${path_set}"/.gnupg/gpg-agent.conf ]
then
	printf "%s" "[${script_name}][INFO] Checking gpg-agent.conf configuration..."
	while read config_line
	do
		if ! grep -qF -- "${config_line}" "${path_set}"/.gnupg/gpg-agent.conf
		then
			echo "${config_line}" >>"${path_set}"/.gnupg/gpg-agent.conf || rt_query=1
		fi
	done <"${script_path}"/control/gpg-agent.conf
	print_message
else
	printf "%s" "[${script_name}][INFO] Copy gpg-agent.conf to ${path_set}/.gnupg/ folder..."
	cp -- "${script_path}"/control/gpg-agent.conf "${path_set}"/.gnupg/gpg-agent.conf || rt_query=1
	print_message
fi

### REMOVE USAGE OF KEYBOX ###
if [ -s "${path_set}"/.gnupg/common.conf ]
then
	### CREATE TMP ##############
	add_trap_command '[ -n "${gpg_init:-}" ] && rm -f -- "${gpg_init}"'
	gpg_init=$(mktemp "${script_path}/tmp/gpg_init.XXXXXX") || exit 1
	
	### REMOVE ##################
	printf "%s" "[${script_name}][INFO] Remove 'use-keyboxd' entry in file .gnupg/common.conf (path ->\"${path_set}\")..."
	sed 's/use-keyboxd//g' "${path_set}"/.gnupg/common.conf >"${gpg_init}" && mv -- "${gpg_init}" "${path_set}"/.gnupg/common.conf || rt_query=1
	print_message
fi

### DISPLAY OUTPUT ###########
printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})"
exec "$@"
