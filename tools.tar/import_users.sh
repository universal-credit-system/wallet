#!/bin/sh -xv
script_path=$(dirname $(readlink -f "${0}"))
user=$1
ls -1 "${script_path}"/control/keys/|grep -v ".sc"|grep "${user}" >"${script_path}"/skeys.tmp
if [ -s "${script_path}"/skeys.tmp ]
then
	gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --list-secret-keys --with-colons|grep "uid"|cut -d ':' -f10 >"${script_path}"/skeys_keyring.tmp
	while read line
	do
		if [ $(grep -c $line "${script_path}"/skeys_keyring.tmp) = 0 ]
		then
			gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --import "${script_path}"/control/keys/${line}
			rm "${script_path}"/userdata/${line}/*.dat 2>/dev/null
		fi
	done <"${script_path}"/skeys.tmp
	rm "${script_path}"/skeys_keyring.tmp
fi
rm "${script_path}"/skeys.tmp
ls -1 "${script_path}"/keys/|grep "${user}" >"${script_path}"/pkeys.tmp
if [ -s "${script_path}"/pkeys.tmp ]
then
	gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --list-keys --with-colons|grep "uid"|cut -d ':' -f10 >"${script_path}"/pkeys_keyring.tmp
	while read line
	do
		if [ $(grep -c $line "${script_path}"/pkeys_keyring.tmp) = 0 ]
		then
			gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --import "${script_path}"/keys/${line}
			rm "${script_path}"/userdata/${line}/*.dat 2>/dev/null
		fi
	done <"${script_path}"/pkeys.tmp
	rm "${script_path}"/pkeys_keyring.tmp
fi
rm "${script_path}"/pkeys.tmp
