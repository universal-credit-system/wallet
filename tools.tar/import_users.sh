#!/bin/sh -xv
script_name=${0}
script_path=$(dirname $(readlink -f ${0}))


ls -1 ${script_path}/control/keys/|grep -v ".sc" >${script_path}/skeys.tmp
gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --list-secret-keys --with-colons|grep "uid"|cut -d ':' -f10 >${script_path}/skeys_keyring.tmp
while read line
do
	if [ $(grep -c $line ${script_path}/skeys_keyring.tmp) = 0 ]
	then
		gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --import ${script_path}/control/keys/${line}
		rm ${script_path}/userdata/${line}/*.dat 2>/dev/null
	fi
done <${script_path}/skeys.tmp
rm ${script_path}/skeys.tmp
rm ${script_path}/skeys_keyring.tmp


ls -1 ${script_path}/keys/ >${script_path}/pkeys.tmp
gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --list-keys --with-colons|grep "uid"|cut -d ':' -f10 >${script_path}/pkeys_keyring.tmp
while read line
do
	if [ $(grep -c $line ${script_path}/pkeys_keyring.tmp) = 0 ]
	then
		gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --import ${script_path}/keys/${line}
		rm ${script_path}/userdata/${line}/*.dat 2>/dev/null
	fi
done <${script_path}/pkeys.tmp
rm ${script_path}/pkeys.tmp
rm ${script_path}/pkeys_keyring.tmp
