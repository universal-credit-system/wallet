#!/bin/sh
### SET VARIABLES ##############
script_path=$(cd "$(dirname "$0")" && pwd)
user=$1
prv_total_count=0
prv_fail_count=0
pub_total_count=0
pub_fail_count=0

### GET LIST OF PRIV KEY FILES #
ls -1U "${script_path}"/control/keys/|grep -v "[a-zA-Z0-9].sct"|grep -- "${user}" >"${script_path}"/tmp/priv_keys.tmp
if [ -s "${script_path}"/tmp/priv_keys.tmp ]
then
	### GET LIST OF GPG KEYS #######
	gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --list-secret-keys --with-colons|grep "uid"|cut -d ':' -f10 >"${script_path}"/tmp/priv_keys_keyring.tmp
	sort "${script_path}"/tmp/priv_keys_keyring.tmp "${script_path}"/tmp/priv_keys_keyring.tmp "${script_path}"/tmp/priv_keys.tmp|uniq -u >"${script_path}"/tmp/keys_to_add.tmp
	while read line
	do
		### IMPORT FILE IF NOT IN RING #
		gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --import "${script_path}"/control/keys/${line}
		rt_query=$?
		if [ "${rt_query}" -eq 0 ]
		then
			prv_total_count=$(( prv_total_count + 1 ))
		else
			prv_fail_count=$(( prv_fail_count + 1 ))
		fi
		rm -f -- "${script_path}"/userdata/${line}/*.dat
	done <"${script_path}"/tmp/keys_to_add.tmp
	rm -f -- "${script_path}"/tmp/keys_to_add.tmp
	rm -f -- "${script_path}"/tmp/priv_keys_keyring.tmp
fi
rm -f -- "${script_path}"/tmp/priv_keys.tmp

### GET LIST OF PUB KEY FILES ##
ls -1U "${script_path}"/keys/|grep -- "${user}" >"${script_path}"/tmp/pub_keys.tmp
if [ -s "${script_path}"/tmp/pub_keys.tmp ]
then
	### GET LIST OF GPG KEYS #######
	gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --list-keys --with-colons|grep "uid"|cut -d ':' -f10 >"${script_path}"/tmp/pub_keys_keyring.tmp
	sort "${script_path}"/tmp/pub_keys_keyring.tmp "${script_path}"/tmp/pub_keys_keyring.tmp "${script_path}"/tmp/pub_keys.tmp|uniq -u >"${script_path}"/tmp/keys_to_add.tmp
	while read line
	do
		### IMPORT FILE IF NOT IN RING #
		gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --import "${script_path}"/keys/${line}
		rt_query=$?
		if [ "${rt_query}" = 0 ]
		then
			pub_total_count=$(( pub_total_count + 1 ))
		else
			pub_fail_count=$(( pub_fail_count + 1 ))
		fi
		rm -f -- "${script_path}"/userdata/${line}/*.dat
	done <"${script_path}"/tmp/keys_to_add.tmp
	rm -f -- "${script_path}"/tmp/keys_to_add.tmp
	rm -f -- "${script_path}"/tmp/pub_keys_keyring.tmp
fi
rm -f -- "${script_path}"/tmp/pub_keys.tmp

### OUTPUT ######################
echo "${prv_total_count} private keys imported (failed:${prv_fail_count})"
echo "${pub_total_count} public keys imported (failed:${pub_fail_count})"
