#!/bin/sh -xv
script_name=${0}
script_path=$(dirname $(readlink -f ${0}))
ls -1 ${script_path}/control/keys/|grep -v ".sc" >${script_path}/keys.tmp
while read line
do
	gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --import ${script_path}/control/keys/${line}
	rm ${script_path}/userdata/${line}/*.dat 2>/dev/null
done <${script_path}/keys.tmp
rm ${script_path}/keys.tmp
