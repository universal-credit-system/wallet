#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
### SET VARIABLES ##############
script_path=$(cd "$(dirname "$0")" && pwd)
user=$1
prv_total_count=0
prv_fail_count=0
pub_total_count=0
pub_fail_count=0

### CREATE TMP ##############
add_trap_command '[ -n "${keys_to_add:-}" ] && rm -f -- "${keys_to_add}"'
keys_to_add=$(mktemp "${script_path}/tmp/import_users.XXXXXX") || exit 1
add_trap_command '[ -n "${keys_keyring:-}" ] && rm -f -- "${keys_keyring}"'
keys_keyring=$(mktemp "${script_path}/tmp/import_users.XXXXXX") || exit 1
add_trap_command '[ -n "${keys_tmp:-}" ] && rm -f -- "${keys_tmp}"'
keys_tmp=$(mktemp "${script_path}/tmp/import_users.XXXXXX") || exit 1

### GET LIST OF PRIV KEY FILES #
find "${script_path}"/control/keys -maxdepth 1 -type f -not -name "*.sct"|awk -F/ '{print $NF}'|grep -F -- "${user}" >"${keys_tmp}" 2>/dev/null
if [ -s "${keys_tmp}" ]
then
	### GET LIST OF GPG KEYS #######
	gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --list-secret-keys --with-colons|grep -F "uid"|cut -d ':' -f10 >"${keys_keyring}"
	sort "${keys_keyring}" "${keys_keyring}" "${keys_tmp}"|uniq -u >"${keys_to_add}"
	while read line
	do
		### IMPORT FILE IF NOT IN RING #
		gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --import "${script_path}/control/keys/${line}"
		rt_query=$?
		if [ "${rt_query}" -eq 0 ]
		then
			prv_total_count=$(( prv_total_count + 1 ))
		else
			prv_fail_count=$(( prv_fail_count + 1 ))
		fi
		### RESET USER ################
		[ -d "${script_path}/userdata/${line}" ] && find "${script_path}/userdata/${line}" -maxdepth 1 -type f -name "*.dat" -exec rm -f -- {} +
	done <"${keys_to_add}"
fi

### GET LIST OF PUB KEY FILES ##
find "${script_path}"/keys -maxdepth 1 -type f -name "${user}*"|awk -F/ '{print $NF}' >"${keys_tmp}" 2>/dev/null
if [ -s "${keys_tmp}" ]
then
	### GET LIST OF GPG KEYS #######
	gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --list-keys --with-colons|grep "uid"|cut -d ':' -f10 >"${keys_keyring}"
	sort "${keys_keyring}" "${keys_keyring}" "${keys_tmp}"|uniq -u >"${keys_to_add}"
	while read line
	do
		### IMPORT FILE IF NOT IN RING #
		gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --import "${script_path}/keys/${line}"
		rt_query=$?
		if [ "${rt_query}" = 0 ]
		then
			pub_total_count=$(( pub_total_count + 1 ))
		else
			pub_fail_count=$(( pub_fail_count + 1 ))
		fi
		[ -d "${script_path}/userdata/${line}" ] && find "${script_path}/userdata/${line}" -maxdepth 1 -type f -name "*.dat" -exec rm -f -- {} +
	done <"${keys_to_add}"
fi

### OUTPUT ######################
printf "%s\n" "${prv_total_count} private keys imported (failed:${prv_fail_count})"
printf "%s\n" "${pub_total_count} public keys imported (failed:${pub_fail_count})"
