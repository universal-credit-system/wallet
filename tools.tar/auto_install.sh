#!/bin/sh

###GET PATH#################
script_path=$(dirname $(readlink -f ${0}))

###CREATE DIRECTORIES#######
mkdir ${script_path}/backup
mkdir ${script_path}/control/keys
mkdir ${script_path}/keys
mkdir ${script_path}/proofs
mkdir ${script_path}/trx
mkdir ${script_path}/userdata

###SAVE UMASK SETTINGS######
user_umask=$(umask)
permissions_directories=$(echo "777 - ${user_umask}"|bc)
touch ${script_path}/test.tmp
permissions_files=$(stat -c '%a' ${script_path}/test.tmp)
rm ${script_path}/test.tmp
cp ${script_path}/control/install_config.conf ${script_path}/control/config.conf
sed -i "s/permissions_directories=permissions_directories/permissions_directories=${permissions_directories}/g" ${script_path}/control/config.conf
sed -i "s/permissions_files=permissions_files/permissions_files=${permissions_files}/g" ${script_path}/control/config.conf

###SET DEFAULT THEME########
sed -i "s#theme_file=theme_file#theme_file=debian.rc#g" ${script_path}/control/config.conf

###SET PATHS################
sed -i "s#trx_path_input=trx_path_input#trx_path_input=${script_path}#g" ${script_path}/control/config.conf
sed -i "s#trx_path_output=trx_path_output#trx_path_output=${script_path}#g" ${script_path}/control/config.conf
sed -i "s#sync_path_input=sync_path_input#sync_path_input=${script_path}#g" ${script_path}/control/config.conf
sed -i "s#sync_path_output=sync_path_output#sync_path_output=${script_path}#g" ${script_path}/control/config.conf

###CHECK DEPENDENCIES#######
while read line
do
	###CHECK IF PROGRAM IS INSTALLED####
        command -v $line >/dev/null
        rt_query=$?
        if [ $rt_query -gt 0 ]
        then
                echo $line >>${script_path}/install_dep.tmp
        fi
done <${script_path}/control/install.dep
if [ ! -s ${script_path}/install_dep.tmp ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	pkg_mngr="";
	if [ -x "$(command -v apk)" ]
	then
		pkg_mngr="apk";
	else
		if [ -x "$(command -v apt-get)" ]
		then
			pkg_mngr="apt-get";
		else
			if [ -x "$(command -v dnf)" ]
			then
				pkg_mngr="dnf";
			else
				if [ -x "$(command -v pkg)" ]
				then
					pkg_mngr="pkg";
				else
					if [ -x "$(command -v yum)" ]
					then
						pkg_mngr="yum";
					else
						if [ -x "$(command -v zypper)" ]
						then
							pkg_mngr="zypper";
						else
							###IF PACKAGING MANAGER DETECTION FAILED####
							no_of_programs=$(wc -l <${script_path}/install_dep.tmp)
							echo "ERROR: Couldn't detect the package management system used on this machine!"
        						echo "Found ${no_of_programs} programs that need to be installed:"
        						cat ${script_path}/install_dep.tmp
							echo "Install these programms first using your package management system and then run install.sh again."
							############################################
						fi
					fi
				fi
			fi
		fi
	fi
	############################
	
	if [ ! -z "${pkg_mngr}" ]
	then
		###INSTALL MISSING PKGS#####
		while read line
		do
			case $pkg_mngr in
				"apk")		apk add $line ;;
				"apt-get")	apt-get -y install $line ;;
				"dnf")		dnf install $line ;;
				"pkg")		pkg install $line ;;
				"yum")		yum install $line ;;
				"zypper")	zypper install $line ;;
			esac
			rt_query=$?
			if [ ! $rt_query = 0 ]
			then
				echo "Error running the following command: ${pkg_mngr} install ${line}"
				echo "Maybe the program ${line} is available in a package with different name."
			fi
		done <${script_path}/install_dep.tmp
		############################
	fi
	
	###REMOVE TMP FILE##########
        rm ${script_path}/install_dep.tmp
fi
