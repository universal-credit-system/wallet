#!/bin/sh
sudo systemctl stop nginx && sudo systemctl stop php8.2-fpm
