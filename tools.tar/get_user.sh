#!/bin/sh
get_user(){
		user=$1
		file_list="${script_path}/ExtrUser_${my_pid}.tmp"
		echo "INFO: CHECK KEYS..."
		if [ -s ${script_path}/keys/${user} ]
		then
			echo "keys/${user}" >${file_list}
		fi
		if [ -s ${script_path}/control/keys/${user} ] && [ -s ${script_path}/control/keys/${user}.sct ]
		then
			echo "control/keys/${user}" >>${file_list}
			echo "control/keys/${user}.sct" >>${file_list}
		fi
		echo "INFO: CHECK PROOFS..."
		if [ -d ${script_path}/proofs/${user} ]
		then
			echo "proofs/${user}/" >>${file_list}
		fi
		echo "INFO: CHECK TRX..."
		trx_total=$(ls -1 ${script_path}/trx/|grep "${user}"|wc -l)
		if [ $trx_total -gt 0 ]
		then
			for each_trx in $(ls -1 ${script_path}/trx/|grep "${user}")
			do
				echo "trx/${each_trx}" >>${file_list}
			done
		fi
		echo "INFO: CHECK USERDATA..."
		if [ -d ${script_path}/userdata/${user} ]
		then
			echo "userdata/${user}/" >>${file_list}
		fi
		total_size=$(cat ${file_list}|wc -l)
		if [ $total_size -gt 0 ]
		then
			echo "INFO: PACK ARCHIVE..."
			stamp=$(date +%s)
			tar -cf ${user}_${stamp}.tar -T ${file_list}
			rt_query=$?
			if [ $rt_query = 0 ]
			then
				echo "INFO: USERPROFILE -> ${user}_${stamp}.tar"
			fi
		else
			echo "INFO: NO FILES FOUND..."
			rt_query=1
		fi
		echo "INFO: EXIT (${rt_query})..."
		rm ${file_list} 2>/dev/null
}

##################
#Main Menu Screen#
##################
my_pid=$$
script_path=$(dirname $(readlink -f ${0}))
user=$1
get_user $user
