#!/bin/sh
get_user(){
		user=$1
		file_list="${script_path}/tmp/ExtrUser_${my_pid}.tmp"
		touch "${file_list}"

		### GET PUB KEY ##########################
		printf "%b" "[ INFO ] Looking for public key of ${user}..."
		if [ -s ${script_path}/keys/${user} ]
		then
			echo "keys/${user}" >"${file_list}"
		fi
		printf "%b" "DONE\n"

		### GET SECRET AND PRIV KEY ##############
		printf "%b" "[ INFO ] Looking for private key and secret of ${user}..."
		if [ -s ${script_path}/control/keys/${user} ] && [ -s ${script_path}/control/keys/${user}.sct ]
		then
			echo "control/keys/${user}" >>"${file_list}"
			echo "control/keys/${user}.sct" >>"${file_list}"
		fi
		printf "%b" "DONE\n"

		### GET PROOFS OF USER ###################
		printf "%b" "[ INFO ] Looking for proofs of ${user}..."
		if [ -d ${script_path}/proofs/${user} ]
		then
			echo "proofs/${user}/" >>"${file_list}"
		fi
		printf "%b" "DONE\n"

		### GET TRX OF USER ######################
		printf "%b" "[ INFO ] Looking for trx of ${user}..."
		ls -1 ${script_path}/trx/|grep "${user}"|awk '{print "trx/" $1}' >>${file_list}
		printf "%b" "DONE\n"
		
		### GET USERDATA OF USER #################
		printf "%b" "[ INFO ] Looking for userdata of ${user}..."
		if [ -d ${script_path}/userdata/${user} ]
		then
			echo "userdata/${user}/" >>"${file_list}"
		fi
		printf "%b" "DONE\n"
		
		total_size=$(wc -l <"${file_list}")
		if [ "${total_size}" -gt 0 ]
		then
			printf "%b" "[ INFO ] PACK ARCHIVE:\n"
			stamp=$(date +%s)
			tar -cvf "${user}_${stamp}.tar" -T "${file_list}"
			rt_query=$?
			if [ "${rt_query}" -eq 0 ]
			then
				printf "%b" "DONE\n"
				echo "[ INFO ] USERPROFILE -> ${user}_${stamp}.tar\n"
			else
				printf "%b" "FAILED\n"
			fi
		else
			printf "%b" "[ INFO ] NO FILES FOUND...\n"
			rt_query=1
		fi
		echo "[ INFO ] EXIT (${rt_query})...\n"
		rm -f -- "${file_list}"
}

##################
#Main Menu Screen#
##################
my_pid=$$
script_path=$(cd "$(dirname "$0")" && pwd)
user=$1
if [ -n "${user}" ]
then
	get_user "${user}"
else
	echo "[ ERROR ] You have to handover a user: ./get_user.sh ADDRESS"
fi
