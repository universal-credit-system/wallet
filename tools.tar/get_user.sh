#!/bin/sh
get_user(){
		user=$1
		file_list="${script_path}/ExtrUser_${my_pid}.tmp"

		### GET PUB KEY ##########################
		printf "%b" "INFO: Looking for public key of ${user}..."
		if [ -s ${script_path}/keys/${user} ]
		then
			echo "keys/${user}" >${file_list}
		fi
		printf "%b" "DONE\n"

		### GET SECRET AND PRIV KEY ##############
		printf "%b" "INFO: Looking for private key and secret of ${user}..."
		if [ -s ${script_path}/control/keys/${user} ] && [ -s ${script_path}/control/keys/${user}.sct ]
		then
			echo "control/keys/${user}" >>${file_list}
			echo "control/keys/${user}.sct" >>${file_list}
		fi
		printf "%b" "DONE\n"

		### GET PROOFS OF USER ###################
		printf "%b" "INFO: Looking for proofs of ${user}..."
		if [ -d ${script_path}/proofs/${user} ]
		then
			echo "proofs/${user}/" >>${file_list}
		fi
		printf "%b" "DONE\n"

		### GET TRX OF USER ######################
		printf "%b" "INFO: Looking for trx of ${user}..."
		trx_total=$(ls -1 ${script_path}/trx/|grep "${user}"|wc -l)
		if [ $trx_total -gt 0 ]
		then
			for trx in $(ls -1 ${script_path}/trx/|grep "${user}")
			do
				echo "trx/${trx}" >>${file_list}
			done
		fi
		printf "%b" "DONE\n"
		
		printf "%b" "INFO: Looking for userdata of ${user}..."
		if [ -d ${script_path}/userdata/${user} ]
		then
			echo "userdata/${user}/" >>${file_list}
		fi
		printf "%b" "DONE\n"
		
		total_size=$(cat ${file_list}|wc -l)
		if [ $total_size -gt 0 ]
		then
			printf "%b" "INFO: PACK ARCHIVE:\n"
			stamp=$(date +%s)
			tar -cvf ${user}_${stamp}.tar -T ${file_list}
			rt_query=$?
			if [ $rt_query = 0 ]
			then
				printf "%b" "DONE\n"
				echo "INFO: USERPROFILE -> ${user}_${stamp}.tar\n"
			else
				printf "%b" "FAILED\n"
			fi
		else
			printf "%b" "INFO: NO FILES FOUND...\n"
			rt_query=1
		fi
		echo "INFO: EXIT (${rt_query})...\n"
		rm ${file_list} 2>/dev/null
}

##################
#Main Menu Screen#
##################
my_pid=$$
script_path=$(dirname $(readlink -f "${0}"))
user=$1
if [ -n "${user}" ]
then
	get_user $user
else
	echo "ERROR: You have to handover a user:"
	echo "./get_user.sh ADDRESS"
fi
