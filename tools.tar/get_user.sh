#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
print_message(){
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%s\n" "DONE"
		else
			printf "%s\n" "FAILED"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}
get_user(){
		user=$1
		
		### CREATE TMP ##############
		add_trap_command '[ -n "${file_list:-}" ] && rm -f -- "${file_list}"'
		file_list=$(mktemp "${script_path}/get_user.XXXXXX") || exit 1

		### GET PUB KEY ##########################
		printf "%s" "[${script_name}][INFO] Looking for public key of ${user}..."
		if [ -e "${script_path}/keys/${user}" ]
		then
			echo "keys/${user}" >"${file_list}" || rt_query=1
		fi
		print_message

		### GET SECRET AND PRIV KEY ##############
		printf "%s" "[${script_name}][INFO] Looking for private key and secret of ${user}..."
		if [ -e "${script_path}/control/keys/${user}" ] && [ -e "${script_path}/control/keys/${user}.sct" ]
		then
			echo "control/keys/${user}" >>"${file_list}" || rt_query=1
			echo "control/keys/${user}.sct" >>"${file_list}" || rt_query=1
		fi
		print_message

		### GET PROOFS OF USER ###################
		printf "%s" "[${script_name}][INFO] Looking for proofs of ${user}..."
		if [ -d "${script_path}/proofs/${user}" ]
		then
			echo "proofs/${user}/" >>"${file_list}" || rt_query=1
		fi
		print_message

		### GET TRX OF USER ######################
		printf "%s" "[${script_name}][INFO] Looking for trx of ${user}..."
		find "${script_path}"/trx -maxdepth 1 -type f -name "${user}*"|awk -F/ '{print "trx/" $NF}' >>"${file_list}" || rt_query=1
		print_message
		
		### GET USERDATA OF USER #################
		printf "%s" "[${script_name}][INFO] Looking for userdata of ${user}..."
		if [ -d "${script_path}/userdata/${user}" ]
		then
			echo "userdata/${user}/" >>"${file_list}" || rt_query=1
		fi
		print_message
		
		total_size=$(wc -l <"${file_list}")
		if [ "${total_size}" -gt 0 ]
		then
			printf "%s" "[${script_name}][INFO] Pack archive..."
			stamp=$(date +%s)
			tar -cvf "${user}_${stamp}.tar" -T "${file_list}" >/dev/null 2>/dev/null || rt_query=1
			print_message
			if [ "${rt_query}" -eq 0 ]
			then
				printf "%s\n" "[${script_name}][INFO] Userprofile -> ${user}_${stamp}.tar"
			else
				add_trap_command '[ -e "${script_path}/${user}_${stamp}.tar" ] && rm -f -- "${script_path}/${user}_${stamp}.tar"'
			fi
		else
			printf "%s\n" "[${script_name}][INFO] No files found"
			rt_query=1
		fi
		printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${rt_query})"
}
### SET VARIABLES ############
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")
rt_query=0
user=$1
if [ -n "${user}" ]
then
	get_user "${user}"
else
	printf "%s\n" "[${script_name}][ERROR] You have to handover a user: ./${script_name} ADDRESS"
fi
#### DISPLAY OUTPUT ##########
printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${rt_query})"
