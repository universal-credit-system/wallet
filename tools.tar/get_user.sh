#!/bin/sh
get_user(){
		username=$1
		file_list="${script_path}/ExtrUser_${my_pid}.tmp"
		echo "INFO: CHECK KEYS..."
		if [ -s ${script_path}/keys/${username} ]
		then
			echo "keys/${username}" >${file_list}
		fi
		echo "INFO: CHECK PROOFS..."
		if [ -d ${script_path}/proofs/${username} ]
		then
			echo "proofs/${username}/" >>${file_list}
		fi
		echo "INFO: CHECK TRX..."
		trx_total=`ls -1 ${script_path}/trx/|grep "${username}"|wc -l`
		if [ $trx_total -gt 0 ]
		then
			for each_trx in `ls -1 ${script_path}/trx/|grep "${username}"`
			do
				echo "trx/${each_trx}" >>${file_list}
			done
		fi
		echo "INFO: CHECK USERDATA..."
		if [ -d ${script_path}/userdata/${username} ]
		then
			echo "userdata/${username}/" >>${file_list}
		fi
		total_size=`cat ${file_list}|wc -l`
		if [ $total_size -gt 0 ]
		then
			echo "INFO: PACK ARCHIVE..."
			tar -cf ${username}_$(date +%s).tar -T ${file_list}
			rt_query=$?
		else
			echo "INFO: NO FILES FOUND..."
			rt_query=1
		fi
		echo "INFO: EXIT (${rt_query})..."
		rm ${file_list} 2>/dev/null
}

##################
#Main Menu Screen#
##################
my_pid=$$
script_path=$(dirname $(readlink -f ${0}))
username=$1
get_user $username
