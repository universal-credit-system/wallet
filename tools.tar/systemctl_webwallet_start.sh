#!/bin/sh
sudo systemctl start nginx && sudo systemctl start php8.2-fpm
