#!/bin/sh
copy_path=$(echo "${1}"|sed 's/\/$//g')
echo "INFO: CREATE TAR-FILE..."
tar -cvf contractor.tar contracts/ rulesets/ control/contractor_HELP.txt ucs_contractor.sh
rt_query=$?
if [ $rt_query = 0 ]
then
	echo "INFO: TAR-FILE SUCCESSFULLY CREATED..."
	if [ ! -z $copy_path -a -d $copy_path ]
	then
		echo "INFO: COPY TAR-FILE..."
		cp contractor.tar ${copy_path}/contractor.tar
		rt_query=$?
                if [ $rt_query = 0 ]
                then
                        echo "INFO: ARCHIVE SUCCESSFULLY COPIED..."
                else
                        echo "ERROR: COULD NOT COPY ARCHIVE TO DIRECTORY ${copy_path}!"
			rm contractor.tar
                fi
	else
		echo "ERROR: COULD NOT COPY ARCHIVE TO ${copy_path}!"
		rm contractor.tar
	fi
else
	echo "ERROR: COULD NOT CREATE ARCHIVE!"
fi
echo "INFO: EXIT (${rt_query})"
echo 
