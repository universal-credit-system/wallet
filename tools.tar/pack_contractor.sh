#!/bin/sh
copy_path=$(echo "${1}"|sed 's/\/$//g')
echo "[ INFO ] Create tar file..."
tar -cvf contractor.tar contracts/ rulesets/ control/contractor_HELP.txt ucs_contractor.sh
rt_query=$?
if [ "${rt_query}" -eq 0 ]
then
	echo "[ INFO ] Tar file created..."
	if [ ! -z "${copy_path}" ] && [ -d "${copy_path}" ]
	then
		echo "[ INFO ] Copy tar file to ${copy_path}..."
		cp -- contractor.tar "${copy_path}"/contractor.tar
		rt_query=$?
                if [ "${rt_query}" -eq 0 ]
                then
                        echo "[ INFO ] File copied..."
                else
			echo "[ ERROR ] Could not copy file..."
                fi
        fi
else
	echo "[ ERROR ] Could not copy file..."
fi
echo "[ INFO ] EXIT (${rt_query})"

