#!/bin/sh
###GET SCRIPT PATH############################
script_path=$(dirname $(readlink -f "${0}"))

###SET VARIABLES##############################
cmd_user_to_keep="*"
cmd_user_to_purge=""

###CHECK FOR STDIN INPUT######################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi
if [ $# -gt 0 ]
then
	cmd_var=""
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case $1 in
			"-keep")	cmd_var=$1
					;;
			"-purge")	cmd_var=$1
					;;
			"-debug")	set -x
					set -v
					;;
			"-help")	echo "Usage: ./purge_users [-keep <USER>] [-purge <USER>]"
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case $cmd_var in
						"-keep")	cmd_user_to_keep=$1
								;;
						"-purge")	cmd_user_to_purge=$1
								;;
						*)		echo "ERROR Usage: ./purge_users [-keep <USER>] [-purge <USER>]"
								exit 1
					esac
					;;
		esac
		shift
	done
fi
###OUTPUT########################
ls -1 ${script_path}/keys|grep "${cmd_user_to_purge}"|grep -v "${cmd_user_to_keep}"
printf "%b" "Do you really want to delete these users? Please confirm [Y/N]: "
read uaction
printf "%b" "Do you want to purge trx of these users? Please confirm [Y/N]: "
read trxuaction
if [ "${uaction}" = "Y" ]
then
	###CHECK IF VARIABLE IS EMPTY####
	for each_user in $(ls -1 ${script_path}/keys|grep "${cmd_user_to_purge}"|grep -v "${cmd_user_to_keep}")
	do
		### GET KEY DATA ################
		printf "%b" "INFO: Get fingerprint of ${each_user}..."
		key_fp=$(gpg --no-default-keyring --keyring=${script_path}/control/keyring.file --with-colons --list-keys $each_user|sed -n 's/^fpr:::::::::\([[:alnum:]]\+\):/\1/p')
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			### SUCCESS MESSAGE ##############################
			printf "%b" "DONE\n"

			### REMOVE PRIVATE KEY FROM KEYRING ##############
			printf "%b" "INFO: Delete secret key of ${each_user} from keyring control/keyring.file..."
			gpg --batch --yes --no-default-keyring --keyring=${script_path}/control/keyring.file --delete-secret-keys ${key_fp} 2>/dev/null
			printf "%b" "DONE\n"

			### REMOVE PUBLICE KEY FROM KEYRING ##############
			printf "%b" "INFO: Delete public key of ${each_user} from keyring control/keyring.file..."
			gpg --batch --yes --no-default-keyring --keyring=${script_path}/control/keyring.file --delete-keys ${key_fp} 2>/dev/null
			printf "%b" "DONE\n"
		else
			### FAIL MESSAGE #################################
			printf "%b" "FAILED\n"
		fi
		### REMOVE USERDATA ########
		printf "%b" "INFO: Delete userdata of ${each_user}..."
		rm -R ${script_path}/userdata/${each_user}/
		printf "%b" "DONE\n"

		### REMOVE PROOFS ##########
		printf "%b" "INFO: Delete proofs of ${each_user}..."
		rm -R ${script_path}/proofs/${each_user}/
		printf "%b" "DONE\n"

		### REMOVE KEYFILES #########
		printf "%b" "INFO: Delete public key file of ${each_user}..."
		rm ${script_path}/keys/${each_user}
		printf "%b" "DONE\n"
		printf "%b" "INFO: Delete private key file of ${each_user}..."
		rm ${script_path}/control/keys/${each_user}
		printf "%b" "DONE\n"
		printf "%b" "INFO: Delete secret file of ${each_user}..."
		rm ${script_path}/control/keys/${each_user}.sct
		printf "%b" "DONE\n"

		### REMOVE USER'S TRX ######
		if [ "${trxuaction}" = "Y" ]
		then
			printf "%b" "INFO: Delete transactions of ${each_user}..."
			rm ${script_path}/trx/${each_user}.*
			printf "%b" "DONE\n"
		fi
	done
	echo "Finished...EXIT"
else
	echo "Aborted...EXIT"
fi
