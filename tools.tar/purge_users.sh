#!/bin/sh
print_message(){
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%b" "DONE\n"
		else
			printf "%b" "FAILED\n"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}
###GET SCRIPT PATH############################
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")
error_counter=0

###SET VARIABLES##############################
cmd_user_to_keep="*"
cmd_user_to_purge=""

###CHECK FOR STDIN INPUT######################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi
if [ $# -gt 0 ]
then
	cmd_var=""
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case $1 in
			"-keep")	cmd_var=$1
					;;
			"-purge")	cmd_var=$1
					;;
			"-debug")	set -x
					set -v
					;;
			"-help")	printf "%s\n" "[${script_name}][INFO][parser] Usage: ./purge_users [-keep <USER>] [-purge <USER>]"
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case "${cmd_var}" in
						"-keep")	cmd_user_to_keep=$1
								;;
						"-purge")	cmd_user_to_purge=$1
								;;
						*)		printf "%s\n" "[${script_name}][ERROR][parser] Usage: ./purge_users [-keep <USER>] [-purge <USER>]"
								exit 1
					esac
					;;
		esac
		shift
	done
fi
###OUTPUT########################
ls -1U ${script_path}/keys|grep -- "${cmd_user_to_purge}"|grep -v -- "${cmd_user_to_keep}"
printf "%b" "[${script_name}][INFO] Do you really want to delete these users? Please confirm [Y/N]: "
read uaction
printf "%b" "[${script_name}][INFO] Do you want to purge trx of these users? Please confirm [Y/N]: "
read trxuaction
if [ "${uaction}" = "Y" ]
then
	###CHECK IF VARIABLE IS EMPTY####
	for each_user in $(ls -1U ${script_path}/keys|grep -- "${cmd_user_to_purge}"|grep -v -- "${cmd_user_to_keep}")
	do
		### GET KEY DATA ################
		printf "%b" "[${script_name}][INFO] Get fingerprint of ${each_user}..."
		key_fp=$(gpg --no-default-keyring --keyring=${script_path}/control/keyring.file --with-colons --list-keys "${each_user}"|sed -n 's/^fpr:::::::::\([[:alnum:]]\+\):/\1/p')
		rt_query=$?
		if [ "${rt_query}" -eq 0 ]
		then
			print_message "${rt_query}"

			### REMOVE PRIVATE KEY FROM KEYRING ##############
			printf "%b" "[${script_name}][INFO] Delete secret key of ${each_user} from keyring control/keyring.file..."
			gpg --batch --yes --no-default-keyring --keyring=${script_path}/control/keyring.file --delete-secret-keys ${key_fp} 2>/dev/null || rt_query=1
			print_message "${rt_query}"

			### REMOVE PUBLICE KEY FROM KEYRING ##############
			printf "%b" "[${script_name}][INFO] Delete public key of ${each_user} from keyring control/keyring.file..."
			gpg --batch --yes --no-default-keyring --keyring=${script_path}/control/keyring.file --delete-keys ${key_fp} 2>/dev/null || rt_query=1
			print_message "${rt_query}"
		else
			print_message "${rt_query}"
		fi
		### REMOVE USERDATA ########
		printf "%b" "[${script_name}][INFO] Delete userdata of ${each_user}..."
		rm -rf -- "${script_path}/userdata/${each_user}"/ || rt_query=1
		print_message "${rt_query}"

		### REMOVE PROOFS ##########
		printf "%b" "[${script_name}][INFO] Delete proofs of ${each_user}..."
		rm -rf -- "${script_path}/proofs/${each_user}"/ || rt_query=1
		print_message "${rt_query}"

		### REMOVE KEYFILES #########
		printf "%b" "[${script_name}][INFO] Delete public key file of ${each_user}..."
		rm -f -- ${script_path}/keys/${each_user} || rt_query=1
		print_message "${rt_query}"

		printf "%b" "[${script_name}][INFO] Delete private key file of ${each_user}..."
		rm -f -- ${script_path}/control/keys/${each_user} || rt_query=1
		print_message "${rt_query}"

		printf "%b" "[${script_name}][INFO] Delete secret file of ${each_user}..."
		rm -f -- ${script_path}/control/keys/${each_user}.sct || rt_query=1
		print_message "${rt_query}"

		### REMOVE USER'S TRX ######
		if [ "${trxuaction}" = "Y" ]
		then
			printf "%b" "[${script_name}][INFO] Delete transactions of ${each_user}..."
			rm -f -- ${script_path}/trx/${each_user}.* || rt_query=1
			print_message "${rt_query}"
		fi
	done
	### DISPLAY OUTPUT ##########
	printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})"
else
	### DISPLAY OUTPUT ##########
	printf "%s\n" "[${script_name}][ERROR] Aborted...EXIT"
fi
