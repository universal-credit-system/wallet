#!/bin/sh

###USER TO KEEP##################
user_to_keep=$1

###GET SCRIPT PATH###############
script_path=$(dirname $(readlink -f ${0}))

###CHECK IF VARIABLE IS EMPTY####
for each_user in `ls -1 ${script_path}/keys`
do
	if [ ! "${each_user}" = "${user_to_keep}" ]
	then
		rm -R ${script_path}/userdata/${each_user}/
		rm -R ${script_path}/proofs/${each_user}/
		rm ${script_path}/keys/${each_user}
		rm ${script_path}/trx/${each_user}.*
	fi
done
