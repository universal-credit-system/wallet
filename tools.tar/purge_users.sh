#!/bin/sh
###GET SCRIPT PATH############################
script_path=$(dirname $(readlink -f "${0}"))

###SET VARIABLES##############################
cmd_user_to_keep="*"
cmd_user_to_purge=""

###CHECK FOR STDIN INPUT######################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi
if [ $# -gt 0 ]
then
	cmd_var=""
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case $1 in
			"-keep")	cmd_var=$1
					;;
			"-purge")	cmd_var=$1
					;;
			"-debug")	set -x
					set -v
					;;
			"-help")	echo "Usage: ./purge_users [-keep <USER>] [-purge <USER>]"
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case $cmd_var in
						"-keep")	cmd_user_to_keep=$1
								;;
						"-purge")	cmd_user_to_purge=$1
								;;
						*)		echo "ERROR Usage: ./purge_users [-keep <USER>] [-purge <USER>]"
								exit 1
					esac
					;;
		esac
		shift
	done
fi
###OUTPUT########################
ls -1 ${script_path}/keys|grep "${cmd_user_to_purge}"|grep -v "${cmd_user_to_keep}"
printf "%b" "Do you really want to delete these users? Please confirm [Y/N]: "
read uaction
if [ "${uaction}" = "Y" ]
then
	###CHECK IF VARIABLE IS EMPTY####
	for each_user in $(ls -1 ${script_path}/keys|grep "${cmd_user_to_purge}"|grep -v "${cmd_user_to_keep}")
	do
		### PURGE KEYRING ###########
		key_fp=$(gpg --no-default-keyring --keyring=${script_path}/control/keyring.file --with-colons --list-keys $each_user|sed -n 's/^fpr:::::::::\([[:alnum:]]\+\):/\1/p')
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			gpg --batch --yes --no-default-keyring --keyring=${script_path}/control/keyring.file --delete-secret-keys ${key_fp} 2>/dev/null
			gpg --batch --yes --no-default-keyring --keyring=${script_path}/control/keyring.file --delete-keys ${key_fp} 2>/dev/null
		fi
		### REMOVE USERDATA ########
		rm -R ${script_path}/userdata/${each_user}/

		### REMOVE PROOFS ##########
		rm -R ${script_path}/proofs/${each_user}/

		### REMOVE KEYFILES #########
		rm ${script_path}/keys/${each_user}
		rm ${script_path}/control/keys/${each_user}
		rm ${script_path}/control/keys/${each_user}.sct

		### REMOVE USER'S TRX ######
		rm ${script_path}/trx/${each_user}.*
	done
else
	echo "Aborted..."
fi
