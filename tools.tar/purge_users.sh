#!/bin/sh

###USER TO KEEP##################
user_to_keep=$1

###GET SCRIPT PATH###############
script_path=$(dirname $(readlink -f ${0}))

###CHECK IF VARIABLE IS EMPTY####
for each_user in $(ls -1 ${script_path}/keys)
do
	if [ ! "${each_user}" = "${user_to_keep}" ]
	then
		### PURGE KEYRING ###########
		key_fp=$(gpg --no-default-keyring --keyring=${script_path}/control/keyring.file --with-colons --list-keys ${key_file}|sed -n 's/^fpr:::::::::\([[:alnum:]]\+\):/\1/p')
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			gpg --batch --yes --no-default-keyring --keyring=${script_path}/control/keyring.file --delete-secret-keys ${key_fp} 2>/dev/null
			gpg --batch --yes --no-default-keyring --keyring=${script_path}/control/keyring.file --delete-keys ${key_fp} 2>/dev/null
		fi
		### REMOVE USERDATA ########
		rm -R ${script_path}/userdata/${each_user}/

		### REMOVE PROOFS ##########
		rm -R ${script_path}/proofs/${each_user}/

		### REMOVE KEYFILES #########
		rm ${script_path}/keys/${each_user}
		rm ${script_path}/control/keys/${each_user}
		rm ${script_path}/control/keys/${each_user}.sct

		### REMOVE USER'S TRX ######
		rm ${script_path}/trx/${each_user}.*
	fi
done
