#!/bin/sh

###DISPLAY OUTPUT#######################
printf "termux_webwallet_stop.sh: $(date -u): stop nginx...\n"

###START NGINX AND PHP-FPM##############
nginx -s stop

###DISPLAY OUTPUT#######################
printf "termux_webwallet_stop.sh: $(date -u): nginx stopped\n"

###DISPLAY OUTPUT#######################
printf "termux_webwallet_stop.sh: $(date -u): stop php-fpm...\n"

###GET PHP MASTER PID AND KILL##########
php_pid=$(ps -ef|grep "php"|grep "master"|grep -v "grep"|awk '{print $2}')
if [ -n "${php_pid}" ]
then
	kill $php_pid
fi

###DISPLAY OUTPUT#######################
printf "termux_webwallet_stop.sh: $(date -u): php-fpm stopped\n"
printf "termux_webwallet_stop.sh: $(date -u): bye bye\n"
