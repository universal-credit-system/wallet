#!/bin/sh

###DISPLAY OUTPUT#######################
printf "termux_webwallet_stop.sh: $(date -u): stop nginx...\n"

###START NGINX AND PHP-FPM##############
nginx -s stop

###DISPLAY OUTPUT#######################
printf "termux_webwallet_stop.sh: $(date -u): nginx stopped\n"

###DISPLAY OUTPUT#######################
printf "termux_webwallet_stop.sh: $(date -u): stop php-fpm...\n"

###GET PHP MASTER PID AND KILL##########
php_pid=`ps -ef|grep "php"|grep "master"|awk '{print $2}'`
kill $php_pid

###DISPLAY OUTPUT#######################
printf "termux_webwallet_stop.sh: $(date -u): php-fpm stopped\n"
printf "termux_webwallet_stop.sh: $(date -u): bye bye\n"
