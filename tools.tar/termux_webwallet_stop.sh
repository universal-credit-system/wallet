#!/bin/sh
###SET VARIABLES########################
script_name=$(basename "$0")
rt_query=0

###DISPLAY OUTPUT#######################
printf "%s\n" "${script_name}: $(date -u): stop nginx..."

###START NGINX AND PHP-FPM##############
nginx -s stop || rt_query=1
if [ "${rt_query}" -eq 0 ]
then
	###DISPLAY OUTPUT#######################
	printf "%s\n" "${script_name}: $(date -u): nginx stopped"
else
	###DISPLAY OUTPUT#######################
	printf "%s\n" "${script_name}: $(date -u): error stopping nginx"
	rt_query=0
fi

###GET PHP MASTER PID AND KILL##########
php_pids=$(ps -ef|awk -v master="php-fpm: master" '$0 ~ master && $0 !~ /awk/ { print $2 }')
for php_master_process in ${php_pids}
do
	###DISPLAY OUTPUT#######################
	printf "%s\n" "${script_name}: $(date -u): stop php-fpm master process with PID ${php_master_process}..."
	kill -TERM "${php_master_process}" || rt_query=1
	if [ "${rt_query}" -eq 0 ]
	then
		printf "%s\n" "${script_name}: $(date -u): php-fpm master process with PID ${php_master_process} stopped"
	else
		printf "%s\n" "${script_name}: $(date -u): error stopping php-fpm master process with PID ${php_master_process}"
	fi
done

###DISPLAY OUTPUT#######################
printf "%s\n" "${script_name}: $(date -u): bye bye"
