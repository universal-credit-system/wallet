<?php
        $uname = escapeshellarg(htmlspecialchars($_POST['user_name']));
        $suname = preg_replace("/[^A-Za-z0-9]/", "", $uname);
	$pin = escapeshellarg(htmlspecialchars($_POST['user_pin']));
        $spin = preg_replace("/[^A-Za-z0-9]/", "", $pin);
        $psw  = escapeshellarg(htmlspecialchars($_POST['user_psw']));
        $spsw = preg_replace("/[^A-Za-z0-9]/", "", $psw);
	$uaction = escapeshellarg(htmlspecialchars($_POST['user_action']));;
        $suaction = preg_replace("/[^A-Za-z0-9]/", "", $uaction);
	if (strpos($suaction, 'login') !== false or strpos($suaction, 'sync') !== false or strpos($suaction, 'create') !== false) {
		$output = shell_exec('/home/m0e/wallet/webwallet.sh "'.$suaction.'" "'.$suname.'" "'.$spin.'" "'.$spsw.'"');
	} else {
		if (strpos($suaction, 'send') !== false) {
			$asset = escapeshellarg(htmlspecialchars($_POST['asset']));;
        		$sasset = preg_replace("/[^A-Za-z0-9.]/", "", $asset);
			$amount = escapeshellarg(htmlspecialchars($_POST['amount']));;
        		$samount = preg_replace("/[^0-9.]/", "", $amount);
       			$receiver = escapeshellarg(htmlspecialchars($_POST['receiver']));
        		$sreceiver = preg_replace("/[^A-Za-z0-9.]/", "", $receiver);
        		$purpose  = escapeshellarg(htmlspecialchars($_POST['purpose']));
       			$spurpose = preg_replace("/[^A-Za-z0-9]/", "", $purpose);
			$output = shell_exec('/home/m0e/wallet/webwallet.sh "'.$suaction.'" "'.$suname.'" "'.$spin.'" "'.$spsw.'" "'.$sasset.'" "'.$samount.'" "'.$sreceiver.'" "'.$purpose.'"');	
		} else {
			$output = http_response_code(404);
		}
	}
        echo "$output";
?>
