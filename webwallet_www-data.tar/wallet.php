<?php
	$target_dir = "<<WALLET_INSTALL_PATH>>/webwallet/";
	$upload_max_size = 500000;
        $uname = escapeshellarg(htmlspecialchars($_POST['user_name']));
        $suname = preg_replace("/[^A-Za-z0-9]/", "", $uname);
	$pin = escapeshellarg(htmlspecialchars($_POST['user_pin']));
        $spin = preg_replace("/[^A-Za-z0-9]/", "", $pin);
        $psw  = escapeshellarg(htmlspecialchars($_POST['user_psw']));
        $spsw = preg_replace("/[^A-Za-z0-9]/", "", $psw);
	$uaction = escapeshellarg(htmlspecialchars($_POST['user_action']));
        $suaction = preg_replace("/[^A-Za-z0-9_]/", "", $uaction);
	if (strpos($suaction, 'login_account') !== false or strpos($suaction, 'sync_uca') !== false or strpos($suaction, 'create_account') !== false or strpos($suaction, 'delete_account') !== false) {
		$output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh "'.$suaction.'" "'.$suname.'" "'.$spin.'" "'.$spsw.'"');
		echo "$output";
	} else {
		if (strpos($suaction, 'send_trx') !== false) {
			$asset = escapeshellarg(htmlspecialchars($_POST['asset']));
        		$sasset = preg_replace("/[^A-Za-z0-9.]/", "", $asset);
			$amount = escapeshellarg(htmlspecialchars($_POST['amount']));
        		$samount = preg_replace("/[^0-9.]/", "", $amount);
       			$receiver = escapeshellarg(htmlspecialchars($_POST['receiver']));
        		$sreceiver = preg_replace("/[^A-Za-z0-9.]/", "", $receiver);
        		$purpose  = escapeshellarg(htmlspecialchars($_POST['purpose']));
       			$spurpose = preg_replace("/[^A-Za-z0-9]/", "", $purpose);
			$output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh "'.$suaction.'" "'.$suname.'" "'.$spin.'" "'.$spsw.'" "'.$sasset.'" "'.$samount.'" "'.$sreceiver.'" "'.$purpose.'"');
			echo "$output";
		} else {
			if (strpos($suaction, 'download_account') !== false or strpos($suaction, 'download_sync') !== false) {
				echo "works";
				$file_output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh "'.$suaction.'" "'.$suname.'" "'.$spin.'" "'.$spsw.'"');
				$file = str_replace(array("\n"), '', $file_output);
				if (file_exists($file)) {
					header('Content-Description: File Transfer');
					header('Content-Type: application/octet-stream');
					header('Content-Disposition: attachment; filename="'.basename($file).'"');
					header('Expires: 0');
					header('Cache-Control: must-revalidate');
					header('Pragma: public');
					header('Content-Length: ' . filesize($file));
					readfile($file);
					unlink($file);
					exit();
				} else {
					var_dump(http_response_code(400));
				}
			} else {
				if (strpos($suaction, 'upload_file') !== false) {
					$fname = escapeshellarg(htmlspecialchars($_FILES["file"]["name"]));
					$target_file = $target_dir . $fname;
					$filetype = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
					$upload_ok = 1;
					if ($_FILES["file"]["size"] > $upload_max_size) {
  						echo '<script type="text/javascript" language="Javascript">alert("ERROR: File is too big!")</script>';
  						$upload_ok = 0;
					}
					if($filetype != "trx" && $filetype != "sync" ) {
  						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Only *.trx and *.sync files are allowed for upload!")</script>';
  						$upload_ok = 0;
					}
					if ($upload_ok = 0) {
  						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Error during upload!")</script>';
					} else {
						$fname = basename($_FILES["file"]["tmp_name"]);
						$target_file = $target_dir . $fname;
  						if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
							if($filetype == "trx") {
								$suaction = 'read_trx';
							} else {
								$suaction = 'read_sync';
							}
							$output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh "'.$suaction.'" "'.$suname.'" "'.$spin.'" "'.$spsw.'" "'.$target_file.'"');
							echo "$output";
							unlink($target_file);
						}
					}
				} else {
					var_dump(http_response_code(400));
				}
			}
		}
	}
?>
