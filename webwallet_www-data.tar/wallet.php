<?php
	$target_dir = "<<WALLET_INSTALL_PATH>>/webwallet/";
	$upload_max_size = 500000;
	if (isset($_POST['user_action'])) {
		$uaction = preg_replace("/[^A-Za-z0-9_]/", "", $_POST['user_action']);
		if (strpos($uaction, 'login_account') !== false) {
			$uname = preg_replace("/[^A-Za-z0-9]/", "", $_POST['user_name']);
			$pin = preg_replace("/[^A-Za-z0-9]/", "", $_POST['user_pin']);
			$psw = preg_replace("/[^A-Za-z0-9]/", "", $_POST['user_psw']);
			$ipaddr = $_SERVER['REMOTE_ADDR'];
			$output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh -action "'.$uaction.'" -user "'.$uname.'" -pin "'.$pin.'" -password "'.$psw.'" -ip "'.$ipaddr.'"');
			echo "$output";
		} else {
			if (isset($_POST['session_id']) && isset($_POST['session_key'])) {
				$session_id = preg_replace("/[^A-Za-z0-9]/", "", $_POST['session_id']);
				$session_key = preg_replace("/[^A-Za-z0-9]/", "", $_POST['session_key']);
				if (strpos($uaction, 'sync_uca') !== false or strpos($uaction, 'create_account') !== false or strpos($uaction, 'delete_account') !== false or strpos($uaction, 'logout_account') !== false) {
					$output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh -action "'.$uaction.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'"');
					echo "$output";
				} else {
					if (strpos($uaction, 'send_trx') !== false) {
						$asset = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['asset']);
						$amount = preg_replace("/[^0-9.]/", "", $_POST['amount']);
						$receiver = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['receiver']);
						$purpose = $_POST['purpose'];
						$purpose = urlencode($purpose);
						$tmp_id = uniqid();
						$file = "<<WALLET_INSTALL_PATH>>/webwallet/tmp/encoded_purpose_".$tmp_id.".tmp";
						file_put_contents($file,$purpose);
						$output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh -action "'.$uaction.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -asset "'.$asset.'" -amount "'.$amount.'" -receiver "'.$receiver.'" -path "'.$file.'"');
						unlink($file);
						echo "$output";
					} else {
						if (strpos($uaction, 'show_trx') !== false) {
							$trx_file = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['trx_file']);
							$output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh -action "'.$uaction.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'" -path "'.$trx_file.'"');
							echo "$output";
						} else {
							if (strpos($uaction, 'download_account') !== false or strpos($uaction, 'download_sync') !== false) {
								$file_output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh -action "'.$uaction.'" -session_id "'.$session_id.'" -session_key "'.$session_key.'"');
								$file = str_replace(array("\n"), '', $file_output);
								if (file_exists($file)) {
									header('Content-Description: File Transfer');
									header('Content-Type: application/octet-stream');
									header('Content-Disposition: attachment; filename="'.basename($file).'"');
									header('Expires: 0');
									header('Cache-Control: must-revalidate');
									header('Pragma: public');
									header('Content-Length: ' . filesize($file));
									readfile($file);
									unlink($file);
									exit();
								} else {
									var_dump(http_response_code(400));
								}
							} else {
								if (strpos($uaction, 'upload_file') !== false) {
									$fname = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
									$filetype = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
									$target_file = $target_dir.$fname.'.'.$filetype;
									$upload_ok = 1;
									if ($_FILES["file"]["size"] > $upload_max_size) {
										echo '<script type="text/javascript" language="Javascript">alert("ERROR: File is too big!")</script>';
										$upload_ok = 0;
									}
									if ($upload_ok = 0) {
										echo '<script type="text/javascript" language="Javascript">alert("ERROR: Error during upload!")</script>';
									} else {
										if(file_exists($target_file)) {
			  								$id = 1;
											do {
			      									$target_file = $target_dir.$fname.'_'.$id.'.'.$filetype;
			     									$id++;
			   								} while(file_exists($target_file));
										}
										if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
											if($filetype == "trx") {
												$uaction = 'read_trx';
											} else {
												$uaction = 'read_sync';
											}
											$output = shell_exec('<<WALLET_INSTALL_PATH>>/webwallet.sh -action "'.$suaction.'" -session_id "'.$ssession_id.'" -session_key "'.$ssession_key.'" -path "'.$target_file.'"');
											echo "$output";
											unlink($target_file);
										}
									}
								} else {
									var_dump(http_response_code(400));
								}
							}
						}
					}
				}
			} else {
				readfile("index.html");
			}
		}
	} else {
		readfile("index.html");
	}
?>
