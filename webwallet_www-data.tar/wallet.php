<?php
function run_webwallet(array $params, string $wallet_path): array
{
    $descriptors = [
        0 => ['pipe', 'r'], // stdin
        1 => ['pipe', 'w'], // stdout
        2 => ['pipe', 'w'], // stderr
    ];

    $cmd = $wallet_path . '/webwallet.sh';
    $proc = proc_open($cmd, $descriptors, $pipes);

    if (!is_resource($proc)) {
        throw new RuntimeException('proc_open failed');
    }

    $input = '';
    foreach ($params as $k => $v) {
        $input .= "{$k} {$v}\n";
    }

    fwrite($pipes[0], $input);
    fclose($pipes[0]);

    $stdout = stream_get_contents($pipes[1]);
    fclose($pipes[1]);

    $stderr = stream_get_contents($pipes[2]);
    fclose($pipes[2]);

    $code = proc_close($proc);

    return [
        'code' => $code,
        'stdout' => $stdout,
        'stderr' => $stderr,
    ];
}
const upload_max_size = 500000;
const STATUS_BAD_REQUEST = 400;
$wallet_path = "<<WALLET_INSTALL_PATH>>";
$target_dir = $wallet_path."/webwallet/tmp/";
$ipaddr = $_SERVER['REMOTE_ADDR'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (isset($_POST['user_action'])) {
		$action = preg_replace("/[^A-Za-z0-9_]/", "", $_POST['user_action']);
		if ($action === 'get_users') {
			$result = run_webwallet([
			    '-action' => $action,
			], $wallet_path);
			echo $result['stdout'];
		} else {
			if ($action === 'check_name' && isset($_POST['user_name'])) {
				$name = preg_replace("/[^A-Za-z0-9]/", "", $_POST['user_name']);
				$result = run_webwallet([
				    '-action' => $action,
				    '-user' => $name
				], $wallet_path);
				echo $result['stdout'];
			} else {
				if ($action === 'login_account' or $action === 'create_account') {
					if (isset($_POST['user_name']) && isset($_POST['user_pin']) && isset($_POST['user_psw'])) {
						$name = preg_replace("/[^A-Za-z0-9]/", "", $_POST['user_name']);
						$pin = preg_replace("/[^A-Za-z0-9]/", "", $_POST['user_pin']);
						$password = preg_replace("/[^A-Za-z0-9]/", "", $_POST['user_psw']);
						if (isset($_POST['msig_data'])) {
							$msig = preg_replace("/[^A-Za-z0-9,]/", "", $_POST['msig_data']);
						} else {
							$msig = '';
						}
						$result = run_webwallet([
						    '-action'	=> $action,
						    '-user'	=> $name,
						    '-pin'	=> $pin,
						    '-password'	=> $password,
						    '-msig'	=> $msig,
						    '-ip'	=> $ipaddr
						], $wallet_path);
						echo $result['stdout'];
					} else {
						readfile("index.html");
					}
				} else {
					if (isset($_POST['session_id']) && isset($_POST['session_key'])) {
						$session_id = preg_replace("/[^A-Za-z0-9]/", "", $_POST['session_id']);
						$session_key = preg_replace("/[^A-Za-z0-9]/", "", $_POST['session_key']);
						if ($action === 'sync_uca' or $action === 'delete_account' or $action === 'logout_account') {
							$result = run_webwallet([
							    '-action'	=> $action,
							    '-session_id'	=> $session_id,
							    '-session_key'	=> $session_key,
							    '-ip'	=> $ipaddr
							], $wallet_path);
							echo $result['stdout'];
						} else {
							if ($action === 'send_trx') {
								if (isset($_POST['msig_data'])) {
									$msig = preg_replace("/[^A-Za-z0-9,]/", "", $_POST['msig_data']);
								} else {
									$msig = '';
								}
								if (isset($_POST['asset'])) {
									$asset = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['asset']);
								} else {
									$asset = '';
								}
								if (isset($_POST['amount'])) {
									$amount = preg_replace("/[^0-9.]/", "", $_POST['amount']);
								} else {
									$amount = '';
								}
								if (isset($_POST['receiver'])) {
									$receiver = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['receiver']);
								} else {
									$receiver = '';
								}
								if (isset($_POST['purpose'])) {
									$purpose = $_POST['purpose'];
									$purpose = urlencode($purpose);
								} else {
									$purpose = '';
								}
								$tmp_id = uniqid();
								$file = $wallet_path."/webwallet/tmp/encoded_purpose_".$tmp_id.".tmp";
								file_put_contents($file,$purpose);
								$result = run_webwallet([
								    '-action'	=> $action,
								    '-session_id'	=> $session_id,
							    	    '-session_key'	=> $session_key,
								    '-ip'	=> $ipaddr,
								    '-msig'	=> $msig,
								    '-asset'	=> $asset,
								    '-amount'	=> $amount,
								    '-receiver'	=> $receiver,
								    '-path'	=> $file
								], $wallet_path);
								echo $result['stdout'];
								if (file_exists($file)) {
		    							unlink($file);
								}
							} else {
								if ($action === 'show_trx' or $action === 'sign_trx') {
									$file = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['trx_file']);
									$result = run_webwallet([
									    '-action'	=> $action,
									    '-session_id'	=> $session_id,
							    		    '-session_key'	=> $session_key,
									    '-ip'	=> $ipaddr,
									    '-path'	=> $file
									], $wallet_path);
									echo $result['stdout'];
								} else {
									if ($action === 'download_account' or $action === 'download_sync') {
										$result = run_webwallet([
										    '-action'	=> $action,
										    '-session_id'	=> $session_id,
							    			    '-session_key'	=> $session_key,
										    '-ip'	=> $ipaddr
										], $wallet_path);
										$file = str_replace(array("\n"), '', $result['stdout']);
										if (file_exists($file)) {
											header('Content-Description: File Transfer');
											header('Content-Type: application/octet-stream');
											header('Content-Disposition: attachment; filename="'.basename($file).'"');
											header('Expires: 0');
											header('Cache-Control: must-revalidate');
											header('Pragma: public');
											header('Content-Length: ' . filesize($file));
											readfile($file);
											if (file_exists($file)) {
					    							unlink($file);
											}
											
										} else {
											var_dump(http_response_code(STATUS_BAD_REQUEST));
										}
									} else {
										if ($action === 'upload_file') {
											$fname = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
											$filetype = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
											$target_file = $target_dir.$fname.'.'.$filetype;
											$upload_ok = 1;
											if ($_FILES["file"]["size"] > $upload_max_size) {
												echo '<script type="text/javascript" language="Javascript">alert("ERROR: File is too big!")</script>';
												$upload_ok = 0;
											}
											if ($upload_ok == 0) {
												echo '<script type="text/javascript" language="Javascript">alert("ERROR: Error during upload!")</script>';
											} else {
												if(file_exists($target_file)) {
					  								$id = 1;
													do {
					      									$target_file = $target_dir.$fname.'_'.$id.'.'.$filetype;
					     									$id++;
					   								} while(file_exists($target_file));
												}
												if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
													if($filetype == "trx") {
														$action = 'read_trx';
													} else {
														$action = 'read_sync';
													}
													$result = run_webwallet([
													    '-action'	=> $action,
													    '-session_id'	=> $session_id,
							   						    '-session_key'	=> $session_key,
													    '-ip'	=> $ipaddr,
													    '-path'	=> $target_file
													], $wallet_path);
													echo $result['stdout'];
													if (file_exists($target_file)) {
							    							unlink($target_file);
													}
												}
											}
										} else {
											http_response_code(STATUS_BAD_REQUEST);
										}
									}
								}
							}
						}
					} else {
						http_response_code(STATUS_BAD_REQUEST);
					}
				}
			}
		}
	} else {
		http_response_code(STATUS_BAD_REQUEST);
	}
} else {
	readfile("index.html");
}
?>
