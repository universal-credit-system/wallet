#!/bin/sh
build_webwallet(){
			### SET VARIABLES ####################################
			main_string=""
			send_string=""

			### GET BALANCES #####################################
			echo "-action show_balance -sender ${cmd_sender}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >"${script_path}/webwallet/tmp/${my_pid}.out" 2>/dev/null
			rt_code=$?
			if [ "${rt_code}" -eq 0 ]
			then
				### FILL BALANCE STRING FOR THE MAIN FORM ##########
				main_string="    <h2 style=\"text-align:center\">Total balance<br></h2>\n"
				main_string="${main_string}    <table class=\"center-balance-table\">\n"

				### FILL BALANCE ARRAY FOR SEND FORM ###############
				send_string="var balanceObject = {\n"
				while read line
				do
					### GET DATA FROM OUTPUT ###########################
					balance=$(echo "${line}"|cut -d ':' -f3|cut -d '=' -f2)
					asset=$(echo "${line}"|cut -d ':' -f2)

					### FILL BALANCE STRING FOR THE MAIN FORM ##########
					main_string="${main_string}      <tr>\n        <td style=\"text-align:left\"><b>${asset}</b></td>\n        <td style=\"text-align:right\"><b>${balance}</b></td>\n      </tr>\n"

					### FILL BALANCE ARRAY FOR SEND FORM ###############
					if [ ! "${main_asset}" = "${cmd_asset}" ]
					then
						send_string="${send_string}  \"${asset}\":{\n    \"${balance}\": [\"1\"]\n  },\n"
					fi
				done <"${script_path}/webwallet/tmp/${my_pid}.out"

				### FILL BALANCE STRING FOR THE MAIN FORM ##########
				main_string="${main_string}    </table>\n"
				balance_string=$(printf "%b" "    <h2 style=\"text-align:center\">Address<br></h2>\n    <h4 style=\"text-align:center;word-break:break-all;word-wrap:break-word;\">${cmd_sender}<br></h4>\n${main_string}")
				####################################################

				### FILL BALANCE ARRAY FOR SEND FORM ###############
				send_string="${send_string} }"
				available_balances_string=$(printf "%b" "${send_string}")

				### FILL ASSET STRING FOR THE MAIN FORM ############
				addresses=$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.tmp -p "${script_path}"/webwallet/tmp/)
				addresses_base=$(basename "${addresses}")
				addresses_fungible=$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.tmp -p "${script_path}"/webwallet/tmp/)
				addresses_fungible_base=$(basename "${addresses_fungible}")
				main_string="var subjectObject = {\n"
				for asset in $(cat "${user_path}"/all_assets.dat)
				do
					is_fungible=$(grep -c "asset_fungible=1" "${script_path}/assets/${asset}")
					if [ "${is_fungible}" -eq 1 ]
					then
						echo "${asset}" >>"${addresses_fungible}"
					fi
				done
				for asset in $(cut -d ':' -f2 "${script_path}/webwallet/tmp/${my_pid}.out")
				do
					main_string="${main_string}  \"${asset}\": {\n"
					is_fungible=$(grep -c "asset_fungible=1" "${script_path}/assets/${asset}")
					if [ "${is_fungible}" -eq 1 ]
					then
						sort -t. -k2 "${addresses_fungible}"|grep -v -h "${cmd_sender}\|${asset}" - "${user_path}"/all_accounts.dat >"${addresses}"
					else
						grep -v "${cmd_sender}" "${user_path}"/all_accounts.dat >"${addresses}"
					fi
					while read line
					do
						main_string="${main_string}    \"${line}\": [\"1\"],\n"
					done <"${addresses}"
					main_string="${main_string}  },\n"
				done
				main_string="${main_string} }\n"
				asset_string=$(printf "%b" "${main_string}")
				rm -f -- "${addresses}"
				rm -f -- "${addresses_fungible}"
				####################################################
				
				### BUILD ARRAY FOR MULTI-SIGNATURE DROPDOWN #######
				main_string="var addressObject = {\n  \"${main_asset}\": {\n"
				for address in $(grep -v "${cmd_sender}" "${user_path}"/all_accounts.dat)
				do
					main_string="${main_string}    \"${address}\": [\"1\"],\n"
				done <"${user_path}"/all_accounts.dat
				main_string="${main_string}  }\n}\n"
				address_string=$(printf "%b" "${main_string}")

				### FILL HISTORY STRING FOR MAIN FORM ##############
				my_trx=$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.tmp -p "${script_path}"/webwallet/tmp/)
				my_trx_base=$(basename "${my_trx}")
				grep -s -l "SNDR:${cmd_sender}\|RCVR:${cmd_sender}" -- "${script_path}"/trx/*|sort -r -t . -k2 >"${my_trx}"
				if [ "$(wc -l <"${my_trx}")" -gt 0 ]
				then
					main_string="    <div style=\"height:300px;overflow-y:scroll;overflow-x:auto;scrollbar-color:#000000 #FFFFFF;font-family:Courier New;\">\n       <table class=\"center-history-table\">\n         <tr>\n          <th>Date</th>\n          <th>Address</th>\n          <th>Amount</th>\n          <th>Asset</th>\n          <th>Purpose</th>\n          <th>Status</th>\n          <th>Confirmations</th>\n         </tr>\n"
					while read trx_file_path
					do
						trx_status=""

						###GET TRANSACTION DATA################################
						trx_file=$(basename "${trx_file_path}")
						trx_hash=$(sha256sum "${trx_file_path}")
						trx_hash=${trx_hash%% *}
						IFS='|' read -r trx_stamp trx_sender trx_receiver trx_amount trx_asset <<-EOF
						$(awk -F: '
							/^:TIME:/ {stmp=$3}
							/^:SNDR:/ {sndr=$3}
							/^:RCVR:/ {rcvr=$3}
							/^:AMNT:/ {amnt=$3}
							/^:ASST:/ {asst=$3}
							END { printf "%s|%s|%s|%s|%s\n", stmp, sndr, rcvr, amnt, asst }
						' "${trx_file_path}")
						EOF
						trx_date=$(date +'%F %H:%M:%S' --date=@"${trx_stamp}")

						###GET CONFIRMATIONS###################################
						trx_confirmations=$(awk \
							-v trx_ref="trx/${trx_file} ${trx_hash}" \
							-v check_file="${user_path}/all_accounts.dat" \
							-v sndr="${trx_sender}" \
							-v rcvr="${trx_receiver}" \
							-f "${script_path}"/control/functions/get_confirmations.awk \
							"${script_path}"/proofs/*/*.txt)

						###CHECK INDEX FILE####################################
						if [ -s "${script_path}/proofs/${trx_sender}/${trx_sender}.txt" ]
						then
							is_indexed=$(grep -c "trx/${trx_file} ${trx_hash}" "${script_path}/proofs/${trx_sender}/${trx_sender}.txt")
						else
							is_indexed=0
						fi
						if [ "${is_indexed}" -eq 0 ]
						then
							trx_status="TRX_IGNORED "
						fi
						trx_blacklisted=$(grep -c "${trx_file}" "${user_path}"/blacklisted_trx.dat)
						if [ "${trx_blacklisted}" -eq 1 ]
						then
							trx_status="${trx_status}TRX_BLACKLISTED "
						fi
						sender_blacklisted=$(grep -c "${trx_sender}" "${user_path}"/blacklisted_accounts.dat)
						if [ "${sender_blacklisted}" -eq 1 ]
						then
							trx_status="${trx_status}SDR_BLACKLISTED "
						fi
						receiver_blacklisted=$(grep -c "${trx_receiver}" "${user_path}"/blacklisted_accounts.dat)
						if [ "${receiver_blacklisted}" -eq 1 ]
						then
							trx_status="${trx_status}RCV_BLACKLISTED "
						fi
						if [ "${is_indexed}" -eq 1 ] && [ "${trx_blacklisted}" -eq 0 ] && [ "${sender_blacklisted}" -eq 0 ] && [ "${receiver_blacklisted}" -eq 0 ]
						then
							trx_status="OK"
						fi
						if [ "${trx_sender}" = "${cmd_sender}" ]
						then
							main_string="${main_string}         <tr>\n           <td>${trx_date}</td>\n           <td>${trx_receiver}</td>\n           <td>-${trx_amount}</td>\n           <td>${trx_asset}</td>\n           <td>-</td>\n           <td>${trx_status}</td>\n           <td>${trx_confirmations}</td>\n         </tr>\n"
						fi
						if [ "${trx_receiver}" = "${cmd_sender}" ]
						then
							main_string="${main_string}         <tr>\n           <td>${trx_date}</td>\n           <td>${trx_sender}</td>\n           <td>+${trx_amount}</td>\n           <td>${trx_asset}</td>\n           <td><button style=\"border:1px solid #FFFFFF;\" type=\"submit\" name=\"trx_file\" value=\"${trx_file}\">show</button></td>\n           <td>${trx_status}</td>\n           <td>${trx_confirmations}</td>\n         </tr>\n"
						fi
					done <"${my_trx}"
					main_string="${main_string}       </table>\n    </div>\n"
				else
					main_string="       <h2 style=\"text-align:center\">no results<br></h2>\n"
				fi
				history_string=$(printf "%b" "${main_string}")
				rm -f -- "${my_trx}"
				####################################################

				###FILL MULTI-SIGNATURE STRING FOR MAIN FORM########
				my_msig_trx=$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.tmp -p "${script_path}"/webwallet/tmp/)
				my_msig_trx_base=$(basename "${my_msig_trx}")
				grep -s -l "MSIG:${cmd_sender}" -- "${script_path}"/trx/* >"${my_msig_trx}"
				for msig_file in $(grep -s -l "MSIG:${cmd_sender}" "${script_path}"/proofs/*/multi.sig)
				do
					user="$(dirname "${msig_file}")"
					user="$(basename "${user}")"
					awk -v user="${user}" -v script_path="${script_path}" 'index($0, user) { print script_path "/trx/" $1 }' "${user_path}"/all_trx.dat >>"${my_msig_trx}"
				done
				sort -r -t . -k2 "${my_msig_trx}" >"${my_msig_trx}".2
				mv -- "${my_msig_trx}".2 "${my_msig_trx}"
				if [ "$(wc -l <"${my_msig_trx}")" -gt 0 ]
				then
					main_string="    <div style=\"height:300px;overflow-y:scroll;overflow-x:auto;scrollbar-color:#000000 #FFFFFF;font-family:Courier New;\">\n       <table class=\"center-history-table\">\n         <tr>\n          <th>Date</th>\n          <th>Sender</th>\n          <th>Receiver</th>\n          <th>Amount</th>\n          <th>Asset</th>\n          <th>Status</th>\n          <th>Action</th>\n          <th>Confirmations</th>\n         </tr>\n"
					while read trx_file_path
					do
						trx_status=""

						###GET TRANSACTION DATA################################
						trx_file=$(basename "${trx_file_path}")
						trx_hash=$(sha256sum "${trx_file_path}")
						trx_hash=${trx_hash%% *}

						###IF ALREADY AUTHORIZED SKIP##########################
						if [ -e "${user_path}"/messages_ack.sig ] && grep -q "trx/${trx_file} ${trx_hash}" "${user_path}"/messages_ack.sig
						then
							continue
						fi

						###GET TRANSACTION DATA################################
						IFS='|' read -r trx_stamp trx_sender trx_receiver trx_amount trx_asset <<-EOF
						$(awk -F: '
							/^:TIME:/ {stmp=$3}
							/^:SNDR:/ {sndr=$3}
							/^:RCVR:/ {rcvr=$3}
							/^:AMNT:/ {amnt=$3}
							/^:ASST:/ {asst=$3}
							END { printf "%s|%s|%s|%s|%s\n", stmp, sndr, rcvr, amnt, asst }
						' "${trx_file_path}")
						EOF
						trx_date=$(date +'%F %H:%M:%S' --date=@"${trx_stamp}")

						###GET CONFIRMATIONS###################################
						trx_confirmations=$(awk \
							-v trx_ref="trx/${trx_file} ${trx_hash}" \
							-v check_file="${user_path}/all_accounts.dat" \
							-v sndr="${trx_sender}" \
							-v rcvr="${trx_receiver}" \
							-f "${script_path}"/control/functions/get_confirmations.awk \
							"${script_path}"/proofs/*/*.txt)

						###CHECK INDEX FILE####################################
						if [ -s "${script_path}/proofs/${trx_sender}/${trx_sender}.txt" ]
						then
							is_indexed=$(grep -c "trx/${trx_file} ${trx_hash}" "${script_path}/proofs/${trx_sender}/${trx_sender}.txt")
						else
							is_indexed=0
						fi
						if [ "${is_indexed}" -eq 0 ]
						then
							trx_status="TRX_IGNORED "
						fi
						trx_blacklisted=$(grep -c "${trx_file}" "${user_path}"/blacklisted_trx.dat)
						if [ "${trx_blacklisted}" -eq 1 ]
						then
							trx_status="${trx_status}TRX_BLACKLISTED "
						fi
						sender_blacklisted=$(grep -c "${trx_sender}" "${user_path}"/blacklisted_accounts.dat)
						if [ "${sender_blacklisted}" -eq 1 ]
						then
							trx_status="${trx_status}SDR_BLACKLISTED "
						fi
						receiver_blacklisted=$(grep -c "${trx_receiver}" "${user_path}"/blacklisted_accounts.dat)
						if [ "${receiver_blacklisted}" -eq 1 ]
						then
							trx_status="${trx_status}RCV_BLACKLISTED "
						fi
						if [ "${is_indexed}" -eq 1 ] && [ "${trx_blacklisted}" -eq 0 ] && [ "${sender_blacklisted}" -eq 0 ] && [ "${receiver_blacklisted}" -eq 0 ]
						then
							trx_status="OK"
						fi
						main_string="${main_string}         <tr>\n           <td>${trx_date}</td>\n           <td>${trx_sender}</td>\n           <td>${trx_receiver}</td>\n           <td>+${trx_amount}</td>\n           <td>${trx_asset}</td>\n           <td>${trx_status}</td>\n           <td><button style=\"border:1px solid #FFFFFF;\" type=\"submit\" name=\"trx_file\" onClick=\"show_multisig_progressbar()\" value=\"${trx_file}\">authorize</button></td>\n           <td>${trx_confirmations}</td>\n         </tr>\n"
					done <"${my_msig_trx}"
					main_string="${main_string}       </table>\n    </div>\n"
				else
					main_string="       <h2 style=\"text-align:center\">no results<br></h2>\n"
				fi
				multisig_string=$(printf "%b" "${main_string}")
				rm -f -- "${my_msig_trx}"
				####################################################

				### BUILD HTML PAGE ################################
				end_line=$(grep -n "<<BALANCES>>" "${script_path}"/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				head -"${end_line}" "${script_path}"/webwallet/webwallet_template.html
				echo "${balance_string}"
				start_line=$(( end_line + 1 ))
				end_line=$(grep -n "<<TRX_HISTORY_TABLE>>" "${script_path}"/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				tail_line=$(( end_line - start_line ))
				head -"${end_line}" "${script_path}"/webwallet/webwallet_template.html|tail -"${tail_line}"|sed -e "s/<<SID>>/${cmd_session_id}/g" -e "s/<<SKEY>>/${cmd_session_key}/g"
				echo "${history_string}"
				start_line=$(( end_line + 1 ))
				end_line=$(grep -n "<<TRX_MULTISIG_TABLE>>" "${script_path}"/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				tail_line=$(( end_line - start_line ))
				head -"${end_line}" "${script_path}"/webwallet/webwallet_template.html|tail -"${tail_line}"|sed -e "s/<<SID>>/${cmd_session_id}/g" -e "s/<<SKEY>>/${cmd_session_key}/g"
				echo "${multisig_string}"
				start_line=$(( end_line + 1 ))
				end_line=$(grep -n "<<CASCADE_DROPDOWN>>" "${script_path}"/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				tail_line=$(( end_line - start_line ))
				head -"${end_line}" "${script_path}"/webwallet/webwallet_template.html|tail -"${tail_line}"|sed -e "s/<<SID>>/${cmd_session_id}/g" -e "s/<<SKEY>>/${cmd_session_key}/g"
				echo "${address_string}"
				echo "${asset_string}"
				echo "${available_balances_string}"
				start_line=$(( end_line + 1 ))
				full_line=$(wc -l <"${script_path}"/webwallet/webwallet_template.html)
				tail_line=$(( full_line - start_line ))
				tail -"${tail_line}" "${script_path}"/webwallet/webwallet_template.html
				#####################################################
			fi
			### REMOVE TMP FILE #################################
			rm -f -- "${script_path}/webwallet/tmp/${my_pid}.out"

			### RETURNCODE ######################################
			return ${rt_code}
}
check_session(){
		### SET RT_QUERY ############################################
		rt_query=1

		### GET NOW STAMP ###########################################
		now_stamp=$(date +%s)

		### CHECK IF VARIABLES ARE EMPTY ############################
		if [ -n "${cmd_session_id}" ] && [ -n "${cmd_session_key}" ] && [ -n "${cmd_ip_address}" ]
		then
			### CHECK IF SESSION FILE EXISTS ############################
			if [ -s "${script_path}/webwallet/sessions/${cmd_session_id}.sid" ]
			then
				### TRY TO DECRYPT SESSION FILE #############################
				echo "${cmd_session_key}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${script_path}/webwallet/tmp/${cmd_session_id}.sid" --decrypt "${script_path}/webwallet/sessions/${cmd_session_id}.sid" 1>/dev/null 2>/dev/null
				rt_query=$?
				if [ "${rt_query}" -eq 0 ]
				then
					### CHECK IF SESSION IS TIMED OUT ###########################
					session_string=$(head -1 "${script_path}/webwallet/tmp/${cmd_session_id}.sid")
					check_ip=${session_string%%,*}
					if [ "${check_ip}" = "${cmd_ip_address}" ]
					then
						### SET VARIABLES ###########################################
						session_string=${session_string#*,}
						session_stamp=${session_string%%,*}

						### REMOVE SID FILE #########################################
						rm -f -- "${script_path}/webwallet/sessions/${cmd_session_id}.sid"

						### IF SESSION IS NOT EXPIRED ###############################
						if [ $(( now_stamp - session_stamp )) -le $(( minutes_logoff * 60 )) ]
						then
							### SET VARIABLES ###########################################
							session_string=${session_string#*,}
							cmd_user=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_pin=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_pw=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_sender=${session_string%%,*}
							user_path="${script_path}/userdata/${cmd_sender}"

							### RENEW STAMP #############################################
							echo "${cmd_ip_address},${now_stamp},${cmd_user},${cmd_pin},${cmd_pw},${cmd_sender}" >"${script_path}/webwallet/tmp/${cmd_session_id}.sid"

							### ENCRYPT AND WRITE NEW SESSION FILE ######################
							echo "${cmd_session_key}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output "${script_path}/webwallet/sessions/${cmd_session_id}.sid" --passphrase-fd 0 "${script_path}/webwallet/tmp/${cmd_session_id}.sid" 2>/dev/null
							rt_query=$?
						else
							rt_query=1
						fi
					else
						rt_query=1
					fi
				fi
				rm -f -- "${script_path}/webwallet/tmp/${cmd_session_id}.sid"
			fi
		fi
		if [ "${rt_query}" -eq 1 ]
		then
			### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
			cat "${landing_page}"
			echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
		fi
		return ${rt_query}
}
create_session(){
		### SET RT_QUERY ############################################
		rt_query=1

		### CHECK IF IP_ADDRESS IS EMPTY ############################
		if [ -n "${cmd_ip_address}" ]
		then
			###TEST KEY BY ENCRYPTING A MESSAGE##########################
			echo "1" >"${script_path}/webwallet/tmp/account_${my_pid}.tmp"
			echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring="${script_path}/control/keyring.file" --trust-model always --local-user "${cmd_sender}" -r "${cmd_sender}" --passphrase-fd 0 --pinentry-mode loopback --sign "${script_path}/webwallet/tmp/account_${my_pid}.tmp" 1>/dev/null 2>/dev/null
			rt_query=$?
			if [ "${rt_query}" -eq 0 ]
			then
				###REMOVE ENCRYPTION SOURCE FILE#############################
				rm -f -- "${script_path}/webwallet/tmp/account_${my_pid}.tmp"

				####TEST KEY BY VERIFYING THE MESSAGE########################
				gpg --batch --status-fd 1 --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --verify "${script_path}/webwallet/tmp/account_${my_pid}.tmp.gpg" 2>/dev/null|grep -q "GOODSIG.*${trx_sender}"
				rt_query=$?
			fi
			rm -f -- "${script_path}/webwallet/tmp/account_${my_pid}".*
			if [ "${rt_query}" -eq 0 ]
			then
				### CREATE A SESSION ID #####################################
				session_id=$(basename --suffix=.sid "$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.sid -p "${script_path}"/webwallet/sessions/)")

				### SET SESSION KEY #########################################
				session_key=$(head -c 100 /dev/urandom|tr -dc A-Za-z0-9|head -c 20|sha224sum)
				session_key=${session_key%% *}

				### GET CURRENT TIMESTAMP ###################################
				now_stamp=$(date +%s)

				### WRITE CREDENTIALS TO FILE################################
				echo "${cmd_ip_address},${now_stamp},${cmd_user},${cmd_pin},${cmd_pw},${cmd_sender}" >"${script_path}/webwallet/tmp/${session_id}.tmp"

				### WRITE SID FILE ##########################################
				echo "${session_key}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output "${script_path}/webwallet/tmp/${session_id}.sid" --passphrase-fd 0 "${script_path}/webwallet/tmp/${session_id}.tmp" 2>/dev/null
				rt_query=$?
				if [ "${rt_query}" -eq 0 ]
				then
					cmd_session_id=${session_id}
					cmd_session_key=${session_key}

					### MOVE SESSION FILE INTO SESSION FOLDER ###################
					mv -- "${script_path}/webwallet/tmp/${session_id}.sid" "${script_path}/webwallet/sessions/${session_id}.sid"
				else
					rm -f -- "${script_path}/webwallet/sessions/${session_id}.sid"
				fi
				rm -f -- "${script_path}/webwallet/tmp/${session_id}.tmp"
			else
				rt_query=1
			fi
		fi
		return ${rt_query}
}
get_address(){
		### SET RT_QUERY ############################################
		rt_query=1

		###FOR EACH SECRET###########################################
		for secret_file in $(ls -1 "${script_path}"/control/keys/|grep ".sct")
		do
			###GET ADDRESS OF SECRET#####################################
			key_file=${secret_file%%.*}

			###CALCULATE ADDRESS#########################################
			random_secret=$(cat "${script_path}/control/keys/${secret_file}")
			key_login=$(echo "${cmd_user}_${random_secret}_${cmd_pin}"|sha224sum)
			key_login=${key_login%% *}
			key_login=$(echo "${key_login}_${cmd_pin}"|sha224sum)
			key_login=${key_login%% *}

			###IF ACCOUNT MATCHES########################################
			if [ "${key_file}" = "${key_login}" ]
			then
				cmd_sender=${key_file}
				user_path="${script_path}/userdata/${cmd_sender}"
				rt_query=0
				break
			fi
		done

		### RETURN IF FOUND #########################################
		return ${rt_query}
}
### SET DEFAULT VALUES ###############################
max_failed_logons=3
minutes_to_watch=30
minutes_to_block=30
minutes_logoff=30
minutes_housekeeping=5
cmd_var=""
cmd_action=""
cmd_user=""
cmd_pin=""
cmd_pw=""
cmd_receiver=""
cmd_amount=""
cmd_asset=""
cmd_msig=""
cmd_purpose=""
cmd_path=""
cmd_session_id=""
cmd_session_key=""
cmd_ip_address=""

### SET PATHS ########################################
script_path=$(cd "$(dirname "$0")" && pwd)
user_path=""

### SOURCE CONFIG FILE ###############################
. "${script_path}"/control/webwallet.conf

### GET PID FOR TMP FILES ############################
my_pid=$$

###CHECK FOR STDIN INPUT##############################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi

### CHECK IF GUI MODE OR CMD MODE AND ASSIGN VARIABLES ###
if [ $# -gt 0 ]
then
	### GO THROUGH PARAMETERS ONE BY ONE ##########################
	while [ $# -gt 0 ]
	do
		### GET TARGET VARIABLES ######################################
		case $1 in
			"-action")	cmd_var=$1
					;;
			"-user")	cmd_var=$1
					;;
			"-pin")		cmd_var=$1
					;;
			"-password")	cmd_var=$1
					;;
			"-receiver")	cmd_var=$1
					;;
			"-amount")	cmd_var=$1
					;;
			"-asset")	cmd_var=$1
					;;
			"-msig")	cmd_var=$1
					;;
			"-purpose")	cmd_var=$1
					;;
			"-path")	cmd_var=$1
					;;
			"-session_id")	cmd_var=$1
					;;
			"-session_key")	cmd_var=$1
					;;
			"-ip")		cmd_var=$1
					;;
			"-help")	more "${script_path}"/control/webwallet_HELP.txt
					exit 0
					;;
			*)		### SET TARGET VARIABLES ######################################
					case "${cmd_var}" in
						"-action")	cmd_action=$1
								if [ ! "${cmd_action}" = "check_name" ] && [ ! "${cmd_action}" = "create_account" ] && [ ! "${cmd_action}" = "delete_account" ] && [ ! "${cmd_action}" = "download_account" ] && [ ! "${cmd_action}" = "download_sync" ] && [ ! "${cmd_action}" = "get_users" ] && [ ! "${cmd_action}" = "login_account" ] && [ ! "${cmd_action}" = "logout_account" ] && [ ! "${cmd_action}" = "read_sync" ] && [ ! "${cmd_action}" = "read_trx" ] && [ ! "${cmd_action}" = "send_trx" ] && [ ! "${cmd_action}" = "show_trx" ] && [ ! "${cmd_action}" = "sign_trx" ] && [ ! "${cmd_action}" = "sync_uca" ]
								then
									echo "ERROR! TRY THIS:"
									echo "./webwallet.sh -help"
									exit 1
								fi
								;;
						"-user")	cmd_user=$1
								;;
						"-pin")		cmd_pin=$1
								;;
						"-password")	cmd_pw=$1
								;;
						"-receiver")	cmd_receiver=$1
								;;
						"-amount")	cmd_amount=$1
								;;
						"-asset")	cmd_asset=$1
								;;
						"-msig")	cmd_msig=$1
								;;
						"-purpose")	cmd_purpose=$1
								;;
						"-path")	cmd_path=$1
								;;
						"-session_id")	cmd_session_id=$1
								;;
						"-session_key")	cmd_session_key=$1
								;;
						"-ip")		cmd_ip_address=$1
								;;
						*)		echo "ERROR! TRY THIS:"
								echo "./webwallet.sh -help"
								exit 1
								;;
					esac
					cmd_var=""
					;;
		esac
		shift
	done

	### SET VARIABLE FOR LANDING PAGE ##################
	landing_page="${path_www_data}/index.html"

	### STEP INTO SCRIPT HOMEDIR #######################
	cd "${script_path}"/ || exit 2

	### CHECK USER ACTION ##############################
	case "${cmd_action}" in
		"create_account")	### CONSIDER MULTI-SIGNATURE ##############################
					msig_string=""
					if [ -n "${cmd_msig}" ] && [ "$(echo "${cmd_msig}"|grep -c '[^a-zA-Z0-9,]')" -eq 0 ]
					then
						### READ CSV STRING #######################################
						OLDIFS=$IFS
						IFS=','
						set -- ${cmd_msig}
						IFS=$OLDIFS

						### BUILD STRING ##########################################
						for msig_user in "$@"
						do
							msig_string="${msig_string}-msig ${msig_user} "
						done
					fi

					### TRIGGER USER CREATION #################################
					echo "-action create_user -user ${cmd_user} ${msig_string}-pin ${cmd_pin} -password ${cmd_pw}"|./ucs_client.sh >>/dev/null
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### GET USER ADDRESS ######################################
						get_address
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### CREATE SESSION ########################################
							create_session
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### BUILD MAIN PAGE #######################################
								build_webwallet
							fi
						fi
					fi
					if [ "${rt_query}" -eq 1 ]
					then
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat "${landing_page}"
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your account!")</script>'
					fi
					;;
		"check_name")		### CHECK USERNAME IS STILL AVAILABLE ######################
					name_hash=$(echo "${cmd_user}"|sha224sum)
					name_hash=${name_hash%% *}
					already_exists=$(grep -c -w "${name_hash}" "${script_path}"/control/accounts.db)

					### ANSWER IS FOR AJAX #####################################
					if [ "${already_exists}" -eq 0 ]
					then
						echo "<b>available &#x2705;</b>"
					else
						echo "<b>already used &#x274C;</b>"
					fi
					;;
		"delete_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### REMOVE USER ENTRY FROM ACCOUNTS.DB ###################
						cmd_user_hash=$(echo "${cmd_user}"|sha224sum)
						cmd_user_hash=${cmd_user_hash%% *}
						sed "/${cmd_user_hash}/d" "${script_path}"/control/accounts.db >"${script_path}"/control/accounts.db."${my_pid}".bak && mv -- "${script_path}"/control/accounts.db."${my_pid}".bak "${script_path}"/control/accounts.db

						### GET FINGERPRINT OF PRIVATE KEY #######################
						key_fp=$(gpg --no-default-keyring --keyring="${script_path}"/control/keyring.file --with-colons --list-keys "${cmd_sender}" 2>/dev/null|sed -n 's/^fpr:::::::::\([[:alnum:]]\+\):/\1/p')
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### DELETE PRIVATE KEY FROM KEYRING ######################
							gpg --batch --yes --no-default-keyring --keyring="${script_path}"/control/keyring.file --delete-secret-keys "${key_fp}" 2>/dev/null
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### DELETE ################################################
								rm -f -- "${script_path}/control/keys/${cmd_sender}"
								rm -f -- "${script_path}/control/keys/${cmd_sender}".sct
								rm -rf -- "${script_path}/userdata/${cmd_sender}"

								### DELETE SESSION ########################################
								rm -f -- "${script_path}/webwallet/sessions/${cmd_session_id}.sid"

								### DISPLAY LANDING PAGE ##################################
								cat "${landing_page}"

								### SHOW MESSAGE BOX ######################################
								echo '<script type="text/javascript" language="Javascript">alert("INFO: Your account ${cmd_sender} has been deleted!")</script>'
							fi
						fi
						if [ "${rt_query}" -eq 1 ]
						then
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while deleting your account!")</script>'
						fi
					fi
					;;
		"download_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### PACK TAR FILE #########################################
						{
						echo "keys/${cmd_sender}"
						echo "control/keys/${cmd_sender}"
						echo "control/keys/${cmd_sender}".sct
						echo "proofs/${cmd_sender}"
						echo "userdata/${cmd_sender}"
						ls -1 trx/"${cmd_sender}".* 2>/dev/null
						}>"${script_path}/webwallet/tmp/${cmd_sender}_profile.tmp"
						tar -czf "${script_path}/webwallet/tmp/${cmd_sender}_profile.tar" -T "${script_path}/webwallet/tmp/${cmd_sender}_profile.tmp" 2>/dev/null
						rt_query=$?
						###########################################################
						if [ "${rt_query}" -eq 0 ]
						then
							### HANDOVER FILE PATH TO TRIGGER DOWNLOAD ################
							echo "${script_path}/webwallet/tmp/${cmd_sender}_profile.tar"
						fi
						rm -f -- "${script_path}/webwallet/tmp/${cmd_sender}_profile.tmp"
					fi
					if [ "${rt_query}" -gt 0 ]
					then
						### DISPLAY ERROR MESSAGE #################################
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured!")</script>'
					fi
					;;
		"download_sync")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						syncfile=$(echo "-action create_sync -sender ${cmd_sender} -password ${cmd_pw} -type partial"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh|tail -1|cut -d ':' -f2)
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### HANDOVER FILE PATH TO TRIGGER DOWNLOAD ################
							echo "${syncfile}"
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating the sync file!")</script>'
						fi
					fi
					;;
		"get_users")		### GET LIST OF ADDRESSES ##################################
					output=$(ls -1 "${script_path}"/keys)

					### ANSWER IS FOR AJAX #####################################
					echo "${output}"
					;;
		"login_account")	### BUILD STRING TO IDENTIFY USER ##########################
					logger_string=$(echo "${cmd_ip_address}_${cmd_user}"|sha224sum)
					logger_string=${logger_string%% *}

					### GET STAMP FOR SESSION LOGGER FILE EXTENSION ############
					now_stamp=$(date +%s)

					### DELETE ALL LOCKS OLDER THAN ############################
					find "${script_path}"/webwallet/logger/ -maxdepth 1 -type f -mmin +"${minutes_to_block}" -delete >/dev/null 2>/dev/null

					### DELETE ALL LOGGER FILES OLDER THAN #####################
					find "${script_path}"/webwallet/logger/tmp/ -maxdepth 1 -type f -mmin +"${minutes_to_watch}" -delete >/dev/null 2>/dev/null

					### GET NUMBER OF SESSION LOGGER FILES FOR THIS USER #######
					total_failed_logons=$(find "${script_path}"/webwallet/logger/tmp/"${logger_string}".* -maxdepth 1 -type f 2>/dev/null|wc -l)
					if [ "${total_failed_logons}" -gt "${max_failed_logons}" ]
					then
						touch "${script_path}/webwallet/logger/${logger_string}.${now_stamp}"
						rm -f -- "${script_path}/webwallet/logger/tmp/${logger_string}".*
					fi

					### CHECK IF USER IS LOCKED ################################
					total_locks=$(find "${script_path}"/webwallet/logger/"${logger_string}".* -maxdepth 1 -type f 2>/dev/null|wc -l)
					if [ "${total_locks}" -eq 0 ]
					then
						### GET ADDRESS ####################################
						get_address
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							### CREATE SESSION #################################
							create_session
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								### DELETE LOGGER SESSION FILES ####################
								rm -f -- "${script_path}/webwallet/logger/tmp/${logger_string}".*

								### BUILD MAIN PAGE ################################
								build_webwallet
							fi
						else
							### WRITE SESSION LOGGER FILE FOR FAILED LOGON #####
							touch "${script_path}/webwallet/logger/tmp/${logger_string}.${now_stamp}"
						fi
						if [ "${rt_query}" -eq 1 ]
						then
							### DISPLAY LANDING PAGE AND ERROR MESSAGE #########
							cat "${landing_page}"
							echo '<script type="text/javascript" language="Javascript">alert("Wrong logon credentials!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat "${landing_page}"
						echo '<script type="text/javascript" language="Javascript">alert("You have entered the wrong logon credentials too many times! Please try again later!")</script>'
					fi
					;;
		"logout_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### REMOVE SESSION AND RETURN TO LANDING PAGE #############
						rm -f -- "${script_path}/webwallet/sessions/${cmd_session_id}.sid"
						cat "${landing_page}"
					fi
					;;
		"read_sync")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action read_sync -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >>/dev/null
						rt_query=$?

						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ "${rt_query}" -eq 0 ]
						then
							### DISPLAY SUCCESS MESSAGE ###############################
							echo '<script type="text/javascript" language="Javascript">alert("INFO: File successfully uploaded!")</script>'
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while reading your syncfile!")</script>'
						fi
					fi
					;;
		"read_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action read_trx -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >>/dev/null
						rt_query=$?

						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ "${rt_query}" -eq 0 ]
						then
							### DISPLAY SUCCESS MESSAGE ###############################
							echo '<script type="text/javascript" language="Javascript">alert("INFO: File successfully uploaded!")</script>'
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while reading your transaction!")</script>'
						fi
					fi
					;;
		"send_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						if [ -e "${cmd_path}" ]
						then
							### CONSIDER MULTI-SIGNATURE ##############################
							msig_string=""
							if [ -n "${cmd_msig}" ] && [ "$(echo "${cmd_msig}"|grep -c '[^a-zA-Z0-9,]')" -eq 0 ]
							then
								### READ CSV STRING #######################################
								OLDIFS=$IFS
								IFS=','
								set -- ${cmd_msig}
								IFS=$OLDIFS

								### BUILD STRING ##########################################
								for msig_user in "$@"
								do
									msig_string="${msig_string}-msig ${msig_user} "
								done
							fi

							### STRIP SINGLE QUOTES FROM WALLET.PHP ESCAPESHELLARG ####
							cmd_purpose=$(cat "${cmd_path}"|php -R 'echo urldecode($argn);')

							### WRITE PURPOSE TO FILE AND CONVERT######################
							echo "${cmd_purpose}" >"${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp"
							dos2unix -f "${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp" 2>/dev/null

							### TRIGGER CLIENT ACTION #################################
							echo "-action create_trx ${msig_string}-sender ${cmd_sender} -password ${cmd_pw} -asset ${cmd_asset} -amount ${cmd_amount} -receiver ${cmd_receiver} -file ${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >>/dev/null
							rt_query=$?

							### DELETE TMP FILE #######################################
							rm -f -- "${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp"

							### BUILD MAIN PAGE #######################################
							build_webwallet
							if [ "${rt_query}" -eq 0 ]
							then
								### DISPLAY SUCCESS MESSAGE ###############################
								echo '<script type="text/javascript" language="Javascript">alert("INFO: Transaction was sent!")</script>'
							else
								### DISPLAY ERROR MESSAGE #################################
								echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your transaction!")</script>'
							fi
						else
							### BUILD MAIN PAGE #######################################
							build_webwallet

							### DISPLAY ERROR MESSAGE ################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your transaction!")</script>'
						fi
					fi
					;;
		"sign_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						out_var=$(echo "-action sign -user ${cmd_user} -pin ${cmd_pin} -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh 2>/dev/null)
						rt_query=$?
						if [ "$rt_query" -eq 0 ]
						then
							### BUILD MAIN PAGE #######################################
							build_webwallet
							if [ "${rt_query}" -eq 0 ]
							then
								### DISPLAY SUCCESS MESSAGE ###############################
								echo '<script type="text/javascript" language="Javascript">alert("INFO: Transaction was signed!")</script>'
							else
								### DISPLAY ERROR MESSAGE #################################
								echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while signing the transaction!")</script>'
							fi
						fi
					fi
					;;
		"show_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						purpose_key=""

						###GET TRANSACTION DATA##################################
						trx_sender=${cmd_path%%.*}
						trx_stamp=${cmd_path#*.}
						trx_stamp=$(date --date=@"${trx_stamp}")
						IFS='|' read -r trx_amount purpose_key_start purpose_start purpose_end <<-EOF
						$(awk -F: '
							/^:AMNT:/ {amnt=$3}
							/^:PRPK:/ {prpk=NR}
							/^:PRPS:/ {prps=NR}
							/BEGIN PGP SIGNATURE/ {prpe=NR}
							END { printf "%s|%s|%s|%s\n", amnt, prpk, prps, prpe }
						' "${script_path}/trx/${cmd_path}")
						EOF
						purpose_key_start=$(( purpose_key_start + 1 ))
						purpose_key_end=${purpose_start}
						purpose_key_end=$(( purpose_key_end - 1 ))
						purpose_key_encrypted=$(sed -n "${purpose_key_start},${purpose_key_end}p" "${script_path}/trx/${cmd_path}")
						printf "%b" "-----BEGIN PGP MESSAGE-----\n\n${purpose_key_encrypted}\n-----END PGP MESSAGE-----\n"  >"${user_path}"/history_purpose_key_encrypted.tmp
						echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${user_path}"/history_purpose_key_decrypted.tmp --decrypt "${user_path}"/history_purpose_key_encrypted.tmp 2>/dev/null
						rt_query=$?
						if [ "${rt_query}" -eq 0 ]
						then
							purpose=""
							purpose_key=$(cat "${user_path}"/history_purpose_key_decrypted.tmp)
							purpose_start=$(( purpose_start + 1 ))
							purpose_end=$(( purpose_end - 1 ))
							purpose_encrypted=$(sed -n "${purpose_start},${purpose_end}p" "${script_path}/trx/${cmd_path}")
							printf "%b" "-----BEGIN PGP MESSAGE-----\n\n${purpose_encrypted}\n-----END PGP MESSAGE-----\n" >"${user_path}"/history_purpose_encrypted.tmp
							echo "${purpose_key}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${user_path}"/history_purpose_decrypted.tmp --decrypt "${user_path}"/history_purpose_encrypted.tmp 2>/dev/null
							rt_query=$?
							if [ "${rt_query}" -eq 0 ]
							then
								is_text=$(file "${user_path}"/history_purpose_decrypted.tmp|grep -c -v "text")
								if [ "${is_text}" -eq 0 ]
								then
									### ENCODE PURPOSE BECAUSE OF SPECIAL CHARACTERS ##########
									purpose=$(printf "%s" "$(cat -E "${user_path}"/history_purpose_decrypted.tmp|sed 's/\$\$*$/\\n/g'|php -R 'echo htmlentities($argn);')")

									### PRINT TRANSACTION CONTENT AS POPUP#####################
									popup="<script type=\"text/javascript\" language=\"Javascript\"> var myWindow = window.open(\"\", \"MsgWindow\", \"toolbar=yes,scrollbars=yes,resizable=yes\"); myWindow.document.write(\"<h3 style=font-family:monospace;>Timestamp:<br>${trx_stamp}<br><br>Amount:<br>+${trx_amount}<br><br>Sender:<br>${trx_sender}<br><br>File:<br>${cmd_path}<br><br>Purpose:<br></h3><pre>${purpose}</pre>\");</script>"
									printf "%s" "${popup}"
								else
									### DISPLAY ERROR MESSAGE #################################
									echo '<script type="text/javascript" language="Javascript">alert("NOTE: The purpose cannot be displayed, because it is not in text format.")</script>'
								fi

								### BUILD MAIN PAGE #######################################
								build_webwallet
							else
								### DISPLAY ERROR MESSAGE #################################
								echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while decrypting the transaction purpose!")</script>'
							fi
							rm -f -- "${user_path}"/history_purpose_encrypted.tmp
							rm -f -- "${user_path}"/history_purpose_decrypted.tmp
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while decrypting the transaction purpose!")</script>'
						fi
						rm -f -- "${user_path}"/history_purpose_key_encrypted.tmp
						rm -f -- "${user_path}"/history_purpose_key_decrypted.tmp
					fi
					;;
		"sync_uca")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action sync_uca -sender ${cmd_sender} -password ${cmd_pw}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >>/dev/null
						rt_query=$?

						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ "${rt_query}" -gt 0 ]
						then
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while performing syncronization!")</script>'
						fi
					fi
					;;
	esac

	### AUTO LOGOFF ################################################################################
	find "${script_path}"/webwallet/sessions/ -maxdepth 1 -type f -mmin +"${minutes_logoff}" -delete >/dev/null 2>/dev/null

	### DO HOUSEKEEPING AND DELETE ALL TMP SESSION FILES OLDER THAN 5 MINUTES ######################
	find "${script_path}"/webwallet/tmp/ -maxdepth 1 -type f -mmin +"${minutes_housekeeping}" -delete >/dev/null 2>/dev/null
else
	### DISPLAY HELP OVERVIEW MESSAGE ##############################################################
	echo "ERROR! TRY THIS:"
	echo "./webwallet.sh -help"
	exit 1
fi
