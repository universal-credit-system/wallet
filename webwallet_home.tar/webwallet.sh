#!/bin/sh
build_webwallet(){
			### SET VARIABLES ####################################
			main_string=""
			send_string=""
			user_address=""

			### GET BALANCES #####################################
			echo "-action show_balance -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw}"|./ucs_client.sh >${script_path}/webwallet/tmp/${my_pid}.out
			rt_query=$?
			if [ $rt_query = 0 ]
			then
				### FILL BALANCE STRING FOR THE MAIN FORM ##########
				main_string="    <h2 style=\"text-align:center\">Total balance<br></h2>\n"
				main_string="${main_string}    <table class=\"center-balance-table\">\n"

				### FILL BALANCE ARRAY FOR SEND FORM ###############
				send_string="var balanceObject = {\n"
				while read line
				do
					### GET DATA FROM OUTPUT ###########################
					balance=$(echo $line|cut -d ':' -f3|cut -d '=' -f2)
					asset=$(echo $line|cut -d ':' -f2)
					user_address=$(echo $line|cut -d ':' -f3|cut -d '=' -f1)

					### FILL BALANCE STRING FOR THE MAIN FORM ##########
					main_string="${main_string}      <tr>\n        <td style="text-align:left"><b>${asset}</b></td>\n        <td style="text-align:right"><b>${balance}</b></td>\n      </tr>\n"

					### FILL BALANCE ARRAY FOR SEND FORM ###############
					if [ ! "${main_asset}" = "${cmd_asset}" ]
					then
						send_string="${send_string}  \"${asset}\":{\n    \"${balance}\": [\"1\"]\n  },\n"
					fi
				done <${script_path}/webwallet/tmp/${my_pid}.out

				### FILL BALANCE STRING FOR THE MAIN FORM ##########
				main_string="${main_string}    </table>\n"
				balance_string=$(printf "%b" "    <h2 style=\"text-align:center\">Address<br></h2>\n    <h4 style=\"text-align:center;word-break:break-all;word-wrap:break-word;\">${user_address}<br></h4>\n${main_string}")
				####################################################

				### FILL BALANCE ARRAY FOR SEND FORM ###############
				send_string="${send_string}  \"${asset}\":{\n    \"${balance}\": [\"1\"]\n  },\n"
				send_string="${send_string} }"
				available_balances_string=$(printf "%b" "$send_string")

				### FILL ASSET STRING FOR THE MAIN FORM ############
				user_path="${script_path}/userdata/${user_address}"
				rm ${user_path}/menu_addresses_fungible.tmp 2>/dev/null
				touch ${user_path}/menu_addresses_fungible.tmp
				main_string="var subjectObject = {\n"
				for asset in $(cat ${user_path}/all_assets.dat)
				do
					is_fungible=$(grep -c "asset_fungible=1" ${script_path}/assets/${asset})
					if [ $is_fungible = 1 ]
					then
						echo $asset >>${user_path}/menu_addresses_fungible.tmp
					fi
				done
				for asset in $(cut -d ':' -f2 ${script_path}/webwallet/tmp/${my_pid}.out)
				do
					main_string="${main_string}  \"${asset}\": {\n"
					is_fungible=$(grep -c "asset_fungible=1" ${script_path}/assets/${asset})
					if [ $is_fungible = 1 ]
					then
						cat ${user_path}/menu_addresses_fungible.tmp ${user_path}/all_assets.dat|grep -v "${asset}"|sort|uniq -d|sort -t. -k2|cat - ${user_path}/all_accounts.dat|grep -v "${user_address}" >${user_path}/menu_addresses.tmp
					else
						grep -v "${user_address}" ${user_path}/all_accounts.dat >${user_path}/menu_addresses.tmp
					fi
					while read line
					do
						main_string="${main_string}    \"${line}\": [\"1\"],\n"
					done <${user_path}/menu_addresses.tmp
					main_string="${main_string}  },\n"
				done
				main_string="${main_string} }\n"
				asset_string=$(printf "%b" "${main_string}")
				####################################################

				### FILL HISTORY STRING FOR MAIN FORM ##############
				rm ${user_path}/*.tmp 2>/dev/null
				touch ${user_path}/my_trx.tmp
				touch ${user_path}/my_trx_sorted.tmp
				cd ${script_path}/trx
				grep -l ":${user_address}" *.* >${user_path}/my_trx.tmp 2>/dev/null
				cd ${script_path}/
				sort -r -t . -k2 ${user_path}/my_trx.tmp >${user_path}/my_trx_sorted.tmp
				mv ${user_path}/my_trx_sorted.tmp ${user_path}/my_trx.tmp
				no_trx=$(wc -l <${user_path}/my_trx.tmp)
				if [ $no_trx -gt 0 ]
				then
					main_string="    <div style=\"height:300px;overflow-y:scroll;overflow-x:auto;\">\n       <table class=\"center-history-table\">\n         <tr>\n          <th>Date</th>\n          <th>Address</th>\n          <th>Amount</th>\n          <th>Asset</th>\n          <th>Purpose</th>\n          <th>Status</th>\n          <th>Confirmations</th>\n         </tr>\n"
					while read line
					do
						trx_file="${script_path}/trx/${line}"
						sender=$(awk -F: '/:SNDR:/{print $3}' ${trx_file})
						receiver=$(awk -F: '/:RCVR:/{print $3}' ${trx_file})
						trx_date=$(date +'%F %H:%M:%S' --date=@$(awk -F: '/:TIME:/{print $3}' ${trx_file}))
						trx_cmd_amount=$(awk -F: '/:AMNT:/{print $3}' ${trx_file})
						trx_asset=$(awk -F: '/:ASST:/{print $3}' ${trx_file})
						trx_status=""
						trx_hash=$(sha256sum ${trx_file})
						trx_hash=${trx_hash%% *}
						trx_confirmations=$(grep -l "trx/${line} ${trx_hash}" proofs/*/*.txt|grep -f ${user_path}/depend_accounts.dat|grep -v "${sender}\|${receiver}"|wc -l)
						if [ -s ${script_path}/proofs/${sender}/${sender}.txt ]
						then
							trx_signed=$(grep -c "trx/${line}" ${script_path}/proofs/${sender}/${sender}.txt)
						else
							trx_status="${trx_status}TRX_IGNORED "
							trx_signed=0
						fi
						trx_blacklisted=$(grep -c "${line}" ${user_path}/blacklisted_trx.dat)
						if [ $trx_blacklisted = 1 ]
						then
							trx_status="${trx_status}TRX_BLACKLISTED "
						fi
						sender_blacklisted=$(grep -c "${sender}" ${user_path}/blacklisted_accounts.dat)
						if [ $sender_blacklisted = 1 ]
						then
							trx_status="${trx_status}SDR_BLACKLISTED "
						fi
						receiver_blacklisted=$(grep -c "${receiver}" ${user_path}/blacklisted_accounts.dat)
						if [ $receiver_blacklisted = 1 ]
						then
							trx_status="${trx_status}RCV_BLACKLISTED "
						fi
						if [ $trx_signed = 1 ] && [ $trx_blacklisted = 0 ] && [ $sender_blacklisted = 0 ] && [ $receiver_blacklisted = 0 ]
						then
							trx_status="OK"
						fi
						if [ "${sender}" = "${user_address}" ]
						then
							main_string="${main_string}         <tr>\n           <td>${trx_date}</td>\n           <td>${receiver}</td>\n           <td>-${trx_cmd_amount}</td>\n           <td>${trx_asset}</td>\n           <td>-</td>\n           <td>${trx_status}</td>\n           <td>${trx_confirmations}</td>\n         </tr>\n"
						fi
						if [ "${receiver}" = "${user_address}" ]
						then
							main_string="${main_string}         <tr>\n           <td>${trx_date}</td>\n           <td>${sender}</td>\n           <td>+${trx_cmd_amount}</td>\n           <td>${trx_asset}</td>\n           <td><button type=\"submit\" name=\"trx_file\" value=\"${line}\">show</button></td>\n           <td>${trx_status}</td>\n           <td>${trx_confirmations}</td>\n         </tr>\n"
						fi
					done <${user_path}/my_trx.tmp
					main_string="${main_string}       </table>\n    </div>\n"
				else
					main_string="       <h2 style=\"text-align:center\">no results<br></h2>\n"
				fi
				history_string=$(printf "%b" "${main_string}")
				rm ${user_path}/my_trx.tmp
				####################################################

				### BUILD HTML PAGE ################################
				end_line=$(grep -n "<<BALANCES>>" ${script_path}/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				head -$end_line ${script_path}/webwallet/webwallet_template.html
				echo "$balance_string"
				start_line=$(( end_line + 1 ))
				end_line=$(grep -n "<<TRX_TABLE>>" ${script_path}/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				tail_line=$(( end_line - $start_line ))
				head -$end_line ${script_path}/webwallet/webwallet_template.html|tail -$tail_line|sed -e "s/<<SID>>/${cmd_session_id}/g" -e "s/<<SKEY>>/${cmd_session_key}/g"
				echo "$history_string"
				start_line=$(( end_line + 1 ))
				end_line=$(grep -n "<<CASCADE_DROPDOWN>>" ${script_path}/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				tail_line=$(( end_line - start_line ))
				head -$end_line ${script_path}/webwallet/webwallet_template.html|tail -$tail_line|sed -e "s/<<SID>>/${cmd_session_id}/g" -e "s/<<SKEY>>/${cmd_session_key}/g"
				echo "$asset_string"
				echo "$available_balances_string"
				start_line=$(( end_line + 1 ))
				full_line=$(wc -l <${script_path}/webwallet/webwallet_template.html)
				tail_line=$(( full_line - start_line ))
				tail -$tail_line ${script_path}/webwallet/webwallet_template.html
				#####################################################
			fi
			### REMOVE TMP FILE #################################
			rm ${script_path}/webwallet/tmp/${my_pid}.out 2>/dev/null

			### RETURNCODE ######################################
			return $rt_query
}
check_session(){
		### SET RT_QUERY ############################################
		rt_query=1
		
		### GET NOW STAMP ###########################################
		now_stamp=$(date +%s)

		### CHECK IF VARIABLES ARE EMPTY ############################
		if [ ! "${cmd_session_id}" = "" ] && [ ! "${cmd_session_key}" = "" ] && [ ! "${cmd_ip_address}" = "" ]
		then
			### CHECK IF SESSION FILE EXISTS ############################
			if [ -s ${script_path}/webwallet/sessions/${cmd_session_id}.sid ]
			then
				### TRY TO DECRYPT SESSION FILE #############################
				echo "${cmd_session_key}"|gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output ${script_path}/webwallet/tmp/${cmd_session_id}.sid --decrypt ${script_path}/webwallet/sessions/${cmd_session_id}.sid 1>/dev/null 2>/dev/null
				rt_query=$?
				if [ $rt_query = 0 ]
				then
					### CHECK IF SESSION IS TIMED OUT ###########################
					session_string=$(head -1 ${script_path}/webwallet/tmp/${cmd_session_id}.sid)
					check_ip=${session_string%%,*}
					if [ "${check_ip}" = "${cmd_ip_address}" ]
					then
						session_string=${session_string#*,}
						session_stamp=${session_string%%,*}
						if [ $(( now_stamp - session_stamp )) -le $(( minutes_logoff * 60 )) ]
						then
							### SET VARIABLES ###########################################
							session_string=${session_string#*,}
							cmd_user=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_pin=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_pw=${session_string%%,*}

							### RENEW STAMP OF LAST ACTION ##############################
							echo "${cmd_ip_address},${now_stamp},${cmd_user},${cmd_pin},${cmd_pw}" >${script_path}/webwallet/tmp/${cmd_session_id}.sid

							### REMOVE OLD SESSION FILE #################################
							rm ${script_path}/webwallet/sessions/${cmd_session_id}.sid

							### ENCRYPT AND WRITE NEW SESSION FILE ######################
							echo "${cmd_session_key}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output ${script_path}/webwallet/sessions/${cmd_session_id}.sid --passphrase-fd 0 ${script_path}/webwallet/tmp/${cmd_session_id}.sid 2>/dev/null
							rt_query=$?
						else
							### REMOVE SID FILE #########################################
							rm ${script_path}/webwallet/sessions/${cmd_session_id}.sid
						fi
					fi
				fi
				rm ${script_path}/webwallet/tmp/${cmd_session_id}.sid 2>/dev/null
			fi
		fi
		return $rt_query
}
create_session(){
		### SET RT_QUERY ############################################
		rt_query=1
		
		### CHECK IF IP_ADDRESS IS EMPTY ############################
		if [ ! "${cmd_ip_address}" = "" ]
		then
			### LOOP TO CHECK IF SESSION ID IS FREE #####################
			free_sid=0
			while [ $free_sid = 0 ]
			do
				### CREATE A SESSION ID #####################################
				now_stamp=$(date +%s)
				session_id=$(echo "${now_stamp}${my_pid}"|sha224sum)
				session_id=${session_id%% *}

				### CHECK IF SESSION ID IS FREE #############################
				if [ ! -s ${script_path}/webwallet/sessions/${session_id}.sid ]
				then
					free_sid=1

					### SET SESSION KEY #########################################
					session_key=$(head -c 100 /dev/urandom|tr -dc A-Za-z0-9|head -c 20|sha224sum)
					session_key=${session_key%% *}
					
					### WRITE CREDENTIALS TO FILE################################
					echo "${cmd_ip_address},${now_stamp},${cmd_user},${cmd_pin},${cmd_pw}" >${script_path}/webwallet/tmp/${session_id}.tmp

					### WRITE SID FILE ##########################################
					echo "${session_key}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output ${script_path}/webwallet/sessions/${session_id}.sid --passphrase-fd 0 ${script_path}/webwallet/tmp/${session_id}.tmp 2>/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						cmd_session_id=$session_id
						cmd_session_key=$session_key
						
						### REMOVE FAILED LOGON ATTEMPTS ############################
						logger_string=$(echo "${cmd_ip_address}_${cmd_user}"|sha224sum)
						logger_string=${logger_string%% *}
						rm ${script_path}/webwallet/logger/tmp/${logger_string}.* 2>/dev/null
						
					else
						rm ${script_path}/webwallet/sessions/${session_id}.sid 2>/dev/null
					fi
					rm ${script_path}/webwallet/tmp/${session_id}.tmp
				fi
			done
		fi
		return $rt_query
}
get_address(){
		### SET RT_QUERY ############################################
		rt_query=1

		###FOR EACH SECRET###########################################
		for secret_file in $(ls -1 -X ${script_path}/control/keys/|grep ".sct")
		do
			###GET ADDRESS OF SECRET#####################################
			key_file=${secret_file%%.*}

			###CALCULATE ADDRESS#########################################
			random_secret=$(cat ${script_path}/control/keys/${secret_file})
			key_login=$(echo "${cmd_user}_${random_secret}_${cmd_pin}"|sha224sum)
			key_login=${key_login%% *}
			key_login=$(echo "${key_login}_${cmd_pin}"|sha224sum)
			key_login=${key_login%% *}

			###IF ACCOUNT MATCHES########################################
			if [ "${key_file}" = "${key_login}" ]
			then
				echo "${key_file}" >>${script_path}/webwallet/tmp/addresslist_${my_pid}.tmp
			fi
		done
		#############################################################

		###IF ANY ADDRESSES FOUND####################################
		for user in $(cat ${script_path}/webwallet/tmp/addresslist_${my_pid}.tmp)
		do
			###TEST KEY BY ENCRYPTING A MESSAGE##########################
			echo $cmd_user >${script_path}/webwallet/tmp/account_${my_pid}.tmp
			echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --local-user ${user} -r ${user} --passphrase-fd 0 --pinentry-mode loopback --encrypt --sign ${script_path}/webwallet/tmp/account_${my_pid}.tmp 1>/dev/null 2>/dev/null
			rt_query=$?
			if [ $rt_query = 0 ]
			then
				###REMOVE ENCRYPTION SOURCE FILE#############################
				rm ${script_path}/webwallet/tmp/account_${my_pid}.tmp

				####TEST KEY BY DECRYPTING THE MESSAGE#######################
				echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output ${script_path}/webwallet/tmp/account_${my_pid}.tmp --decrypt ${script_path}/webwallet/tmp/account_${my_pid}.tmp.gpg 1>/dev/null 2>/dev/null
				rt_query=$?
				if [ $rt_query = 0 ]
				then
					extracted_name=$(cat ${script_path}/webwallet/tmp/account_${my_pid}.tmp)
					if [ "${extracted_name}" = "${cmd_user}" ]
					then
						user_address=$user
						rt_query=0
						break
					fi
				fi
			else
				rm ${script_path}/webwallet/tmp/account_${my_pid}.tmp.gpg 2>/dev/null
			fi
		done

		###REMOVE TMP FILES##########################################
		rm ${script_path}/webwallet/tmp/account_${my_pid}.tmp 2>/dev/null
		rm ${script_path}/webwallet/tmp/account_${my_pid}.tmp.gpg 2>/dev/null
		rm ${script_path}/webwallet/tmp/logon_${my_pid}.tmp 2>/dev/null
		rm ${script_path}/webwallet/tmp/addresslist_${my_pid}.tmp 2>/dev/null

		### RETURN IF FOUND #########################################
		return $rt_query
}
### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f ${0}))

### SOURCE CONFIG FILE ###############################
. ${script_path}/control/webwallet.conf

### GET PID FOR TMP FILES ############################
my_pid=$$

###CHECK FOR STDIN INPUT##############################
if [ ! -t 0 ]
then
	set -- $(cat) $*
fi

### CHECK IF GUI MODE OR CMD MODE AND ASSIGN VARIABLES ###
if [ $# -gt 0 ]
then
	### IF ANY VARIABLES ARE HANDED OVER SET INITAL VALUES ##########
	cmd_var=""
	cmd_action=""
	cmd_user=""
	cmd_pin=""
	cmd_pw=""
	cmd_receiver=""
	cmd_amount=""
	cmd_asset=""
	cmd_purpose=""
	cmd_path=""
	cmd_session_id=""
	cmd_session_key=""
	cmd_ip_address=""

	### GO THROUGH PARAMETERS ONE BY ONE ##########################
	while [ $# -gt 0 ]
	do
		### GET TARGET VARIABLES ######################################
		case $1 in
			"-action")	cmd_var=$1
					;;
			"-user")	cmd_var=$1
					;;
			"-pin")		cmd_var=$1
					;;
			"-password")	cmd_var=$1
					;;
			"-receiver")	cmd_var=$1
					;;
			"-amount")	cmd_var=$1
					;;
			"-asset")	cmd_var=$1
					;;
			"-purpose")	cmd_var=$1
					;;
			"-path")	cmd_var=$1
					;;
			"-session_id")	cmd_var=$1
					;;
			"-session_key")	cmd_var=$1
					;;
			"-ip")		cmd_var=$1
					;;
			"-help")	more ${script_path}/control/webwallet_HELP.txt
					exit 0
					;;
			*)		### SET TARGET VARIABLES ######################################
					case $cmd_var in
						"-action")	cmd_action=$1
								if [ ! "${cmd_action}" = "check_name" ] && [ ! "${cmd_action}" = "create_account" ] && [ ! "${cmd_action}" = "delete_account" ] && [ ! "${cmd_action}" = "download_account" ] && [ ! "${cmd_action}" = "download_sync" ] && [ ! "${cmd_action}" = "login_account" ] && [ ! "${cmd_action}" = "logout_account" ] && [ ! "${cmd_action}" = "read_sync" ] && [ ! "${cmd_action}" = "read_trx" ] && [ ! "${cmd_action}" = "send_trx" ] && [ ! "${cmd_action}" = "show_trx" ] && [ ! "$cmd_action" = "sync_uca" ]
								then
									echo "ERROR! TRY THIS:"
									echo "./webwallet.sh -help"
									exit 1
								fi
								;;
						"-user")	cmd_user=$1
								;;
						"-pin")		cmd_pin=$1
								;;
						"-password")	cmd_pw=$1
								;;
						"-receiver")	cmd_receiver=$1
								;;
						"-amount")	cmd_amount=$1
								;;
						"-asset")	cmd_asset=$1
								;;
						"-purpose")	cmd_purpose=$1
								;;
						"-path")	cmd_path=$1
								;;
						"-session_id")	cmd_session_id=$1
								;;
						"-session_key")	cmd_session_key=$1
								;;
						"-ip")		cmd_ip_address=$1
								;;
						*)		echo "ERROR! TRY THIS:"
								echo "./webwallet.sh -help"
								exit 1
								;;
					esac
					cmd_var=""
					;;
		esac
		shift
	done

	### SET VARIABLE FOR LANDING PAGE ##################
	landing_page="<<WWW-DATA_INSTALL_PATH>>/index.html"

	### SET USER ADDRESS ###############################
	user_address=""

	### STEP INTO SCRIPT HOMEDIR #######################
	cd ${script_path}/

	### CHECK USER ACTION ##############################
	case $cmd_action in
		"create_account")	### TRIGGER USER CREATION #################################
					echo "-action create_user -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw}"|./ucs_client.sh >>/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### CREATE SESSION ########################################
						create_session
						rt_query=$?
						if [ $rt_query = 0 ]
						then
							### BUILD MAIN PAGE #######################################
							build_webwallet
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your account!")</script>'
					fi
					;;
		"check_name")		### CHECK USERNAME IS STILL AVAILABLE ######################
					name_hash=$(echo "${cmd_user}"|sha224sum)
					name_hash=${name_hash%% *}
					already_there=$(grep -c -w "${name_hash}" ${script_path}/control/accounts.db)
					
					### ANSWER IS FOR AJAX #####################################
					if [ $already_there = 0 ]
					then
						echo "<b>available &#x2705;</b>"
					else
						echo "<b>already used &#x274C;</b>"
					fi
					;;
		"delete_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### GET USER ADDRESS ######################################
						get_address
						rt_query=$?
						if [ $rt_query = 0 ]
						then
							### REMOVE USER ENTRY FROM ACCOUNTS.DB ####################
							### TO WORK WITH BSD SED -i IS NOT USED####################
							sed "/${user_address}/d" ${script_path}/control/accounts.db >${script_path}/control/${my_pid}_accounts.db
							mv ${script_path}/control/${my_pid}_accounts.db ${script_path}/control/accounts.db

							### STEP INTO USERPATH FOR ADDRESS HANDOVER ###############
							cd ${script_path}/${user_address}/

							### FLOCK KEYS FOLDER WHEN DELETING #######################
							flock ${script_path}/keys/ -c '
							user_path=$(pwd)
							base_dir=$(dirname $user_path)
							script_path=$(dirname $base_dir)
							rm ${script_path}/keys/${user_address} 2>/dev/null
							rm ${script_path}/control/keys/${user_address} 2>/dev/null
							rm -R ${script_path}/proofs/${user_address} 2>/dev/null
							rm -R ${script_path}/userdata/${user_address} 2>/dev/null
							rm ${script_path}/trx/${user_address}.* 2>/dev/null
							'
							###########################################################

							### STEP BACK INTO MAIN DIRECOTRY #########################
							cd ${script_path}/

							### DELETE SESSION ########################################
							rm ${script_path}/webwallet/sessions/${cmd_session_id}.sid

							### DISPLAY LANDING PAGE ##################################
							cat $landing_page

							### SHOW MESSAGE BOX ######################################
							echo '<script type="text/javascript" language="Javascript">alert("INFO: Your account ${user_address} has been deleted!")</script>'
						else
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while deleting your account!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
		"download_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### GET USER ADDRESS ######################################
						get_address
						rt_query=$?
						if [ $rt_query = 0 ]
						then
							### PACK TAR FILE #########################################
							trxlist=$(ls -1 trx/|grep "${user_address}")
							nolines=$(echo "${trx_list}"|wc -l)
							if [ $nolines -gt 0 ]
							then
								trxlist=$(echo "${trxlist}"|awk '{print "trx/" $1}')
							fi
							tar -czf ${script_path}/webwallet/tmp/${user_address}_profile.tar keys/${user_address} control/keys/${user_address} control/keys/${user_address}.sct proofs/${user_address} userdata/${user_address} $trxlist 2>/dev/null
							rt_query=$?
							###########################################################
							if [ $rt_query = 0 ]
							then
								### HANDOVER FILE PATH TO TRIGGER DOWNLOAD ################
								echo "${script_path}/webwallet/tmp/${user_address}_profile.tar"
							fi
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
		"download_sync")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						syncfile=$(echo "-action create_sync -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} -type partial"|./ucs_client.sh|tail -1|cut -d ':' -f2)
						rt_query=$?
						if [ $rt_query = 0 ]
						then
							### HANDOVER FILE PATH TO TRIGGER DOWNLOAD ################
							echo "${syncfile}"
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating the sync file!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
		"login_account")	### BUILD STRING TO IDENTIFY USER ##########################
					logger_string=$(echo "${cmd_ip_address}_${cmd_user}"|sha224sum)
					logger_string=${logger_string%% *}

					### GET STAMP FOR SESSION LOGGER FILE EXTENSION ############
					now_stamp=$(date +%s)

					### DELETE ALL LOCKS OF THE USER OLDER THAN ################
					find ${script_path}/webwallet/logger/${logger_string}.* -maxdepth 1 -type f -mmin +${minutes_to_block} -delete >/dev/null 2>/dev/null

					### DELETE ALL LOGGER FILES OF THE USER OLDER THAN #########
					find ${script_path}/webwallet/logger/tmp/${logger_string}.* -maxdepth 1 -type f -mmin +${minutes_to_watch} -delete >/dev/null 2>/dev/null

					### GET NUMBER OF SESSION LOGGER FILES FOR THIS USER #######
					total_failed_logons=$(ls -1 ${script_path}/webwallet/logger/tmp|grep -c "${logger_string}")
					if [ $total_failed_logons -ge 3 ]
					then
						touch ${script_path}/webwallet/logger/${logger_string}.${now_stamp}
						rm ${script_path}/webwallet/logger/tmp/${logger_string}.* 2>/dev/null
					fi

					### CHECK IF USER IS LOCKED ################################
					total_locks=$(find ${script_path}/webwallet/logger/${logger_string}.* -maxdepth 1 -type f|wc -l)
					if [ $total_locks = 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action show_balance -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw}"|./ucs_client.sh >>/dev/null
						rt_query=$?
						if [ $rt_query = 0 ]
						then
							### CREATE SESSION ########################################
							create_session
							rt_query=$?
							if [ $rt_query = 0 ]
							then
								### DELETE LOGGER SESSION FILES ###########################
								rm ${script_path}/webwallet/logger/tmp/${logger_string}.* 2>/dev/null

								### BUILD MAIN PAGE #######################################
								build_webwallet
							else
								### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
								cat $landing_page
								echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating the session!")</script>'
							fi
						else
							### WRITE SESSION LOGGER FILE FOR FAILED LOGON ############
							touch ${script_path}/webwallet/logger/tmp/${logger_string}.${now_stamp}

							### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
							cat $landing_page
							echo '<script type="text/javascript" language="Javascript">alert("Wrong logon credentials!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("You have entered the wrong password more than 3 times! Please try again later!")</script>'
					fi
					;;
		"logout_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### REMOVE SESSION AND RETURN TO LANDING PAGE #############
						rm ${script_path}/webwallet/sessions/${cmd_session_id}.sid
						cat $landing_page
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
		"read_sync")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action read_sync -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} -path ${cmd_path}"|./ucs_client.sh >>/dev/null
						rt_query=$?
						
						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ $rt_query = 0 ]
						then
							### DISPLAY SUCCESS MESSAGE ###############################
							echo '<script type="text/javascript" language="Javascript">alert("INFO: File successfully uploaded!")</script>'
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while reading your syncfile!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
		"read_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action read_trx -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} -path ${cmd_path}"|./ucs_client.sh >>/dev/null
						rt_query=$?
						
						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ $rt_query = 0 ]
						then
							### DISPLAY SUCCESS MESSAGE ###############################
							echo '<script type="text/javascript" language="Javascript">alert("INFO: File successfully uploaded!")</script>'
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while reading your transaction!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
		"send_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						if [ -e ${cmd_path} ]
						then
							### STRIP SINGLE QUOTES FROM WALLET.PHP ESCAPESHELLARG ####
							cmd_purpose=$(cat ${cmd_path}|php -R 'echo urldecode($argn);')
							
							### WRITE PURPOSE TO FILE AND CONVERT######################
							echo "${cmd_purpose}" >${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp
							dos2unix -f ${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp 2>/dev/null

							### TRIGGER CLIENT ACTION #################################
							echo "-action create_trx -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} -asset ${cmd_asset} -amount ${cmd_amount} -receiver ${cmd_receiver} -file ${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp"|./ucs_client.sh >>/dev/null
							rt_query=$?
							
							### DELETE TMP FILE #######################################
							rm ${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp
							
							### BUILD MAIN PAGE #######################################
							build_webwallet
							if [ $rt_query = 0 ]
							then
								### DISPLAY SUCCESS MESSAGE ###############################
								echo '<script type="text/javascript" language="Javascript">alert("INFO: Transaction was sent!")</script>'
							else
								### DISPLAY ERROR MESSAGE #################################
								echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your transaction!")</script>'
							fi
						else
							### BUILD MAIN PAGE #######################################
							build_webwallet
							
							### DISPLAY ERROR MESSAGE ################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your transaction!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
		"show_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						get_address
						rt_query=$?
						if [ $rt_query = 0 ]
						then
							purpose_key=""
							user_path="${script_path}/userdata/${user_address}"
							purpose_key_start=$(awk -F: '/:PRPK:/{print NR}' ${script_path}/trx/${cmd_path})
							purpose_key_start=$(( purpose_key_start + 1 ))
							purpose_key_end=$(awk -F: '/:PRPS:/{print NR}' ${script_path}/trx/${cmd_path})
							purpose_key_end=$(( purpose_key_end - 1 ))
							purpose_key_encrypted=$(sed -n "${purpose_key_start},${purpose_key_end}p" ${script_path}/trx/${cmd_path})
							###GROUP COMMANDS TO OPEN FILE ONLY ONCE###################
							{
								echo "-----BEGIN PGP MESSAGE-----"
								echo ""
								echo "${purpose_key_encrypted}"
								echo "-----END PGP MESSAGE-----"
							} >${user_path}/history_purpose_key_encrypted.tmp
							echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output ${user_path}/history_purpose_key_decrypted.tmp --decrypt ${user_path}/history_purpose_key_encrypted.tmp 2>/dev/null
							rt_query=$?
							if [ $rt_query = 0 ]
							then
								sender=${cmd_path%%.*}
								stamp=${cmd_path#*.}
								stamp=$(date --date=@${stamp})
								amount=$(awk -F: '/:AMNT:/{print $3}' ${script_path}/trx/${cmd_path})
								purpose=""
								purpose_key=$(cat ${user_path}/history_purpose_key_decrypted.tmp)
								purpose_start=$(awk -F: '/:PRPS:/{print NR}' ${script_path}/trx/${cmd_path})
								purpose_start=$(( purpose_start + 1 ))
								purpose_end=$(awk -F: '/BEGIN PGP SIGNATURE/{print NR}' ${script_path}/trx/${cmd_path})
								purpose_end=$(( purpose_end - 1 ))
								purpose_encrypted=$(sed -n "${purpose_start},${purpose_end}p" ${script_path}/trx/${cmd_path})
								echo "-----BEGIN PGP MESSAGE-----" >${user_path}/history_purpose_encrypted.tmp
								echo "" >>${user_path}/history_purpose_encrypted.tmp
								echo "${purpose_encrypted}" >>${user_path}/history_purpose_encrypted.tmp
								echo "-----END PGP MESSAGE-----" >>${user_path}/history_purpose_encrypted.tmp
								echo "${purpose_key}"|gpg --batch --no-default-keyring --keyring=${script_path}/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output ${user_path}/history_purpose_decrypted.tmp --decrypt ${user_path}/history_purpose_encrypted.tmp 2>/dev/null
								rt_query=$?
								if [ $rt_query = 0 ]
								then
									is_text=$(file ${user_path}/history_purpose_decrypted.tmp|grep -c -v "text")
									if [ $is_text = 0 ]
									then
										### ENCODE PURPOSE BECAUSE OF SPECIAL CHARACTERS ##########
										purpose=$(printf "%s" "$(cat -E ${user_path}/history_purpose_decrypted.tmp|sed 's/\$\$*$/\\n/g'|php -R 'echo htmlentities($argn);')")

										### PRINT TRANSACTION CONTENT AS POPUP#####################
										popup="<script type=\"text/javascript\" language=\"Javascript\"> var myWindow = window.open(\"\", \"MsgWindow\", \"toolbar=yes,scrollbars=yes,resizable=yes\"); myWindow.document.write(\"<h3>Timestamp:<br>${stamp}<br><br>Amount:<br>+${amount}<br><br>Sender:<br>${sender}<br><br>File:<br>${cmd_path}<br><br>Purpose:<br></h3><pre>${purpose}</pre>\");</script>"
										printf "%s" "${popup}"
									else
										### DISPLAY ERROR MESSAGE #################################
										echo '<script type="text/javascript" language="Javascript">alert("NOTE: The purpose cannot be displayed, because it is not in text format.")</script>'
									fi
									
									### BUILD MAIN PAGE #######################################
									build_webwallet
								else
									### DISPLAY ERROR MESSAGE #################################
									echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while decrypting the transaction purpose!")</script>'
								fi
								rm ${user_path}/history_purpose_encrypted.tmp 2>/dev/null
								rm ${user_path}/history_purpose_decrypted.tmp 2>/dev/null
							else
								### DISPLAY ERROR MESSAGE #################################
								echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while decrypting the transaction purpose!")</script>'
							fi
							rm ${user_path}/history_purpose_key_encrypted.tmp 2>/dev/null
							rm ${user_path}/history_purpose_key_decrypted.tmp 2>/dev/null
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
		"sync_uca")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action sync_uca -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw}"|./ucs_client.sh >>/dev/null
						rt_query=$?
						
						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ $rt_query -gt 0 ]
						then
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while performing syncronization!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
					fi
					;;
	esac

	### AUTO LOGOFF ################################################################################
	find ${script_path}/webwallet/sessions/ -maxdepth 1 -type f -mmin +${minutes_logoff} -delete >/dev/null 2>/dev/null

	### DO HOUSEKEEPING AND DELETE ALL TMP SESSION FILES OLDER THAN 5 MINUTES ######################
	find ${script_path}/webwallet/tmp/ -maxdepth 1 -type f -mmin +${minutes_housekeeping} -delete >/dev/null 2>/dev/null
else
	### DISPLAY HELP OVERVIEW MESSAGE ##############################################################
	echo "ERROR! TRY THIS:"
	echo "./webwallet.sh -help"
	exit 1
fi
