#!/bin/sh
build_webwallet(){
			####GET BALANCES######################################
			./ucs_client.sh -action show_balance -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} >${script_path}/webwallet/tmp/${my_pid}.out
			rt_query=$?
			if [ $rt_query = 0 ]
			then
				###FILL BALANCE STRING FOR THE MAIN FORM############
				printf "    <h2 style=\"text-align:center\">Total balance<br></h2>\n" >${script_path}/webwallet/tmp/${my_pid}.tmp
				printf "    <table class=\"center-balance-table\">\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp

				###FILL BALANCE ARRAY FOR SEND FORM#################
				printf "var balanceObject = {\n  " >${script_path}/webwallet/tmp/${my_pid}_.tmp
				while read line
				do
					is_total=`echo $line|grep -c -v "UNLOCKED"`
					if [ $is_total = 1 ]
					then
						###GET DATA FROM OUTPUT#############################
						balance=`echo $line|cut -d ':' -f3|cut -d '=' -f2`
						asset=`echo $line|cut -d ':' -f2`
						user_address=`echo $line|cut -d ':' -f3|cut -d '=' -f1`

						###FILL BALANCE STRING FOR THE MAIN FORM############
						printf "      <tr>\n        <td style="text-align:left"><b>${asset}</b></td>\n        <td style="text-align:right"><b>${balance}</b></td>\n      </tr>\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp

						###FILL BALANCE ARRAY FOR SEND FORM#################
						if [ ! "${main_asset}" = "${cmd_asset}" ]
						then
							printf "  \"${asset}\":{\n    \"${balance}\": [\"1\"]\n  },\n" >>${script_path}/webwallet/tmp/${my_pid}_.tmp
						fi
					fi
				done <${script_path}/webwallet/tmp/${my_pid}.out

				###FILL BALANCE STRING FOR THE MAIN FORM############
				printf "    </table>\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				printf "    <h2 style=\"text-align:center\">Unlocked balance<br></h2>\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				balance=`grep "UNLOCKED" ${script_path}/webwallet/tmp/${my_pid}.out|cut -d ':' -f3|cut -d '=' -f2`
				asset=`grep "UNLOCKED" ${script_path}/webwallet/tmp/${my_pid}.out|cut -d ':' -f2`
				printf "    <table class=\"center-balance-table\">\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				printf "      <tr>\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				printf "        <td style="text-align:left"><b>${asset}</b></td>\n        <td style="text-align:right"><b>${balance}</b></td>\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				printf "      </tr>\n"  >>${script_path}/webwallet/tmp/${my_pid}.tmp
				printf "    </table>\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				address_header=`printf "    <h2 style=\"text-align:center\">Address<br></h2>\n    <h4 style=\"text-align:center;word-break:break-all;word-wrap:break-word;\">${user_address}<br></h4>\n"`
				balance_string=`echo "$address_header"|cat - ${script_path}/webwallet/tmp/${my_pid}.tmp`
				####################################################

				###FILL BALANCE ARRAY FOR SEND FORM#################
				printf "  \"${asset}\":{\n    \"${balance}\": [\"1\"]\n  },\n" >>${script_path}/webwallet/tmp/${my_pid}_.tmp
				printf " }" >>${script_path}/webwallet/tmp/${my_pid}_.tmp
				available_balances_string=`cat ${script_path}/webwallet/tmp/${my_pid}_.tmp`

				###FILL ASSET STRING FOR THE MAIN FORM##############
				user_path="${script_path}/userdata/${user_address}"
				rm ${user_path}/menu_addresses_fungible.tmp 2>/dev/null
				touch ${user_path}/menu_addresses_fungible.tmp
				printf "var subjectObject = {\n" >${script_path}/webwallet/tmp/${my_pid}.tmp
				for asset in `cat ${user_path}/all_assets.dat`
				do
					is_fungible=`grep -c "asset_fungible=1" ${script_path}/assets/${asset}`
					if [ $is_fungible = 1 ]
					then
						echo $asset >>${user_path}/menu_addresses_fungible.tmp
					fi
				done
				#for asset in `cat ${user_path}/all_assets.dat`
				for asset in `grep -v "UNLOCKED" ${script_path}/webwallet/tmp/${my_pid}.out|cut -d ':' -f2`
				do
					printf "  \"${asset}\": {\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
					is_fungible=`grep -c "asset_fungible=1" ${script_path}/assets/${asset}`
					if [ $is_fungible = 1 ]
					then
						cat ${user_path}/menu_addresses_fungible.tmp ${user_path}/all_assets.dat|grep -v "${asset}"|sort|uniq -d|sort -t. -k2|cat - ${user_path}/all_accounts.dat >${user_path}/menu_addresses.tmp
					else
						cat ${user_path}/all_accounts.dat >${user_path}/menu_addresses.tmp
					fi
					while read line
					do
						printf "    \"${line}\": [\"1\"],\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
					done <${user_path}/menu_addresses.tmp
					printf "  },\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				done
				printf " }\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				asset_string=`cat ${script_path}/webwallet/tmp/${my_pid}.tmp`
				####################################################

				###FILL HISTORY STRING FOR MAIN FORM################
				rm ${user_path}/*.tmp 2>/dev/null
				touch ${user_path}/my_trx.tmp
				touch ${user_path}/my_trx_sorted.tmp
				cd ${script_path}/trx
				grep -l ":${user_address}" *.* >${user_path}/my_trx.tmp 2>/dev/null
				cd ${script_path}
				sort -r -t . -k3 ${user_path}/my_trx.tmp >${user_path}/my_trx_sorted.tmp
				mv ${user_path}/my_trx_sorted.tmp ${user_path}/my_trx.tmp
				no_trx=`wc -l <${user_path}/my_trx.tmp`
				if [ $no_trx -gt 0 ]
				then
					printf "       <table class=\"center-history-table\">\n         <tr>\n          <th>Date</th>\n          <th>Address</th>\n          <th>Amount</th>\n          <th>Asset</th>\n          <th>Status</th>\n          <th>Confirmations</th>\n         </tr>\n" >${script_path}/webwallet/tmp/${my_pid}.tmp
					while read line
					do
						trx_file=$line
						trx_data_raw=`sed -n '4,8p' ${script_path}/trx/${trx_file}`
						trx_data=`echo $trx_data_raw|sed 's/ //g'`
						sender=`echo "${trx_data}"|cut -d ':' -f7`
						cmd_receiver=`echo "${trx_data}"|cut -d ':' -f9`
						trx_date_tmp=`echo "${trx_file}"|cut -d '.' -f3`
						trx_date=`date +'%F %H:%M:%S' --date=@${trx_date_tmp}`
						trx_cmd_amount=`echo "${trx_data}"|cut -d ':' -f5|cut -d '|' -f1`
						trx_asset=`echo "${trx_data}"|cut -d ':' -f5|cut -d '|' -f2`
						trx_status=""
						trx_hash=`sha256sum ${script_path}/trx/${trx_file}|cut -d ' ' -f1`
						trx_confirmations=`grep -l "trx/${trx_file} ${trx_hash}" proofs/*.*/*.txt|grep -v "${user_address}\|${sender}"|wc -l`
						if [ -s ${script_path}/proofs/${sender}/${sender}.txt ]
						then
							trx_signed=`grep -c "${trx_file}" ${script_path}/proofs/${sender}/${sender}.txt`
						else
							trx_status="${trx_status}TRX_IGNORED "
							trx_signed=0
						fi
						trx_blacklisted=`grep -c "${trx_file}" ${user_path}/blacklisted_trx.dat`
						if [ $trx_blacklisted = 1 ]
						then
							trx_status="${trx_status}TRX_BLACKLISTED "
						fi
						sender_blacklisted=`grep -c "${sender}" ${user_path}/blacklisted_accounts.dat`
						if [ $sender_blacklisted = 1 ]
						then
							trx_status="${trx_status}SDR_BLACKLISTED "
						fi
						cmd_receiver_blacklisted=`grep -c "${cmd_receiver}" ${user_path}/blacklisted_accounts.dat`
						if [ $cmd_receiver_blacklisted = 1 ]
						then
							trx_status="${trx_status}RCV_BLACKLISTED "
						fi
						if [ $trx_signed = 1 -a $trx_blacklisted = 0 -a $sender_blacklisted = 0 -a $cmd_receiver_blacklisted = 0 ]
						then
							trx_status="OK"
						fi
						if [ "${sender}" = "${user_address}" ]
						then
							printf "         <tr>\n           <td>${trx_date}</td>\n           <td>${cmd_receiver}</td>\n           <td>-${trx_cmd_amount}</td>\n           <td>${trx_asset}</td>\n           <td>${trx_status}</td>\n           <td>${trx_confirmations}</td>\n         </tr>\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
						fi
						if [ "${cmd_receiver}" = "${user_address}" ]
						then
							printf "         <tr>\n           <td>${trx_date}</td>\n           <td>${sender}</td>\n           <td>+${trx_cmd_amount}</td>\n           <td>${trx_asset}</td>\n           <td>${trx_status}</td>\n           <td>${trx_confirmations}</td>\n         </tr>\n" >>${script_path}/webwallet/tmp/${my_pid}.tmp
						fi
					done <${user_path}/my_trx.tmp
					printf "       </table>" >>${script_path}/webwallet/tmp/${my_pid}.tmp
				else
					printf "       <h2 style=\"text-align:center\">no results!:<br></h2>" >${script_path}/webwallet/tmp/${my_pid}.tmp
				fi
				history_string=`cat ${script_path}/webwallet/tmp/${my_pid}.tmp`
				####################################################

				###BUILD HTML PAGE##################################
				end_line=`grep -n "<<BALANCES>>" ${script_path}/webwallet/webwallet_template.html|cut -d ':' -f1`
				end_line=$(( $end_line - 1 ))
				head -$end_line ${script_path}/webwallet/webwallet_template.html
				echo "$balance_string"
				start_line=$(( $end_line + 1 ))
				end_line=`grep -n "<<TRX_TABLE>>" ${script_path}/webwallet/webwallet_template.html|cut -d ':' -f1`
				end_line=$(( $end_line - 1 ))
				tail_line=$(( $end_line - $start_line ))
				head -$end_line ${script_path}/webwallet/webwallet_template.html|tail -$tail_line|sed -e "s/<<USERNAME>>/${cmd_user}/g" -e "s/<<PIN>>/${cmd_pin}/g" -e "s/<<PASSWORD>>/${cmd_pw}/g"
				echo "$history_string"
				start_line=$(( $end_line + 1 ))
				end_line=`grep -n "<<CASCADE_DROPDOWN>>" ${script_path}/webwallet/webwallet_template.html|cut -d ':' -f1`
				end_line=$(( $end_line - 1 ))
				tail_line=$(( $end_line - $start_line ))
				head -$end_line ${script_path}/webwallet/webwallet_template.html|tail -$tail_line|sed -e "s/<<USERNAME>>/${cmd_user}/g" -e "s/<<PIN>>/${cmd_pin}/g" -e "s/<<PASSWORD>>/${cmd_pw}/g"
				echo "$asset_string"
				echo "$available_balances_string"
				start_line=$(( $end_line + 1 ))
				full_line=`wc -l <${script_path}/webwallet/webwallet_template.html`
				tail_line=$(( $full_line - $start_line ))
				tail -$tail_line ${script_path}/webwallet/webwallet_template.html
				#####################################################
			fi
			###REMOVE TMP FILES##################################
			rm ${script_path}/webwallet/tmp/${my_pid}.tmp 2>/dev/null
			rm ${script_path}/webwallet/tmp/${my_pid}_.tmp 2>/dev/null
			rm ${script_path}/webwallet/tmp/${my_pid}.out 2>/dev/null

			###RETURNCODE########################################
			return $rt_query
}
get_address(){
		###TRY TO LOGON##############################################
		./ucs_client.sh -action show_balance -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} >>/dev/null
		rt_query=$?
		if [ $rt_query = 0 ]
		then
			###READ LIST OF KEYS LINE BY LINE############################
			for key_file in `ls -1 ${script_path}/keys/|sort -t . -k2`
			do
				###EXTRACT KEY DATA##########################################
				keylist_name=`echo $key_file|cut -d '.' -f1`
				keylist_stamp=`echo $key_file|cut -d '.' -f2`
				keylist_hash=`echo "${cmd_user}_${keylist_stamp}_${cmd_pin}"|sha256sum|cut -d ' ' -f1`
				#############################################################

				###IF ACCOUNT MATCHES########################################
				if [ $keylist_name = $keylist_hash ]
				then
					user_address="${keylist_hash}.${keylist_stamp}"
					break
				fi
				##############################################################
			done
			#############################################################
		fi
		#############################################################

		###RETURN IF FOUND###########################################
		return $rt_query
}
###GET SCRIPT PATH##################################
script_path=`dirname $(readlink -f ${0})`

###GET PID FOR TMP FILES############################
my_pid=$$

###CHECK IF GUI MODE OR CMD MODE AND ASSIGN VARIABLES###
if [ $# -gt 0 ]
then
	###IF ANY VARIABLES ARE HANDED OVER SET INITAL VALUES##########
	cmd_var=""
	cmd_action=""
	cmd_user=""
	cmd_pin=""
	cmd_pw=""
	cmd_receiver=""
	cmd_amount=""
	cmd_asset=""
	cmd_purpose=""
	cmd_path=""

	###GO THROUGH PARAMETERS ONE BY ONE############################
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case $1 in
			"-action")	cmd_var=$1
					;;
			"-user")	cmd_var=$1
					;;
			"-pin")		cmd_var=$1
					;;
			"-password")	cmd_var=$1
					;;
			"-receiver")	cmd_var=$1
					;;
			"-amount")	cmd_var=$1
					;;
			"-asset")	cmd_var=$1
					;;
			"-purpose")	cmd_var=$1
					;;
			"-path")	cmd_var=$1
					;;
			"-help")	more ${script_path}/control/webwallet_HELP.txt
					exit 0
					;;
			*)		###SET TARGET VARIABLES########################################
					case $cmd_var in
						"-action")	cmd_action=$1
								if [ ! "${cmd_action}" = "create_account" -a ! "${cmd_action}" = "delete_account" -a ! "${cmd_action}" = "download_account" -a ! "${cmd_action}" = "download_sync" -a ! "${cmd_action}" = "login_account" -a ! "${cmd_action}" = "read_sync" -a ! "${cmd_action}" = "read_trx " -a ! "${cmd_action}" = "send_trx" -a ! "$cmd_action" = "sync_uca" ]
								then 
									echo "ERROR! TRY THIS:"
									echo "./webwallet.sh -help"
									exit 1
								fi
								;;
						"-user")	cmd_user=$1
								;;
						"-pin")		cmd_pin=$1
								;;
						"-password")	cmd_pw=$1
								;;
						"-receiver")	cmd_receiver=$1
								;;
						"-amount")	cmd_amount=$1
								;;
						"-asset")	cmd_asset=$1
								;;
						"-purpose")	cmd_purpose=$1
								;;
						"-path")	cmd_path=$1
								;;
						*)		echo "ERROR! TRY THIS:"
								echo "./webwallet.sh -help"
								exit 1
								;;
					esac
					cmd_var=""
					;;
		esac
		shift
	done

	###SET VARIABLE FOR LANDING PAGE####################
	landing_page="<<WWW-DATA_INSTALL_PATH>>/index.html"

	###SET USER ADDRESS#################################
	user_address=""

	###STEP INTO SCRIPT HOMEDIR#########################
	cd ${script_path}/

	###CHECK USER ACTION################################
	case $cmd_action in
		"create_account")	./ucs_client.sh -action create_user -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} >>/dev/null
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						build_webwallet
					else
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your account!")</script>'
					fi
					;;
		"delete_account")	get_address
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						###STEP INTO USERPATH FOR ADDRESS HANDOVER############
						cd ${script_path}/${user_address}/

						###FLOCK KEYS FOLDER WHEN DELETING####################
						flock ${script_path}/keys/ -c '
						user_path=`pwd`
						base_dir=`dirname $user_path`
						script_path=`dirname $base_dir`
						rm ${script_path}/keys/${user_address} 2>/dev/null
						rm ${script_path}/control/keys/${user_address} 2>/dev/null
						rm -R ${script_path}/proofs/${user_address} 2>/dev/null
						rm -R ${script_path}/userdata/${user_address} 2>/dev/null
						rm ${script_path}/trx/${user_address}.* 2>/dev/null
						'
						######################################################

						###STEP BACK INTO MAIN DIRECOTRY######################
						cd ${script_path}/

						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("INFO: Your account ${user_address} has been deleted!")</script>'
					else
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while deleting your account!")</script>'
					fi
					;;
		"download_account")	get_address
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						trxlist=`ls -1 trx/|grep "${user_address}"`
						nolines=`echo "${trx_list}"|wc -l`
						if [ $nolines -gt 0 ]
						then
							trxlist=`echo "${trxlist}"|awk '{print "trx/" $1}'`
						fi
						tar -czf ${script_path}/webwallet/tmp/${user_address}_profile.tar keys/${user_address} control/keys/${user_address} proofs/${user_address} $trxlist 2>/dev/null
						rt_query=$?
						if [ $rt_query = 0 ]
						then
							echo "${script_path}/webwallet/tmp/${user_address}_profile.tar"
						fi
					else
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured!")</script>'
					fi
					;;
		"download_sync")	syncfile=`./ucs_client.sh -action create_sync -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} -type partial|tail -1|cut -d ':' -f2`
					rt_query=$?
					if [ $rt_query = 0 ]
					then
						echo "${syncfile}"
					else
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating the sync file!")</script>'
					fi
					;;
		"login_account")	build_webwallet
					rt_query=$?
					if [ $rt_query -gt 0 ]
					then
						cat $landing_page
						echo '<script type="text/javascript" language="Javascript">alert("Wrong logon credentials!")</script>'
					fi
					;;
		"read_sync")		./ucs_client.sh -action read_sync -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} -path ${cmd_path} >>/dev/null
					rt_query=$?
					build_webwallet
					if [ $rt_query = 0 ]
					then
						echo '<script type="text/javascript" language="Javascript">alert("INFO: File successfully uploaded!")</script>'
					else
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while reading your syncfile!")</script>'
					fi
					;;
		"read_trx")		./ucs_client.sh -action read_trx -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} -path ${cmd_path} >>/dev/null
					rt_query=$?
					build_webwallet
					if [ $rt_query = 0 ]
					then
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while reading your transaction!")</script>'
					else
						echo '<script type="text/javascript" language="Javascript">alert("INFO: File successfully uploaded!")</script>'
					fi
					;;
		"send_trx")		./ucs_client.sh -action create_trx -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} -asset ${cmd_asset} -amount ${cmd_amount} -receiver ${cmd_receiver} -purpose ${cmd_purpose} >>/dev/null
					rt_query=$?
					build_webwallet
					if [ $rt_query = 0 ]
					then
						echo '<script type="text/javascript" language="Javascript">alert("INFO: Transaction was sent!")</script>'
					else
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your transaction!")</script>'
					fi
					;;
		"sync_uca")		./ucs_client.sh -action sync_uca -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw} >>/dev/null
					rt_query=$?
					build_webwallet
					if [ $rt_query -gt 0 ]
					then
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while performing syncronization!")</script>'
					fi
					;;
	esac

else
	echo "ERROR! TRY THIS:"
	echo "./webwallet.sh -help"
	exit 1
fi
