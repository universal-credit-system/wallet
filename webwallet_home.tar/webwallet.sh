#!/bin/sh
build_webwallet(){
			### SET VARIABLES ####################################
			main_string=""
			send_string=""
			user_address=""

			### GET BALANCES #####################################
			echo "-action show_balance -sender ${cmd_sender}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >"${script_path}/webwallet/tmp/${my_pid}.out" 2>/dev/null
			rt_query=$?
			if [ "$rt_query" -eq 0 ]
			then
				### FILL BALANCE STRING FOR THE MAIN FORM ##########
				main_string="    <h2 style=\"text-align:center\">Total balance<br></h2>\n"
				main_string="${main_string}    <table class=\"center-balance-table\">\n"

				### FILL BALANCE ARRAY FOR SEND FORM ###############
				send_string="var balanceObject = {\n"
				while read line
				do
					### GET DATA FROM OUTPUT ###########################
					balance=$(echo "$line"|cut -d ':' -f3|cut -d '=' -f2)
					asset=$(echo "$line"|cut -d ':' -f2)
					user_address=$(echo "$line"|cut -d ':' -f3|cut -d '=' -f1)

					### FILL BALANCE STRING FOR THE MAIN FORM ##########
					main_string="${main_string}      <tr>\n        <td style=\"text-align:left\"><b>${asset}</b></td>\n        <td style=\"text-align:right\"><b>${balance}</b></td>\n      </tr>\n"

					### FILL BALANCE ARRAY FOR SEND FORM ###############
					if [ ! "${main_asset}" = "${cmd_asset}" ]
					then
						send_string="${send_string}  \"${asset}\":{\n    \"${balance}\": [\"1\"]\n  },\n"
					fi
				done <"${script_path}/webwallet/tmp/${my_pid}.out"

				### FILL BALANCE STRING FOR THE MAIN FORM ##########
				main_string="${main_string}    </table>\n"
				balance_string=$(printf "%b" "    <h2 style=\"text-align:center\">Address<br></h2>\n    <h4 style=\"text-align:center;word-break:break-all;word-wrap:break-word;\">${user_address}<br></h4>\n${main_string}")
				####################################################

				### FILL BALANCE ARRAY FOR SEND FORM ###############
				send_string="${send_string}  \"${asset}\":{\n    \"${balance}\": [\"1\"]\n  },\n"
				send_string="${send_string} }"
				available_balances_string=$(printf "%b" "$send_string")

				### FILL ASSET STRING FOR THE MAIN FORM ############
				user_path="${script_path}/userdata/${user_address}"
				addresses=$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.tmp -p "${script_path}"/webwallet/tmp/)
				addresses_base=$(basename "$addresses")
				addresses_fungible=$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.tmp -p "${script_path}"/webwallet/tmp/)
				addresses_fungible_base=$(basename "$addresses_fungible")
				main_string="var subjectObject = {\n"
				for asset in $(cat "${user_path}"/all_assets.dat)
				do
					is_fungible=$(grep -c "asset_fungible=1" "${script_path}/assets/${asset}")
					if [ "$is_fungible" -eq 1 ]
					then
						echo "$asset" >>"${addresses_fungible}"
					fi
				done
				for asset in $(cut -d ':' -f2 "${script_path}/webwallet/tmp/${my_pid}.out")
				do
					main_string="${main_string}  \"${asset}\": {\n"
					is_fungible=$(grep -c "asset_fungible=1" "${script_path}/assets/${asset}")
					if [ "$is_fungible" -eq 1 ]
					then
						sort -t. -k2 "${addresses_fungible}"|grep -v -h "${user_address}\|${asset}" - "${user_path}"/all_accounts.dat >"${addresses}"
					else
						grep -v "${user_address}" "${user_path}"/all_accounts.dat >"${addresses}"
					fi
					while read line
					do
						main_string="${main_string}    \"${line}\": [\"1\"],\n"
					done <"${addresses}"
					main_string="${main_string}  },\n"
				done
				main_string="${main_string} }\n"
				asset_string=$(printf "%b" "${main_string}")
				rm "${script_path}/webwallet/tmp/${addresses_base}" 2>/dev/null
				rm "${script_path}/webwallet/tmp/${addresses_fungible_base}" 2>/dev/null
				####################################################

				### FILL HISTORY STRING FOR MAIN FORM ##############
				my_trx=$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.tmp -p "${script_path}"/webwallet/tmp/)
				my_trx_base=$(basename "$my_trx")
				grep -s -l ":${user_address}" -- "${script_path}"/trx/*.*|sort -r -t . -k2 >"${my_trx}"
				if [ "$(wc -l <"${my_trx}")" -gt 0 ]
				then
					main_string="    <div style=\"height:300px;overflow-y:scroll;overflow-x:auto;\">\n       <table class=\"center-history-table\">\n         <tr>\n          <th>Date</th>\n          <th>Address</th>\n          <th>Amount</th>\n          <th>Asset</th>\n          <th>Purpose</th>\n          <th>Status</th>\n          <th>Confirmations</th>\n         </tr>\n"
					while read trx_file
					do
						trx_filename=$(basename "${trx_file}")
						sender=$(awk -F: '/:SNDR:/{print $3}' "${trx_file}")
						receiver=$(awk -F: '/:RCVR:/{print $3}' "${trx_file}")
						trx_date=$(date +'%F %H:%M:%S' --date=@"$(awk -F: '/:TIME:/{print $3}' "${trx_file}")")
						trx_cmd_amount=$(awk -F: '/:AMNT:/{print $3}' "${trx_file}")
						trx_asset=$(awk -F: '/:ASST:/{print $3}' "${trx_file}")
						trx_status=""
						trx_hash=$(sha256sum "${trx_file}")
						trx_hash=${trx_hash%% *}
						trx_confirmations=$(grep -l "trx/${trx_filename} ${trx_hash}" proofs/*/*.txt|grep -f "${user_path}"/all_accounts.dat|grep -c -v "${sender}\|${receiver}")
						if [ -s "${script_path}/proofs/${sender}/${sender}.txt" ]
						then
							trx_signed=$(grep -c "trx/${trx_filename}" "${script_path}/proofs/${sender}/${sender}.txt")
						else
							trx_status="${trx_status}TRX_IGNORED "
							trx_signed=0
						fi
						trx_blacklisted=$(grep -c "${trx_filename}" "${user_path}"/blacklisted_trx.dat)
						if [ "$trx_blacklisted" -eq 1 ]
						then
							trx_status="${trx_status}TRX_BLACKLISTED "
						fi
						sender_blacklisted=$(grep -c "${sender}" "${user_path}"/blacklisted_accounts.dat)
						if [ "$sender_blacklisted" -eq 1 ]
						then
							trx_status="${trx_status}SDR_BLACKLISTED "
						fi
						receiver_blacklisted=$(grep -c "${receiver}" "${user_path}"/blacklisted_accounts.dat)
						if [ "$receiver_blacklisted" -eq 1 ]
						then
							trx_status="${trx_status}RCV_BLACKLISTED "
						fi
						if [ "$trx_signed" -eq 1 ] && [ "$trx_blacklisted" -eq 0 ] && [ "$sender_blacklisted" -eq 0 ] && [ "$receiver_blacklisted" -eq 0 ]
						then
							trx_status="OK"
						fi
						if [ "${sender}" = "${user_address}" ]
						then
							main_string="${main_string}         <tr>\n           <td>${trx_date}</td>\n           <td>${receiver}</td>\n           <td>-${trx_cmd_amount}</td>\n           <td>${trx_asset}</td>\n           <td>-</td>\n           <td>${trx_status}</td>\n           <td>${trx_confirmations}</td>\n         </tr>\n"
						fi
						if [ "${receiver}" = "${user_address}" ]
						then
							main_string="${main_string}         <tr>\n           <td>${trx_date}</td>\n           <td>${sender}</td>\n           <td>+${trx_cmd_amount}</td>\n           <td>${trx_asset}</td>\n           <td><button type=\"submit\" name=\"trx_file\" value=\"${trx_filename}\">show</button></td>\n           <td>${trx_status}</td>\n           <td>${trx_confirmations}</td>\n         </tr>\n"
						fi
					done <"${my_trx}"
					main_string="${main_string}       </table>\n    </div>\n"
				else
					main_string="       <h2 style=\"text-align:center\">no results<br></h2>\n"
				fi
				history_string=$(printf "%b" "${main_string}")
				rm "${script_path}/webwallet/tmp/${my_trx_base}" 2>/dev/null
				####################################################

				### BUILD HTML PAGE ################################
				end_line=$(grep -n "<<BALANCES>>" "${script_path}"/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				head -$end_line "${script_path}"/webwallet/webwallet_template.html
				echo "$balance_string"
				start_line=$(( end_line + 1 ))
				end_line=$(grep -n "<<TRX_TABLE>>" "${script_path}"/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				tail_line=$(( end_line - start_line ))
				head -$end_line "${script_path}"/webwallet/webwallet_template.html|tail -$tail_line|sed -e "s/<<SID>>/${cmd_session_id}/g" -e "s/<<SKEY>>/${cmd_session_key}/g"
				echo "$history_string"
				start_line=$(( end_line + 1 ))
				end_line=$(grep -n "<<CASCADE_DROPDOWN>>" "${script_path}"/webwallet/webwallet_template.html)
				end_line=${end_line%%:*}
				end_line=$(( end_line - 1 ))
				tail_line=$(( end_line - start_line ))
				head -$end_line "${script_path}"/webwallet/webwallet_template.html|tail -$tail_line|sed -e "s/<<SID>>/${cmd_session_id}/g" -e "s/<<SKEY>>/${cmd_session_key}/g"
				echo "$asset_string"
				echo "$available_balances_string"
				start_line=$(( end_line + 1 ))
				full_line=$(wc -l <"${script_path}"/webwallet/webwallet_template.html)
				tail_line=$(( full_line - start_line ))
				tail -$tail_line "${script_path}"/webwallet/webwallet_template.html
				#####################################################
			fi
			### REMOVE TMP FILE #################################
			rm "${script_path}/webwallet/tmp/${my_pid}.out" 2>/dev/null

			### RETURNCODE ######################################
			return $rt_query
}
check_session(){
		### SET RT_QUERY ############################################
		rt_query=1

		### GET NOW STAMP ###########################################
		now_stamp=$(date +%s)

		### CHECK IF VARIABLES ARE EMPTY ############################
		if [ -n "${cmd_session_id}" ] && [ -n "${cmd_session_key}" ] && [ -n "${cmd_ip_address}" ]
		then
			### CHECK IF SESSION FILE EXISTS ############################
			if [ -s "${script_path}/webwallet/sessions/${cmd_session_id}.sid" ]
			then
				### TRY TO DECRYPT SESSION FILE #############################
				echo "${cmd_session_key}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${script_path}/webwallet/tmp/${cmd_session_id}.sid" --decrypt "${script_path}/webwallet/sessions/${cmd_session_id}.sid" 1>/dev/null 2>/dev/null
				rt_query=$?
				if [ "$rt_query" -eq 0 ]
				then
					### CHECK IF SESSION IS TIMED OUT ###########################
					session_string=$(head -1 "${script_path}/webwallet/tmp/${cmd_session_id}.sid")
					check_ip=${session_string%%,*}
					if [ "${check_ip}" = "${cmd_ip_address}" ]
					then
						### SET VARIABLES ###########################################
						session_string=${session_string#*,}
						session_stamp=${session_string%%,*}

						### REMOVE SID FILE #########################################
						rm "${script_path}/webwallet/sessions/${cmd_session_id}.sid"

						### IF SESSION IS NOT EXPIRED ###############################
						if [ $(( now_stamp - session_stamp )) -le $(( minutes_logoff * 60 )) ]
						then
							### SET VARIABLES ###########################################
							session_string=${session_string#*,}
							cmd_user=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_pin=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_pw=${session_string%%,*}
							session_string=${session_string#*,}
							cmd_sender=${session_string%%,*}
							user_address=$cmd_sender

							### RENEW STAMP #############################################
							echo "${cmd_ip_address},${now_stamp},${cmd_user},${cmd_pin},${cmd_pw},${cmd_sender}" >"${script_path}/webwallet/tmp/${cmd_session_id}.sid"

							### ENCRYPT AND WRITE NEW SESSION FILE ######################
							echo "${cmd_session_key}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output "${script_path}/webwallet/sessions/${cmd_session_id}.sid" --passphrase-fd 0 "${script_path}/webwallet/tmp/${cmd_session_id}.sid" 2>/dev/null
							rt_query=$?
						else
							rt_query=1
						fi
					else
						rt_query=1
					fi
				fi
				rm "${script_path}/webwallet/tmp/${cmd_session_id}.sid" 2>/dev/null
			fi
		fi
		if [ "$rt_query" -eq 1 ]
		then
			### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
			cat "$landing_page"
			echo '<script type="text/javascript" language="Javascript">alert("ERROR: Your session has expired! Please log on again!")</script>'
		fi
		return $rt_query
}
create_session(){
		### SET RT_QUERY ############################################
		rt_query=1

		### CHECK IF IP_ADDRESS IS EMPTY ############################
		if [ -n "${cmd_ip_address}" ]
		then
			###TEST KEY BY ENCRYPTING A MESSAGE##########################
			echo "${cmd_user}" >"${script_path}/webwallet/tmp/account_${my_pid}.tmp"
			echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring="${script_path}/control/keyring.file" --trust-model always --local-user "${user_address}" -r "${user_address}" --passphrase-fd 0 --pinentry-mode loopback --encrypt --sign "${script_path}/webwallet/tmp/account_${my_pid}.tmp" 1>/dev/null 2>/dev/null
			rt_query=$?
			if [ "$rt_query" -eq 0 ]
			then
				###REMOVE ENCRYPTION SOURCE FILE#############################
				rm "${script_path}/webwallet/tmp/account_${my_pid}.tmp"

				####TEST KEY BY DECRYPTING THE MESSAGE#######################
				echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${script_path}/webwallet/tmp/account_${my_pid}.tmp" --decrypt "${script_path}/webwallet/tmp/account_${my_pid}.tmp.gpg" 1>/dev/null 2>/dev/null
				rt_query=$?
			fi
			rm "${script_path}/webwallet/tmp/account_${my_pid}".* 2>/dev/null
			if [ "$rt_query" -eq 0 ]
			then
				### CREATE A SESSION ID #####################################
				session_id=$(basename --suffix=.sid "$(mktemp XXXXXXXXXXXXXXXXXXXX --suffix=.sid -p "${script_path}"/webwallet/sessions/)")

				### SET SESSION KEY #########################################
				session_key=$(head -c 100 /dev/urandom|tr -dc A-Za-z0-9|head -c 20|sha224sum)
				session_key=${session_key%% *}

				### GET CURRENT TIMESTAMP ###################################
				now_stamp=$(date +%s)

				### WRITE CREDENTIALS TO FILE################################
				echo "${cmd_ip_address},${now_stamp},${cmd_user},${cmd_pin},${cmd_pw},${cmd_sender}" >"${script_path}/webwallet/tmp/${session_id}.tmp"

				### WRITE SID FILE ##########################################
				echo "${session_key}"|gpg --batch --no-tty --s2k-mode 3 --s2k-count 65011712 --s2k-digest-algo SHA512 --s2k-cipher-algo AES256 --pinentry-mode loopback --symmetric --cipher-algo AES256 --output "${script_path}/webwallet/tmp/${session_id}.sid" --passphrase-fd 0 "${script_path}/webwallet/tmp/${session_id}.tmp" 2>/dev/null
				rt_query=$?
				if [ "$rt_query" -eq 0 ]
				then
					cmd_session_id=$session_id
					cmd_session_key=$session_key

					### MOVE SESSION FILE INTO SESSION FOLDER ###################
					mv "${script_path}/webwallet/tmp/${session_id}.sid" "${script_path}/webwallet/sessions/${session_id}.sid"
				else
					rm "${script_path}/webwallet/sessions/${session_id}.sid" 2>/dev/null
				fi
				rm "${script_path}/webwallet/tmp/${session_id}.tmp"
			else
				rt_query=1
			fi
		fi
		return $rt_query
}
get_address(){
		### SET RT_QUERY ############################################
		rt_query=1

		###FOR EACH SECRET###########################################
		for secret_file in $(ls -1 "${script_path}"/control/keys/|grep ".sct")
		do
			###GET ADDRESS OF SECRET#####################################
			key_file=${secret_file%%.*}

			###CALCULATE ADDRESS#########################################
			random_secret=$(cat "${script_path}/control/keys/${secret_file}")
			key_login=$(echo "${cmd_user}_${random_secret}_${cmd_pin}"|sha224sum)
			key_login=${key_login%% *}
			key_login=$(echo "${key_login}_${cmd_pin}"|sha224sum)
			key_login=${key_login%% *}

			###IF ACCOUNT MATCHES########################################
			if [ "${key_file}" = "${key_login}" ]
			then
				user_address=$key_file
				cmd_sender=$key_file
				rt_query=0
				break
			fi
		done

		### RETURN IF FOUND #########################################
		return $rt_query
}
### SET DEFAULT VALUES ###############################
max_failed_logons=3
minutes_to_watch=30
minutes_to_block=30
minutes_logoff=30
minutes_housekeeping=5

### GET SCRIPT PATH ##################################
script_path=$(dirname "$(readlink -f "${0}")")

### SOURCE CONFIG FILE ###############################
. "${script_path}"/control/webwallet.conf

### GET PID FOR TMP FILES ############################
my_pid=$$

###CHECK FOR STDIN INPUT##############################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi

### CHECK IF GUI MODE OR CMD MODE AND ASSIGN VARIABLES ###
if [ $# -gt 0 ]
then
	### IF ANY VARIABLES ARE HANDED OVER SET INITAL VALUES ##########
	cmd_var=""
	cmd_action=""
	cmd_user=""
	cmd_pin=""
	cmd_pw=""
	cmd_receiver=""
	cmd_amount=""
	cmd_asset=""
	cmd_purpose=""
	cmd_path=""
	cmd_session_id=""
	cmd_session_key=""
	cmd_ip_address=""

	### GO THROUGH PARAMETERS ONE BY ONE ##########################
	while [ $# -gt 0 ]
	do
		### GET TARGET VARIABLES ######################################
		case $1 in
			"-action")	cmd_var=$1
					;;
			"-user")	cmd_var=$1
					;;
			"-pin")		cmd_var=$1
					;;
			"-password")	cmd_var=$1
					;;
			"-receiver")	cmd_var=$1
					;;
			"-amount")	cmd_var=$1
					;;
			"-asset")	cmd_var=$1
					;;
			"-purpose")	cmd_var=$1
					;;
			"-path")	cmd_var=$1
					;;
			"-session_id")	cmd_var=$1
					;;
			"-session_key")	cmd_var=$1
					;;
			"-ip")		cmd_var=$1
					;;
			"-help")	more "${script_path}"/control/webwallet_HELP.txt
					exit 0
					;;
			*)		### SET TARGET VARIABLES ######################################
					case $cmd_var in
						"-action")	cmd_action=$1
								if [ ! "${cmd_action}" = "check_name" ] && [ ! "${cmd_action}" = "create_account" ] && [ ! "${cmd_action}" = "delete_account" ] && [ ! "${cmd_action}" = "download_account" ] && [ ! "${cmd_action}" = "download_sync" ] && [ ! "${cmd_action}" = "login_account" ] && [ ! "${cmd_action}" = "logout_account" ] && [ ! "${cmd_action}" = "read_sync" ] && [ ! "${cmd_action}" = "read_trx" ] && [ ! "${cmd_action}" = "send_trx" ] && [ ! "${cmd_action}" = "show_trx" ] && [ ! "$cmd_action" = "sync_uca" ]
								then
									echo "ERROR! TRY THIS:"
									echo "./webwallet.sh -help"
									exit 1
								fi
								;;
						"-user")	cmd_user=$1
								;;
						"-pin")		cmd_pin=$1
								;;
						"-password")	cmd_pw=$1
								;;
						"-receiver")	cmd_receiver=$1
								;;
						"-amount")	cmd_amount=$1
								;;
						"-asset")	cmd_asset=$1
								;;
						"-purpose")	cmd_purpose=$1
								;;
						"-path")	cmd_path=$1
								;;
						"-session_id")	cmd_session_id=$1
								;;
						"-session_key")	cmd_session_key=$1
								;;
						"-ip")		cmd_ip_address=$1
								;;
						*)		echo "ERROR! TRY THIS:"
								echo "./webwallet.sh -help"
								exit 1
								;;
					esac
					cmd_var=""
					;;
		esac
		shift
	done

	### SET VARIABLE FOR LANDING PAGE ##################
	landing_page="${path_www_data}/index.html"

	### SET USER ADDRESS ###############################
	user_address=""

	### STEP INTO SCRIPT HOMEDIR #######################
	cd "${script_path}"/ || exit 2

	### CHECK USER ACTION ##############################
	case $cmd_action in
		"create_account")	### TRIGGER USER CREATION #################################
					echo "-action create_user -user ${cmd_user} -pin ${cmd_pin} -password ${cmd_pw}"|./ucs_client.sh >>/dev/null
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						### GET USER ADDRESS ######################################
						get_address
						rt_query=$?
						if [ "$rt_query" -eq 0 ]
						then
							### CREATE SESSION ########################################
							create_session
							rt_query=$?
							if [ "$rt_query" -eq 0 ]
							then
								### BUILD MAIN PAGE #######################################
								build_webwallet
							fi
						fi
					fi
					if [ "$rt_query" -eq 1 ]
					then
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat "$landing_page"
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your account!")</script>'
					fi
					;;
		"check_name")		### CHECK USERNAME IS STILL AVAILABLE ######################
					name_hash=$(echo "${cmd_user}"|sha224sum)
					name_hash=${name_hash%% *}
					already_there=$(grep -c -w "${name_hash}" "${script_path}"/control/accounts.db)

					### ANSWER IS FOR AJAX #####################################
					if [ "$already_there" -eq 0 ]
					then
						echo "<b>available &#x2705;</b>"
					else
						echo "<b>already used &#x274C;</b>"
					fi
					;;
		"delete_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						### REMOVE USER ENTRY FROM ACCOUNTS.DB ###################
						### TO WORK WITH BSD SED -i IS NOT USED ##################
						cmd_user_hash=$(echo "${cmd_user}"|sha224sum)
						cmd_user_hash=${cmd_user_hash%% *}
						sed "/${cmd_user_hash}/d" "${script_path}"/control/accounts.db >"${script_path}/control/${my_pid}_accounts.db"
						mv "${script_path}/control/${my_pid}_accounts.db" "${script_path}/control/accounts.db"

						### GET FINGERPRINT OF PRIVATE KEY #######################
						key_fp=$(gpg --no-default-keyring --keyring="${script_path}"/control/keyring.file --with-colons --list-keys "${user_address}" 2>/dev/null|sed -n 's/^fpr:::::::::\([[:alnum:]]\+\):/\1/p')
						rt_query=$?
						if [ "$rt_query" -eq 0 ]
						then
							### DELETE PRIVATE KEY FROM KEYRING ######################
							gpg --batch --yes --no-default-keyring --keyring="${script_path}"/control/keyring.file --delete-secret-keys "${key_fp}" 2>/dev/null
							rt_query=$?
							if [ "$rt_query" -eq 0 ]
							then
								### DELETE ################################################
								rm "${script_path}/control/keys/${user_address}" 2>/dev/null
								rm "${script_path}/control/keys/${user_address}".sct 2>/dev/null
								rm -R "${script_path}/userdata/${user_address}" 2>/dev/null

								### DELETE SESSION ########################################
								rm "${script_path}/webwallet/sessions/${cmd_session_id}.sid"

								### DISPLAY LANDING PAGE ##################################
								cat "$landing_page"

								### SHOW MESSAGE BOX ######################################
								echo '<script type="text/javascript" language="Javascript">alert("INFO: Your account ${user_address} has been deleted!")</script>'
							fi
						fi
						if [ "$rt_query" -eq 1 ]
						then
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while deleting your account!")</script>'
						fi
					fi
					;;
		"download_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						### PACK TAR FILE #########################################
						{
						echo "keys/${user_address}"
						echo "control/keys/${user_address}"
						echo "control/keys/${user_address}".sct
						echo "proofs/${user_address}"
						echo "userdata/${user_address}"
						ls -1 trx/"${user_address}".* 2>/dev/null
						}>"${script_path}/webwallet/tmp/${user_address}_profile.tmp"
						tar -czf "${script_path}/webwallet/tmp/${user_address}_profile.tar" -T "${script_path}/webwallet/tmp/${user_address}_profile.tmp" 2>/dev/null
						rt_query=$?
						###########################################################
						if [ "$rt_query" -eq 0 ]
						then
							### HANDOVER FILE PATH TO TRIGGER DOWNLOAD ################
							echo "${script_path}/webwallet/tmp/${user_address}_profile.tar"
						fi
						rm "${script_path}/webwallet/tmp/${user_address}_profile.tmp"
					fi
					if [ "$rt_query" -gt 0 ]
					then
						### DISPLAY ERROR MESSAGE #################################
						echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured!")</script>'
					fi
					;;
		"download_sync")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						syncfile=$(echo "-action create_sync -sender ${cmd_sender} -password ${cmd_pw} -type partial"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh|tail -1|cut -d ':' -f2)
						rt_query=$?
						if [ "$rt_query" -eq 0 ]
						then
							### HANDOVER FILE PATH TO TRIGGER DOWNLOAD ################
							echo "${syncfile}"
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating the sync file!")</script>'
						fi
					fi
					;;
		"login_account")	### BUILD STRING TO IDENTIFY USER ##########################
					logger_string=$(echo "${cmd_ip_address}_${cmd_user}"|sha224sum)
					logger_string=${logger_string%% *}

					### GET STAMP FOR SESSION LOGGER FILE EXTENSION ############
					now_stamp=$(date +%s)

					### DELETE ALL LOCKS OF THE USER OLDER THAN ################
					find "${script_path}/webwallet/logger/${logger_string}".* -maxdepth 1 -type f -mmin +"${minutes_to_block}" -delete >/dev/null 2>/dev/null

					### DELETE ALL LOGGER FILES OF THE USER OLDER THAN #########
					find "${script_path}/webwallet/logger/tmp/${logger_string}".* -maxdepth 1 -type f -mmin +"${minutes_to_watch}" -delete >/dev/null 2>/dev/null

					### GET NUMBER OF SESSION LOGGER FILES FOR THIS USER #######
					total_failed_logons=$(ls -1 "${script_path}"/webwallet/logger/tmp|grep -c "${logger_string}")
					if [ "$total_failed_logons" -gt "$max_failed_logons" ]
					then
						touch "${script_path}/webwallet/logger/${logger_string}.${now_stamp}"
						rm "${script_path}/webwallet/logger/tmp/${logger_string}".* 2>/dev/null
					fi

					### CHECK IF USER IS LOCKED ################################
					total_locks=$(find "${script_path}/webwallet/logger/${logger_string}".* -maxdepth 1 -type f 2>/dev/null|wc -l)
					if [ "$total_locks" -eq 0 ]
					then
						### GET ADDRESS ####################################
						get_address
						rt_query=$?
						if [ "$rt_query" -eq 0 ]
						then
							### CREATE SESSION #################################
							create_session
							rt_query=$?
							if [ "$rt_query" -eq 0 ]
							then
								### DELETE LOGGER SESSION FILES ####################
								rm "${script_path}/webwallet/logger/tmp/${logger_string}".* 2>/dev/null

								### BUILD MAIN PAGE ################################
								build_webwallet
							fi
						else
							### WRITE SESSION LOGGER FILE FOR FAILED LOGON #####
							touch "${script_path}/webwallet/logger/tmp/${logger_string}.${now_stamp}"
						fi
						if [ "$rt_query" -eq 1 ]
						then
							### DISPLAY LANDING PAGE AND ERROR MESSAGE #########
							cat "$landing_page"
							echo '<script type="text/javascript" language="Javascript">alert("Wrong logon credentials!")</script>'
						fi
					else
						### DISPLAY LANDING PAGE AND ERROR MESSAGE ################
						cat "$landing_page"
						echo '<script type="text/javascript" language="Javascript">alert("You have entered the wrong logon credentials too many times! Please try again later!")</script>'
					fi
					;;
		"logout_account")	### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						### REMOVE SESSION AND RETURN TO LANDING PAGE #############
						rm "${script_path}/webwallet/sessions/${cmd_session_id}.sid"
						cat "$landing_page"
					fi
					;;
		"read_sync")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action read_sync -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >>/dev/null
						rt_query=$?

						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ "$rt_query" -eq 0 ]
						then
							### DISPLAY SUCCESS MESSAGE ###############################
							echo '<script type="text/javascript" language="Javascript">alert("INFO: File successfully uploaded!")</script>'
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while reading your syncfile!")</script>'
						fi
					fi
					;;
		"read_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action read_trx -sender ${cmd_sender} -password ${cmd_pw} -path ${cmd_path}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >>/dev/null
						rt_query=$?

						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ "$rt_query" -eq 0 ]
						then
							### DISPLAY SUCCESS MESSAGE ###############################
							echo '<script type="text/javascript" language="Javascript">alert("INFO: File successfully uploaded!")</script>'
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while reading your transaction!")</script>'
						fi
					fi
					;;
		"send_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						if [ -e "${cmd_path}" ]
						then
							### STRIP SINGLE QUOTES FROM WALLET.PHP ESCAPESHELLARG ####
							cmd_purpose=$(cat "${cmd_path}"|php -R 'echo urldecode($argn);')

							### WRITE PURPOSE TO FILE AND CONVERT######################
							echo "${cmd_purpose}" >"${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp"
							dos2unix -f "${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp" 2>/dev/null

							### TRIGGER CLIENT ACTION #################################
							echo "-action create_trx -sender ${cmd_sender} -password ${cmd_pw} -asset ${cmd_asset} -amount ${cmd_amount} -receiver ${cmd_receiver} -file ${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >>/dev/null
							rt_query=$?

							### DELETE TMP FILE #######################################
							rm "${script_path}/webwallet/tmp/decoded_purpose_${my_pid}.tmp"

							### BUILD MAIN PAGE #######################################
							build_webwallet
							if [ "$rt_query" -eq 0 ]
							then
								### DISPLAY SUCCESS MESSAGE ###############################
								echo '<script type="text/javascript" language="Javascript">alert("INFO: Transaction was sent!")</script>'
							else
								### DISPLAY ERROR MESSAGE #################################
								echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your transaction!")</script>'
							fi
						else
							### BUILD MAIN PAGE #######################################
							build_webwallet
							
							### DISPLAY ERROR MESSAGE ################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while creating your transaction!")</script>'
						fi
					fi
					;;
		"show_trx")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						purpose_key=""
						user_path="${script_path}/userdata/${user_address}"
						purpose_key_start=$(awk -F: '/:PRPK:/{print NR}' "${script_path}/trx/${cmd_path}")
						purpose_key_start=$(( purpose_key_start + 1 ))
						purpose_key_end=$(awk -F: '/:PRPS:/{print NR}' "${script_path}/trx/${cmd_path}")
						purpose_key_end=$(( purpose_key_end - 1 ))
						purpose_key_encrypted=$(sed -n "${purpose_key_start},${purpose_key_end}p" "${script_path}/trx/${cmd_path}")
						printf "%b" "-----BEGIN PGP MESSAGE-----\n\n${purpose_key_encrypted}\n-----END PGP MESSAGE-----\n"  >"${user_path}"/history_purpose_key_encrypted.tmp
						echo "${cmd_pw}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${user_path}"/history_purpose_key_decrypted.tmp --decrypt "${user_path}"/history_purpose_key_encrypted.tmp 2>/dev/null
						rt_query=$?
						if [ "$rt_query" -eq 0 ]
						then
							sender=${cmd_path%%.*}
							stamp=${cmd_path#*.}
							stamp=$(date --date=@"${stamp}")
							amount=$(awk -F: '/:AMNT:/{print $3}' "${script_path}/trx/${cmd_path}")
							purpose=""
							purpose_key=$(cat "${user_path}"/history_purpose_key_decrypted.tmp)
							purpose_start=$(awk -F: '/:PRPS:/{print NR}' "${script_path}/trx/${cmd_path}")
							purpose_start=$(( purpose_start + 1 ))
							purpose_end=$(awk -F: '/BEGIN PGP SIGNATURE/{print NR}' "${script_path}/trx/${cmd_path}")
							purpose_end=$(( purpose_end - 1 ))
							purpose_encrypted=$(sed -n "${purpose_start},${purpose_end}p" "${script_path}/trx/${cmd_path}")
							printf "%b" "-----BEGIN PGP MESSAGE-----\n\n${purpose_encrypted}\n-----END PGP MESSAGE-----\n" >"${user_path}"/history_purpose_encrypted.tmp
							echo "${purpose_key}"|gpg --batch --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --passphrase-fd 0 --pinentry-mode loopback --output "${user_path}"/history_purpose_decrypted.tmp --decrypt "${user_path}"/history_purpose_encrypted.tmp 2>/dev/null
							rt_query=$?
							if [ "$rt_query" -eq 0 ]
							then
								is_text=$(file "${user_path}"/history_purpose_decrypted.tmp|grep -c -v "text")
								if [ "$is_text" -eq 0 ]
								then
									### ENCODE PURPOSE BECAUSE OF SPECIAL CHARACTERS ##########
									purpose=$(printf "%s" "$(cat -E "${user_path}"/history_purpose_decrypted.tmp|sed 's/\$\$*$/\\n/g'|php -R 'echo htmlentities($argn);')")

									### PRINT TRANSACTION CONTENT AS POPUP#####################
									popup="<script type=\"text/javascript\" language=\"Javascript\"> var myWindow = window.open(\"\", \"MsgWindow\", \"toolbar=yes,scrollbars=yes,resizable=yes\"); myWindow.document.write(\"<h3>Timestamp:<br>${stamp}<br><br>Amount:<br>+${amount}<br><br>Sender:<br>${sender}<br><br>File:<br>${cmd_path}<br><br>Purpose:<br></h3><pre>${purpose}</pre>\");</script>"
									printf "%s" "${popup}"
								else
									### DISPLAY ERROR MESSAGE #################################
									echo '<script type="text/javascript" language="Javascript">alert("NOTE: The purpose cannot be displayed, because it is not in text format.")</script>'
								fi

								### BUILD MAIN PAGE #######################################
								build_webwallet
							else
								### DISPLAY ERROR MESSAGE #################################
								echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while decrypting the transaction purpose!")</script>'
							fi
							rm "${user_path}"/history_purpose_encrypted.tmp 2>/dev/null
							rm "${user_path}"/history_purpose_decrypted.tmp 2>/dev/null
						else
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while decrypting the transaction purpose!")</script>'
						fi
						rm "${user_path}"/history_purpose_key_encrypted.tmp 2>/dev/null
						rm "${user_path}"/history_purpose_key_decrypted.tmp 2>/dev/null
					fi
					;;
		"sync_uca")		### CHECK IF SESSION IS ACTIVE ############################
					check_session
					rt_query=$?
					if [ "$rt_query" -eq 0 ]
					then
						### TRIGGER CLIENT ACTION #################################
						echo "-action sync_uca -sender ${cmd_sender} -password ${cmd_pw}"|flock "${script_path}/userdata/${cmd_sender}" ./ucs_client.sh >>/dev/null
						rt_query=$?

						### BUILD MAIN PAGE #######################################
						build_webwallet
						if [ "$rt_query" -gt 0 ]
						then
							### DISPLAY ERROR MESSAGE #################################
							echo '<script type="text/javascript" language="Javascript">alert("ERROR: An error has occured while performing syncronization!")</script>'
						fi
					fi
					;;
	esac

	### AUTO LOGOFF ################################################################################
	find "${script_path}"/webwallet/sessions/ -maxdepth 1 -type f -mmin +"${minutes_logoff}" -delete >/dev/null 2>/dev/null

	### DO HOUSEKEEPING AND DELETE ALL TMP SESSION FILES OLDER THAN 5 MINUTES ######################
	find "${script_path}"/webwallet/tmp/ -maxdepth 1 -type f -mmin +"${minutes_housekeeping}" -delete >/dev/null 2>/dev/null
else
	### DISPLAY HELP OVERVIEW MESSAGE ##############################################################
	echo "ERROR! TRY THIS:"
	echo "./webwallet.sh -help"
	exit 1
fi
