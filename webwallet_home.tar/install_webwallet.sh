#!/bin/sh

### ASSIGN VARIABLES ########################
wwwpath=$1
specific_env=$2

### GET SCRIPT PATH #########################
script_path=$(dirname $(readlink -f "${0}"))

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

### SET VARIABLES ############
error_detected=0

###CHECK DEPENDENCIES#######
while read line
do
	###CHECK IF PROGRAMM IS UNKNOWN####
        type "$line" >/dev/null
        rt_query=$?
        if [ $rt_query -gt 0 ]
        then
                echo "$line" >>"${script_path}"/webwallet_install_dep.tmp
        fi
done <"${script_path}"/control/webwallet_install.dep
if [ -f ${script_path}/webwallet_install_dep.tmp ] && [ -s ${script_path}/webwallet_install_dep.tmp ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case $specific_env in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				if [ -x "$(command -v apk)" ]
				then
					pkg_mngr="apk";
				else
					if [ -x "$(command -v apt-get)" ]
					then
						pkg_mngr="apt-get";
					else
						if [ -x "$(command -v dnf)" ]
						then
							pkg_mngr="dnf";
						else
							if [ -x "$(command -v pacman)" ]
							then
								pkg_mngr="pacman";
							else
								if [ -x "$(command -v pkg)" ]
								then
									pkg_mngr="pkg";
								else
									if [ -x "$(command -v yum)" ]
									then
										pkg_mngr="yum";
									else
										if [ -x "$(command -v zypper)" ]
										then
											pkg_mngr="zypper";
										else
											###IF PACKAGING MANAGER DETECTION FAILED####
											error_detected=1
											no_of_programs=$(wc -l <${script_path}/webwallet_install_dep.tmp)
											echo "ERROR: Couldn't detect the package management system used on this machine!"
											echo "Found ${no_of_programs} programs that need to be installed:"
											cat ${script_path}/webwallet_install_dep.tmp
											echo "Install these programms first using your package management system and then run install.sh again."
											############################################
										fi
									fi
								fi
							fi
						fi
					fi
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ $error_detected = 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read line
		do
			printf "%b" "INFO: Trying to install ${line} using ${pkg_mngr}...\n"
			case $pkg_mngr in
				"apk")		apk add $line ;;
				"apt-get")	apt-get -y install $line ;;
				"dnf")		dnf -y install $line ;;
				"pacman")	pacman --noconfirm -S $line ;;
				"pkg")		pkg install -y $line ;;
				"yum")		yum -y install $line ;;
				"zypper")	zypper -n install $line ;;
			esac
			rt_query=$?
			if [ ! $rt_query = 0 ]
			then
				error_detected=1
				echo "Error running the following command: ${pkg_mngr} install ${line}"
				echo "Maybe the program ${line} is available in a package with different name."
			fi
		done <${script_path}/webwallet_install_dep.tmp
		############################
	fi
fi
###REMOVE TMP FILE##########
rm ${script_path}/webwallet_install_dep.tmp 2>/dev/null
if [ $error_detected = 0 ]
then
	### CHECK IF DIRECTORY-VARIABLE EMPTY #######
	if [ -n "${wwwpath}" ]
	then
		### CHECK IF DIRECTROY EXISTS ###############
		if [ -d "${wwwpath}" ]
		then
			rt_query=0
			### WRITE PATH TO SCRIPTS ###################
			printf "%b" "INFO: Write wallet install path to "${wwwpath}"/wallet.php..."
			sed -i "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" "${wwwpath}"/wallet.php || rt_query=1
			if [ $rt_query = 0 ]
			then
				printf "%b" "DONE\n"
			else
				printf "%b" "FAILED\n"
			fi
			rt_query=0
			printf "%b" "INFO: Write wallet install path to "${wwwpath}"/control/webwallet.conf..."
			sed -i "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" "${script_path}"/control/webwallet.conf || rt_query=1
			if [ $rt_query = 0 ]
			then
				printf "%b" "DONE\n"
			else
				printf "%b" "FAILED\n"
			fi
			#############################################
			### TARGET ENVIRONMENT SPECIFIC TASKS #######
			#############################################

			### TERMUX ##################################
			is_termux=$(echo "${specific_env}"|grep -c "termux")
			if [ "${is_termux}" = 1 ]
			then
				termux-fix-shebang "${script_path}"/ucs_client.sh "${script_path}"/webwallet.sh
			fi
			#############################################
		else
			### WRITE ERROR MESSAGE #####################
			echo "ERROR: the folder $wwwpath does not exist!"
		fi
	else
		### WRITE HELP MESSAGE ######################
		echo "ERROR:    You have to handover the path to www! See below example:"
		echo "          ./install_webwallet.sh /var/www/html"
	fi
	printf "%b" "INFO: Installation finished\n"
fi
