#!/bin/sh

### ASSIGN VARIABLES ########################
wwwpath=$1
targetenv=$2

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

### CHECK IF DIRECTORY-VARIABLE EMPTY #######
if [ ! "${wwwpath}" = "" ]
then
	### CHECK IF DIRECTROY EXISTS ###############
	if [ -d $wwwpath ]
	then
		### WRITE PATH TO SCRIPTS ###################
		script_path=$(dirname $(readlink -f ${0}))
		sed -i "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" ${wwwpath}/wallet.php
		sed -i "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" ${script_path}/webwallet.sh

		#############################################
		### TARGET ENVIRONMENT SPECIFIC TASKS #######
		#############################################

		### TERMUX ##################################
		is_termux=$(echo "${targetenv}"|grep -c "termux")
		if [ $is_termux = 1 ]
		then
			termux-fix-shebang ${script_path}/ucs_client.sh ${script_path}/webwallet.sh
		fi
		#############################################
	else
		### WRITE ERROR MESSAGE #####################
		echo "ERROR: the folder $wwwpath does not exist!"
	fi
else
	### WRITE HELP MESSAGE ######################
	echo "ERROR:    You have to handover the path to www! See below example:"
	echo "          ./install_webwallet.sh /var/www/html"
fi
