#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
print_message(){
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%s\n" "DONE"
		else
			printf "%s\n" "FAILED"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}

### ASSIGN VARIABLES ########################
wwwpath=$1
specific_env=$2
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "${0}")
my_pid=$$
error_counter=0

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

### CREATE TMP ##############
add_trap_command '[ -n "${install_dep:-}" ] && rm -f -- "${install_dep}"'
install_dep=$(mktemp "${script_path}/tmp/install_webwallet_dep.XXXXXX") || exit 1

###CHECK DEPENDENCIES#######
while read program
do
	###CHECK IF PROGRAMM IS UNKNOWN####
        type "${program}" >/dev/null
        rt_query=$?
        if [ "${rt_query}" -gt 0 ]
        then
                echo "${program}" >>"${install_dep}"
        fi
done <"${script_path}"/control/webwallet_install.dep
if [ -f "${install_dep}" ] && [ -s "${install_dep}" ]
then
	############################
	###IF APPS ARE TO INSTALL###
	###GET PACKAGE MANAGER######
	case "${specific_env}" in
		"termux")	pkg_mngr="pkg"
				;;
		*)		pkg_mngr=""
				for pmgr in apk apt-get dnf pacman pkg yum zipper
				do
					if [ -x "$(command -v "${pmgr}")" ]
					then
						pkg_mngr="${pmgr}";
					fi
				done
				if [ -z "${pkg_mngr}" ]
				then
					###IF PACKAGING MANAGER DETECTION FAILED####
					error_counter=1
					no_of_programs=$(wc -l <"${script_path}"/webwallet_install_dep.tmp)
					printf "%s\n" "[ ERROR ][package] Couldn't detect the package management system used on this machine!"
					printf "%s\n" "[ ERROR ][package] Found ${no_of_programs} programs that need to be installed:"
					awk '{print "[ ERROR ][package] -> " $1}' "${script_path}"/webwallet_install_dep.tmp
					printf "%s\n" "[ ERROR ][package] Install these programms first using your package management system and then run ${script_name} again."
					############################################
				fi
				;;
	esac
	############################
	
	if [ -n "${pkg_mngr}" ] && [ "${error_counter}" -eq 0 ]
	then
		### INSTALL MISSING PKGS #####
		while read program
		do
			printf "%s\n" "[ INFO ] Trying to install ${program} using ${pkg_mngr}..."
			case "${pkg_mngr}" in
				"apk")		apk add "${program}" ;;
				"apt-get")	apt-get -y install "${program}" ;;
				"dnf")		dnf -y install "${program}" ;;
				"pacman")	pacman --noconfirm -S "${program}" ;;
				"pkg")		pkg install -y "${program}" ;;
				"yum")		yum -y install "${program}" ;;
				"zypper")	zypper -n install "${program}" ;;
			esac
			rt_query=$?
			if [ "${rt_query}" -gt 0 ]
			then
				printf "%s\n" "[ ERROR ] Error running the following command: ${pkg_mngr} install ${program}"
				printf "%s\n" "[ ERROR ] Maybe the program ${program} is available in a package with different name."
				error_counter=$(( error_counter + 1 ))
			fi
		done <"${install_dep}"
		############################
	fi
fi
if [ "${error_counter}" -eq 0 ]
then
	### CHECK IF DIRECTORY-VARIABLE EMPTY #######
	if [ -n "${wwwpath}" ]
	then
		### CHECK IF DIRECTROY EXISTS ###############
		if [ -d "${wwwpath}" ]
		then
			rt_query=0
			### WRITE PATH TO SCRIPTS ###################
			printf "%s" "[ INFO ] Write wallet install path to ${wwwpath}/wallet.php..."
			sed "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" "${wwwpath}"/wallet.php >"${wwwpath}"/wallet.php."${my_pid}".bak && mv -- "${wwwpath}"/wallet.php."${my_pid}".bak "${wwwpath}"/wallet.php || rt_query=1
			print_message "${rt_query}"
			
			printf "%s" "[ INFO ] Write wallet install path to ${wwwpath}/control/webwallet.conf..."
			sed "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" "${script_path}"/control/webwallet.conf >"${script_path}"/control/webwallet.conf."${my_pid}".bak && mv -- "${script_path}"/control/webwallet.conf."${my_pid}".bak "${script_path}"/control/webwallet.conf || rt_query=1
			print_message "${rt_query}"
			
			#############################################
			### TARGET ENVIRONMENT SPECIFIC TASKS #######
			#############################################

			### TERMUX ##################################
			is_termux=$(echo "${specific_env}"|grep -c "termux")
			if [ "${is_termux}" -eq 1 ]
			then
				printf "%s" "[ INFO ] Run termux-fix-shebang..."
				termux-fix-shebang "${script_path}"/ucs_client.sh "${script_path}"/webwallet.sh
				print_message "${rt_query}"
			fi
			#############################################
		else
			### WRITE ERROR MESSAGE #####################
			printf "%s\n" "[ ERROR ] Folder $wwwpath does not exist!"
			error_counter=1
		fi
	else
		### WRITE HELP MESSAGE ######################
		printf "%s\n" "[ ERROR ] You have to handover the path to www root: ./install_webwallet.sh /var/www/html"
		error_counter=1
	fi
fi
printf "%s\n" "[ INFO ] ${script_name} finished (errors:${error_counter})"
