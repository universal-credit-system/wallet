#!/bin/sh
wwwpath=$1
if [ ! "${wwwpath}" = "" ]
then
	if [ -d $wwwpath ]
	then
		script_path=`dirname $(readlink -f ${0})`
		sed -i "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" ${wwwpath}/wallet.php
		sed -i "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" ${script_path}/webwallet.sh
	else
		echo "ERROR: the folder $wwwpath does not exist!"
	fi
else
	echo "ERROR:    You have to handover the path to www! See below example:"
	echo "          ./install_webwallet.sh /var/www/html"
fi
