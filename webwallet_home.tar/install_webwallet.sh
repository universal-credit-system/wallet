#!/bin/sh

### ASSIGN VARIABLES ########################
wwwpath=$1
targetenv=$2

### GET SCRIPT PATH #########################
script_path=$(dirname $(readlink -f ${0}))

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

###CHECK DEPENDENCIES#######
while read line
do
	###CHECK IF PROGRAMM IS UNKNOWN####
        type $line >/dev/null
        rt_query=$?
        if [ $rt_query -gt 0 ]
        then
                echo $line >>${script_path}/install_webwallet_dep.tmp
        fi
done <${script_path}/control/install_webwallet.dep
if [ ! -s ${script_path}/install_webwallet_dep.tmp ]
then
	### CHECK IF DIRECTORY-VARIABLE EMPTY #######
	if [ ! "${wwwpath}" = "" ]
	then
		### CHECK IF DIRECTROY EXISTS ###############
		if [ -d $wwwpath ]
		then
			### WRITE PATH TO SCRIPTS ###################
			script_path=$(dirname $(readlink -f ${0}))
			sed -i "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" ${wwwpath}/wallet.php
			sed -i "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" ${script_path}/webwallet.sh

			#############################################
			### TARGET ENVIRONMENT SPECIFIC TASKS #######
			#############################################

			### TERMUX ##################################
			is_termux=$(echo "${targetenv}"|grep -c "termux")
			if [ $is_termux = 1 ]
			then
				termux-fix-shebang ${script_path}/ucs_client.sh ${script_path}/webwallet.sh
			fi
			#############################################
		else
			### WRITE ERROR MESSAGE #####################
			echo "ERROR: the folder $wwwpath does not exist!"
		fi
	else
		### WRITE HELP MESSAGE ######################
		echo "ERROR:    You have to handover the path to www! See below example:"
		echo "          ./install_webwallet.sh /var/www/html"
	fi
else
	###DISPLAY APPS TO INSTALL##
	no_of_programs=$(wc -l <${script_path}/install_webwallet_dep.tmp)
        echo "Found ${no_of_programs} program(s) that need to be installed:"
        cat ${script_path}/install_webwallet_dep.tmp
	echo "Install these programms first, then run install_webwallet.sh again."

	###REMOVE TMP FILE##########
        rm ${script_path}/install_webwallet_dep.tmp
fi
