#!/bin/sh

### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

### LIST ALL EXISTING IMAGES #########################
image_id=$(docker images|grep "ucs_client"|awk '{print $3}'|head -1)

### LAUNCH ###########################################
docker run -v ucs_client:/var/ucs/wallet -it ${image_id} sh

