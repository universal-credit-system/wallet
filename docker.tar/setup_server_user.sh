#!/bin/sh
script_path=$(dirname $(readlink -f "${0}"))
cd ${script_path}/ || exit 1
if [ ! -s ${script_path}/control/server_user.txt ] && [ ! -f ${script_path}/control/server_user.txt ]
then
	./ucs_client.sh -action create_user >${script_path}/control/server_user.txt
fi

