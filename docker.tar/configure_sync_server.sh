#!/bin/sh -xv

### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

###CHECK FOR STDIN INPUT####
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi

###ASSIGN VARIABLES###
if [ $# -gt 0 ]
then
	cmd_var=""
	cmd_ip=""
	cmd_sender_port=""
	cmd_receiver_port=""

	###GO THROUGH PARAMETERS ONE BY ONE############################
	while [ $# -gt 0 ]
	do
		###GET TARGET VARIABLES########################################
		case $1 in
			"-ip")			cmd_var=$1
						;;
			"-sender_port")		cmd_var=$1
						;;
			"-receiver_port")	cmd_var=$1
						;;
			*)			###SET TARGET VARIABLES########################################
						case $cmd_var in
							"-ip")			cmd_ip=$1
										;;
							"-sender_port")		cmd_sender_port=$1
										;;
							"-receiver_port")	cmd_receiver_port=$1
										;;
							*)			echo "ERROR! SYNTAX:"
										echo "./configure_sync.sh -ip IP_ADDRESS [-sender_port PORT] [-receiver_port PORT]"
										exit 1
										;;
						esac
						cmd_var=""
						;;
		esac
		shift
	done
fi

### CHECK IF CMD_IP NOT EMPTY AND USER EXIST #########
if [ -n "${cmd_ip}" ] && [ -s ${script_path}/control/server_user.txt ] && [ -f ${script_path}/control/server_user.txt ]
then
	### EXTRACT ADDRESS AND PASSWORD ######################
	cmd_address=$(grep "ADDRESS" ${script_path}/control/server_user.txt|cut -d ':' -f2)
	cmd_password=$(grep "PASSWORD" ${script_path}/control/server_user.txt|cut -d '>' -f2|cut -d '<' -f1)
	rt_query=0
	
	### WRITE ADDRESS TO SERVER.CONF ######################
	sed -i "s/user_account=\"\"/user_account=\"${cmd_address}\"/g" ${script_path}/control/server.conf || rt_query=1
	if [ $rt_query = 0 ]
	then
		### WRITE PASSWORD TO SERVER.CONF #####################
		sed -i "s/user_pw=\"\"/user_pw=\"${cmd_password}\"/g" ${script_path}/control/server.conf || rt_query=1
		if [ $rt_query = 0 ]
		then
			### WRITE IP ADDRESS TO SERVER.CONF ###################
			sed -i "s/bind_ip_address=\"127.0.0.1\"/bind_ip_address=\"${cmd_ip}\"/g" ${script_path}/control/server.conf || rt_query=1
			if [ $rt_query = 0 ]
			then
				if [ -n "${cmd_sender_port}" ]
				then
					### WRITE SENDER PORT TO SERVER.CONF ##########
					sed -i "s/sender_port=\"15000\"/sender_port=\"${cmd_sender_port}\"/g" ${script_path}/control/server.conf || rt_query=1
					if [ ! $rt_query = 0 ]
					then
						entity='$sender_port'
					fi
				fi
				if [ -n "${cmd_receiver_port}" ] && [ $rt_query = 0 ]
				then
					### WRITE RECEIVER PORT TO SERVER.CONF ########
					sed -i "s/receiver_port=\"15001\"/receiver_port=\"${cmd_sender_port}\"/g" ${script_path}/control/server.conf || rt_query=1
					if [ ! $rt_query = 0 ]
					then
						entity='$receiver_port'
					fi
				fi
			else
				entity='$bind_ip_address'
			fi
		else
			entity='$user_pw'
		fi
	else
		entity='$user_account'
	fi
	if [ ! $rt_query = 0 ]
	then
		echo "ERROR: Error writing $entity to file control/server.conf"
	else
		echo "INFO: Server configured"
	fi
fi

