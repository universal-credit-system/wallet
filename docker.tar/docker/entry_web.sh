#!/bin/sh
script_path=$(cd "$(dirname "$0")" && pwd)
"${script_path}"/php_init.sh
su ucs_node -c "${script_path}"/gpg_init.sh
nginx
while [ $# -gt 0 ]
do
	$1
	shift
done

