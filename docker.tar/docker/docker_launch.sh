#!/bin/sh
volume_exists(){
		volume_name=$1
		exists=$(docker volume ls|grep -c "${volume_name}")
		return $exists
}
### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

### DISPLAY LIST OF DOCKERFILES ######################
number=$(docker images -q ucs_client|wc -l)
echo "Found  ${number}  images of ucs_client"
if [ "$number" -gt 0 ]
then
	### WRITE SELECTION ##################################
	docker images -q ucs_client|awk '{print NR" "$1" "$2" "$3" "$4" "$5" "$6}'

	### PROMPT USER ######################################
	printf "%b" "Please select a number (1-$number) : "
	read selection
	if [ "$selection" -ge 1 ] && [ "$selection" -le "$number" ]
	then
		### EXTRACT IMAGE HASH ###############################
		image_id=$(docker images -q ucs_client|head -$selection|tail -1)

		### START CONTAINER ##################################
		docker run -v ucs_client:/home/ucs_node/ -it ${image_id}
	else
		echo "No number selected"
		exit 1
	fi
fi

