#!/bin/sh

### SET SCRIPT PATH ##################################
script_path="/var/ucs/wallet/"

### STEP INTO SCRIPT PATH ############################
cd ${script_path}/ || exit 1

### CHECK IF A USER EXISTS ###########################
rt_query=0
if [ ! -s ${script_path}/control/server_user.txt ] && [ ! -f ${script_path}/control/server_user.txt ]
then
	### IF NOT CREATE ONE ################################
	${script_path}/ucs_client.sh -action create_user >${script_path}/control/server_user.txt
	rt_query=$?
fi
if [ $rt_query = 0 ]
then
	### EXTRACT ADDRESS AND PASSWORD ######################
	cmd_address=$(grep "ADDRESS" ${script_path}/control/server_user.txt|cut -d ':' -f2)
	cmd_password=$(grep "PASSWORD" ${script_path}/control/server_user.txt|cut -d '>' -f2|cut -d '<' -f1)
	rt_query=0

	### WRITE ADDRESS TO SERVER.CONF ######################
	sed -i "s/user_account=\"\"/user_account=\"${cmd_address}\"/g" ${script_path}/control/server.conf || rt_query=1
	if [ $rt_query = 0 ]
	then
		### WRITE PASSWORD TO SERVER.CONF #####################
		sed -i "s/user_pw=\"\"/user_pw=\"${cmd_password}\"/g" ${script_path}/control/server.conf || rt_query=1
		if [ ! $rt_query = 0 ]
		then
			entity='$user_account'
		fi
	else
		entity='$user_pw'
	fi
	if [ ! $rt_query = 0 ]
	then
		echo "ERROR: Error writing $entity to file control/server.conf"
	else
		echo "INFO: Server user configured"
	fi
fi
exit $rt_query
