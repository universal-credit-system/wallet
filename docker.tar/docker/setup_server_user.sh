#!/bin/sh
print_message(){
		if [ "$rt_query" -eq 0 ]
		then
			printf "%b" "DONE\n"
		else
			printf "%b" "FAILED\n"
			error_detected=1
		fi
		rt_query=0
}
### SET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))
error_detected=0

### STEP INTO SCRIPT PATH ############################
cd ${script_path}/ || exit 1

### CHECK IF A USER EXISTS ###########################
rt_query=0
if [ ! -s "${script_path}"/control/server_user.txt ] && [ ! -f "${script_path}"/control/server_user.txt ]
then
	### DISPLAY OUTPUT ###################################
	printf "%b" "[ INFO ] $(date -u): Create server user..."

	### IF NOT CREATE ONE ################################
	"${script_path}"/ucs_client.sh -action create_user >"${script_path}"/control/server_user.txt 2>/dev/null
	rt_query=$?
else
	### DISPLAY OUTPUT ###################################
	printf "%b" "[ INFO ] $(date -u): Found server user..."
fi
print_message "$rt_query"
if [ "$rt_query" -eq 0 ]
then
	### EXTRACT ADDRESS AND PASSWORD ######################
	printf "%b" "[ INFO ] $(date -u): Extract user credentials from control/server_user.txt..."
	cmd_address=$(grep "ADDRESS" "${script_path}"/control/server_user.txt|cut -d ':' -f2) || rt_query=1
	cmd_password=$(grep "PASSWORD" "${script_path}"/control/server_user.txt|cut -d '>' -f2|cut -d '<' -f1) || rt_query=1
	print_message "$rt_query"

	### WRITE ADDRESS TO SERVER.CONF ######################
	printf "%b" "[ INFO ] $(date -u): Write user credentials to control/server.conf..."
	sed -i "s/user_account=\"\"/user_account=\"${cmd_address}\"/g" "${script_path}"/control/server.conf || rt_query=1
	if [ "$rt_query" -eq 0 ]
	then
		### WRITE PASSWORD TO SERVER.CONF #####################
		sed -i "s/user_pw=\"\"/user_pw=\"${cmd_password}\"/g" "${script_path}"/control/server.conf || rt_query=1
	fi

	### DISPLAY OUTPUT ###################################
	print_message "$rt_query"
fi

### DISPLAY OUTPUT ##########
error_text="with errors"
if [ "$error_detected" -eq 0 ]
then
	error_text="without errors"
fi
printf "%b" "[ INFO ] setup_server_user.sh finished $error_text. exiting...\n"

exit $rt_query
