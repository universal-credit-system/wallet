#!/bin/sh
add_trap_command(){
		    	command_to_add="$1"
			if [ -n "${command_to_add:-}" ]
			then
				if [ -z "${current_trap:-}" ]
			    	then
			    		### IF EMPTY SET TRAP #########################
			    		current_trap=${command_to_add}
			    		trap "${command_to_add}" EXIT
			    	else
			    		### IF NOT EMPTY APPEND #######################
					trap "${current_trap}; ${command_to_add}" EXIT
					current_trap="${current_trap}; ${command_to_add}"
				fi
			fi
}
print_message(){
		if [ "$rt_query" -eq 0 ]
		then
			printf "%s\n" "DONE"
		else
			printf "%s\n" "FAILED"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}
### SET SCRIPT PATH ##################################
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")
error_counter=0

### STEP INTO SCRIPT PATH ############################
cd "${script_path}" || exit 1

### CHECK IF A USER EXISTS ###########################
rt_query=0
if [ ! -s "${script_path}"/control/server_user.txt ] && [ ! -f "${script_path}"/control/server_user.txt ]
then
	### DISPLAY OUTPUT ###################################
	printf "%s\n" "[${script_name}][INFO] $(date -u): Create server user..."

	### IF NOT CREATE ONE ################################
	"${script_path}"/ucs_client.sh -action create_user >"${script_path}"/control/server_user.txt 2>/dev/null || rt_query=1
else
	### DISPLAY OUTPUT ###################################
	printf "%s\n" "[${script_name}][INFO] $(date -u): Found existing server user..."
fi
### DISPLAY STATUS ###################################
print_message
if [ "$rt_query" -eq 0 ]
then
	### EXTRACT ADDRESS AND PASSWORD #####################
	printf "%s\n" "[${script_name}][INFO] $(date -u): Load credentials..."
	cmd_address=$(grep -F -- "ADDRESS" "${script_path}"/control/server_user.txt|cut -d ':' -f2) || rt_query=1
	cmd_password=$(grep -F -- "PASSWORD" "${script_path}"/control/server_user.txt|cut -d '>' -f2|cut -d '<' -f1) || rt_query=1
	print_message

	### CREATE TMP ##############
	add_trap_command '[ -n "${config_tmp:-}" ] && rm -f -- "${config_tmp}"'
	config_tmp=$(mktemp "${script_path}/tmp/server_config_tmp.XXXXXX") || printf "%s\n" "[${script_name}][ERROR] $(date -u): Could not create temp file (path ->\"${script_path}/tmp\"). Aborting..." && exit 1

	### WRITE ADDRESS TO SERVER.CONF ######################
	printf "%s\n" "[${script_name}][INFO] $(date -u): Configure control/server.conf..."
	sed "s/user_account=\"\"/user_account=\"${cmd_address}\"/g" "${script_path}"/control/server.conf >"${config_tmp}" && mv "${config_tmp}" "${script_path}"/control/server.conf || rt_query=1
	if [ "${rt_query}" -eq 0 ]
	then
		### WRITE PASSWORD TO SERVER.CONF #####################
		sed "s/user_pw=\"\"/user_pw=\"${cmd_password}\"/g" "${script_path}"/control/server.conf >"${config_tmp}" && mv "${config_tmp}" "${script_path}"/control/server.conf || rt_query=1
	fi

	### DISPLAY OUTPUT ###################################
	print_message
fi

### DISPLAY OUTPUT ##########
printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})"
exit ${rt_query}
