#!/bin/sh

### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

### TOuCH TMP FILE ###################################
grep "" /dev/null >"${script_path}/docker_access.tmp"

### GET TOTAL NUMBER OF CONTAINERS ###################
number=0
for each_image in $(docker images -q ucs_client)
do
	number_containers=$(docker container ls|grep "$each_image"|wc -l)
	number=$(( number + number_containers ))
done

### DISPLAY NUMBER ###################################
echo "Found  ${number}  containers running ucs_client"

### GET TOTAL LIST OF CONTAINERS #####################
for each_image in $(docker images -q ucs_client)
do
	### WRITE SELECTION ##################################
	docker container ls|grep "$each_image"|awk '{print NR" "$1" "$2" "$3" "$4" "$5" "$6}' >>"${script_path}/docker_access.tmp"
done

### IF ANY CONTAINER IS RUNNING ######################
if [ "$number" -gt 0 ]
then
	### DISPLAY LIST OF CONTAINERS #######################
	cat "${script_path}/docker_access.tmp"

	### PROMPT USER ######################################
	printf "%b" "Please select a number (1-$number) : "
	read selection
	if [ "$selection" -ge 1 ] && [ "$selection" -le "$number" ]
	then
		### EXTRACT IMAGE HASH ###############################
		container_id=$(head -$selection "${script_path}/docker_access.tmp"|tail -1|awk '{print $2}')

		### RUN DOCKER CONTAINER #############################
		echo "Access container ${container_id}..."
		docker exec -it ${container_id} sh
	else
		echo "No number selected"
		rm "${script_path}/docker_access.tmp" 2>/dev/null
		exit 1
	fi
fi

### REMOVE TMP FILE ##################################
rm "${script_path}/docker_access.tmp" 2>/dev/null
