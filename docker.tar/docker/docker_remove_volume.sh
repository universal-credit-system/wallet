#!/bin/sh

### HANDOVER STORAGE #################################
storage=$1

### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

### REMOVE PERSISTENT STORAGE ########################
if [ -z "${storage}" ]
then
	storage="ucs_client"
fi
echo "Remove volume $storage..."
docker volume rm $storage >/dev/null
rt_query=$?
if [ "$rt_query" -eq 0 ]
then
	echo "Volume $storage successfully removed!"
else
	echo "Error removing persistent storage $storage ! Aborting..."
	exit 1
fi
