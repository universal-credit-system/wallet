#!/bin/sh

### HANDOVER STORAGE #################################
storage=$1

### GET SCRIPT PATH ##################################
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "$0")

### REMOVE PERSISTENT STORAGE ########################
if [ -z "${storage}" ]
then
	storage="ucs_client"
fi
printf "%s\n" "[${script_name}][INFO] Trying to remove volume ${storage}..."
docker volume rm "${storage}" >/dev/null
rt_query=$?
if [ "${rt_query}" -eq 0 ]
then
	printf "%s\n" "[${script_name}][INFO] Volume ${storage} successfully removed!"
else
	printf "%s\n" "[${script_name}][ERROR] Error removing persistent storage ${storage} (rt:${rt_query})! Aborting..."
	exit 1
fi
