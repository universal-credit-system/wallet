#!/bin/sh

### GET SCRIPT PATH ##################################
script_path=$(cd "$(dirname "$0")" && pwd)

### GET VOLUME #######################################
volume=$1
if [ -z "${volume}" ]
then
	volume="ucs_client"
fi

### GET BUSYBOX ######################################
docker image pull busybox 

### READ VOLUME ######################################
stamp=$(date +%s)
docker run --rm -v "${volume}":/home/ucs_node busybox sh -c 'tar -cOzf - /home/ucs_node' > "${script_path}/volume_export_$stamp.tgz"
rt_query=$?
if [ ${rt_query} -eq 0 ]
then
	printf "%s\n" "Volume ${volume} successfully written to file ( -> ${script_path}/volume_export_${stamp}.tgz )"
else
	printf "%s\n" "Error creating tar file..."
	exit 1
fi

