#!/bin/sh

### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

### GET VOLUME #######################################
volume=$1
if [ -z "${volume}" ]
then
	volume="ucs_client"
fi

### GET BUSYBOX ######################################
docker image pull busybox 

### READ VOLUME ######################################
stamp=$(date +%s)
docker run --rm -v ${volume}:/home/ucs_node busybox sh -c 'tar -cOzf - /home/ucs_node' > "${script_path}"/volume_export_$stamp.tgz
rt_query=$?
if [ $rt_query = 0 ]
then
	echo "Volume $volume successfully written to file ( -> ${script_path}/volume_export_$stamp.tgz )"
else
	echo "Error creating tar file..."
	exit 1
fi

