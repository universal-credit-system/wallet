#!/bin/sh
/var/ucs/wallet/php_init.sh
su ucs_node -c /var/ucs/wallet/gpg_init.sh
su ucs_node -c /var/ucs/wallet/setup_server_user.sh
exec "$@"
