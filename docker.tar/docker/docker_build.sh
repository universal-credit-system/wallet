#!/bin/sh
volume_exists(){
		volume_name=$1
		exists=$(docker volume ls|grep -c "${volume_name}")
		if [ $exists -eq 0 ]
		then
			echo "Create volume $storage..."
			docker volume create $storage >/dev/null
			rt_query=$?
			if [ $rt_query = 0 ]
			then
				echo "Volume $storage successfully created!"
			else
				echo "Error creating persistent storage $storage"
				exit 2
			fi
		else
			echo "recycling volume $storage..."
		fi
}
### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

### DISPLAY LIST OF DOCKERFILES ######################
number=$(ls -1 "${script_path}"/|grep "Dockerfile"|wc -l)
echo "Found  ${number}  Dockerfiles available to build the image in path ${script_path}!"
if [ $number -gt 0 ]
then
	### WRITE SELECTION ##################################
	ls -1 "${script_path}"/|grep "Dockerfile"|awk '{print NR" " $1}'

	### PROMPT USER ######################################
	printf "%b" "Please select a number (1-$number) : "
	read selection
	if [ "$selection" -ge 1 ] && [ "$selection" -le "$number" ]
	then
		### CREATE DOCKER VOLUME FOR WALLET ##################
		storage="ucs_client"
		volume_exists $storage

		### EXTRAC DOCKERFILE NAME ###########################
		dockerfile=$(ls -1 "${script_path}"/|grep "Dockerfile"|awk '{print NR" " $1}'|head -$selection|tail -1|cut -d ' ' -f2)

		### BUILD DOCKER IMAGE ###############################
		echo "Building image..."
		docker build -f $dockerfile . -t ucs_client
		rt_query=$?
		if [ "$rt_query" -eq 0 ]
		then
			echo "Docker image successfully created!"
		else
			echo "Error creating docker image"
			exit 3
		fi
	else
		echo "No number selected"
		exit 1
	fi
fi

