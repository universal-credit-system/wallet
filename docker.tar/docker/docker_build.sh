#!/bin/sh
volume_exists(){
		volume_name=$1
		if ! docker volume ls|grep -qF -- "${volume_name}"
		then
			printf "%s\n" "Create volume ${storage}..."
			if docker volume create "${storage}" >/dev/null
			then
				printf "%s\n" "Volume ${storage} successfully created!"
			else
				printf "%s\n" "Error creating persistent storage ${storage}"
				exit 2
			fi
		else
			printf "%s\n" "recycling volume ${storage}..."
		fi
}
### GET SCRIPT PATH ##################################
script_path=$(cd "$(dirname "$0")" && pwd)

### DISPLAY LIST OF DOCKERFILES ######################
number=$(find "${script_path}" -maxdepth 1 -type f -name "Dockerfile*"|wc -l)
printf "%s\n" "Found  ${number}  Dockerfiles available to build the image in path ${script_path}!"
if [ "${number}" -gt 0 ]
then
	### WRITE SELECTION ##################################
	find "${script_path}" -maxdepth 1 -type f -name "Dockerfile*"|awk -F/ '{print $NF}'|awk '{print NR" " $1}'

	### PROMPT USER ######################################
	printf "%s" "Please select a number (1-${number}) : "
	read selection
	if [ "${selection}" -ge 1 ] && [ "${selection}" -le "${number}" ]
	then
		### CREATE DOCKER VOLUME FOR WALLET ##################
		storage="ucs_client"
		volume_exists "${storage}"

		### EXTRAC DOCKERFILE NAME ###########################
		dockerfile=$(find "${script_path}" -maxdepth 1 -type f -name "Dockerfile*"|awk -F/ '{print $NF}'|awk '{print NR" " $1}'|head -"${selection}"|tail -1|cut -d ' ' -f2)

		### BUILD DOCKER IMAGE ###############################
		printf "%s\n" "Building image..."
		docker build -f "${dockerfile}" . -t ucs_client
		rt_query=$?
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%s\n" "Docker image successfully created!"
		else
			printf "%s\n" "Error creating docker image"
			exit 3
		fi
	else
		printf "%s\n" "No number selected"
		exit 1
	fi
fi

