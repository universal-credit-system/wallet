#!/bin/sh
su ucs_node -c /var/ucs/wallet/controller.sh &
nginx -g daemon off;

