#!/bin/sh
volume_exists(){
		volume_name=$1
		exists=$(docker volume ls|grep -cF -- "${volume_name}")
		return $exists
}
### GET SCRIPT PATH ##################################
script_path=$(cd "$(dirname "$0")" && pwd)

### DISPLAY LIST OF DOCKERFILES ######################
number=$(docker images -q ucs_client|wc -l)
printf "%s\n" "Found  ${number}  images of ucs_client"
if [ "${number}" -gt 0 ]
then
	### WRITE SELECTION ##################################
	docker images -q ucs_client|awk '{print NR" "$1" "$2" "$3" "$4" "$5" "$6}'

	### PROMPT USER ######################################
	printf "%s" "Please select a number (1-${number}) : "
	read selection
	if [ "${selection}" -ge 1 ] && [ "${selection}" -le "${number}" ]
	then
		### EXTRACT IMAGE HASH ###############################
		image_id=$(docker images -q ucs_client|head -"${selection}"|tail -1)

		### RUN DOCKER CONTAINER #############################
		docker run -v ucs_client:/home/ucs_node/ -p 8080:80 -it "${image_id}" sh
	else
		printf "%s\n" "No number selected"
		exit 1
	fi
fi
