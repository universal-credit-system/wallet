#!/bin/sh
script_path=$(dirname $(readlink -f "${0}"))
${script_path}/php_init.sh
su ucs_node -c ${script_path}/gpg_init.sh
su ucs_node -c ${script_path}/setup_server_user.sh
su ucs_node -c ${script_path}/controller.sh &
nginx
while [ $# -gt 0 ]
do
	$1
	shift
done

