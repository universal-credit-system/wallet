#!/bin/sh
/var/ucs/wallet/gpg_init.sh
/var/ucs/wallet/setup_server_user.sh
exec "$@"
