#!/bin/sh
script_path=$(dirname $(readlink -f "${0}"))
${script_path}/gpg_init.sh
${script_path}/setup_server_user.sh
${script_path}/controller.sh &
while [ $# -gt 0 ]
do
	$1
	shift
done
