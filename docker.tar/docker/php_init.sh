#!/bin/sh

### start php-fpm83 ###
php-fpm83

