#!/bin/sh
script_path=$(dirname $(readlink -f "${0}"))
cd ${script_path}/ || exit 1

### START THE CONTROLLER
./controller.sh

