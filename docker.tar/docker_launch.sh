#!/bin/sh

### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

### DISPLAY LIST OF DOCKERFILES ######################
number=$(docker images|grep "ucs_client"|wc -l)
echo "Found  ${number}  images of ucs_client"

### WRITE SELECTION ##################################
docker images|grep "ucs_client"|awk '{print NR" "$1" "$2" "$3" "$4" "$5" "$6}'
if [ $number -gt 0 ]
then
	### PROMPT USER ######################################
	printf "%b" "Please select a number (1-$number) : "
	read selection
	if [ $selection -ge 1 ] && [ $selection -le $number ]
	then
		### EXTRACT IMAGE HASH ###############################
		image_id=$(docker images|grep "ucs_client"|awk '{print NR" "$1" "$2" "$3" "$4" "$5" "$6}'|grep "$selection"|awk '{print $2}')

		### BUILD DOCKER IMAGE ###############################
		echo "Start container..."
		docker run -v ucs_client:/var/ucs/wallet -it ${image_id}
	else
		echo "No number selected"
		exit 1
	fi
fi

