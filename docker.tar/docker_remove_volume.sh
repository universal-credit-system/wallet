#!/bin/sh

### GET SCRIPT PATH ##################################
script_path=$(dirname $(readlink -f "${0}"))

### REMOVE PERSISTENT STORAGE ########################
storage="ucs_client"
echo "Remove volume $storage..."
docker volume rm $storage >/dev/null
rt_query=$?
if [ $rt_query = 0 ]
then
	echo "Volume $storage successfully removed!"
else
	echo "Error removing persistent storage $storage ! Aborting..."
	exit 1
fi
