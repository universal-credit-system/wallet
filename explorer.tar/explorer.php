<?php
	if (isset($_POST['pattern'])) {
		$pattern = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['pattern']);
		$output = shell_exec('<<EXPLORER_INSTALL_PATH>>/explorer.sh "'.$pattern.'"');
		http_response_code(200);
		echo "$output";
	} else {
		http_response_code(400);
		readfile("explorer.html");
	}
?>
