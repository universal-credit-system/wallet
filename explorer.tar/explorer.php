<?php
function run_explorer(array $params, string $wallet_path): array
{
    $descriptors = [
        0 => ['pipe', 'r'], // stdin
        1 => ['pipe', 'w'], // stdout
        2 => ['pipe', 'w'], // stderr
    ];

    $cmd = $wallet_path . '/explorer.sh';
    $proc = proc_open($cmd, $descriptors, $pipes);

    if (!is_resource($proc)) {
        throw new RuntimeException('proc_open failed');
    }

    $input = '';
    foreach ($params as $k => $v) {
        $input .= "{$k} {$v}\n";
    }

    fwrite($pipes[0], $input);
    fclose($pipes[0]);

    $stdout = stream_get_contents($pipes[1]);
    fclose($pipes[1]);

    $stderr = stream_get_contents($pipes[2]);
    fclose($pipes[2]);

    $code = proc_close($proc);

    return [
        'code' => $code,
        'stdout' => $stdout,
        'stderr' => $stderr,
    ];
}
$wallet_path = "<<WALLET_INSTALL_PATH>>";
const STATUS_BAD_REQUEST = 400;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (isset($_POST['action'])) {
		$action = preg_replace("/[^A-Za-z]/", "", $_POST['action']);
		if ($action === 'search' && isset($_POST['pattern'])) {
			$pattern = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['pattern']);
			$result = run_explorer([
			    '-action'	=> $action,
			    '-pattern'	=> $pattern
			], $wallet_path);
			http_response_code(200);
			echo $result['stdout'];
		} elseif ($action === 'display' && isset($_POST['path'])) {
			$trx_file = preg_replace("/[^A-Za-z0-9.]/", "", $_POST['path']);
			$result = run_explorer([
			    '-action'	=> $action,
			    '-path'	=> $trx_file
			], $wallet_path);
			http_response_code(200);
			echo $result['stdout'];
		} else {
			http_response_code(STATUS_BAD_REQUEST);
			readfile("explorer.html");
		}
	} else {
		http_response_code(STATUS_BAD_REQUEST);
		readfile("explorer.html");
	}
} else {
	http_response_code(STATUS_BAD_REQUEST);
	readfile("explorer.html");
}
?>
