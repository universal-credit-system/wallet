#!/bin/sh
get_trx_data(){
		### GET TRX DATA ###############################
		path=$1
		rt_query=1
		if [ -e "${path}" ]
		then
			trx_base=$(basename "${path}")
			trx_hash=$(sha256sum "${path}")
			trx_hash=${trx_hash%% *}
			trx_stamp=${trx_base#*.}
			trx_date_day=$(date -u +%x --date=@"${trx_stamp}")
			trx_date_time=$(date -u +%X.%3N --date=@"${trx_stamp}")
			trx_date="${trx_date_day} ${trx_date_time}"
			IFS='|' read -r trx_amount trx_asset trx_sender trx_receiver  <<-EOF
			$(awk -F: '
				/^:AMNT:/ {amnt=$3}
				/^:ASST:/ {asst=$3}
				/^:SNDR:/ {sndr=$3}
				/^:RCVR:/ {rcvr=$3}
			END { printf "%s|%s|%s|%s\n", amnt, asst, sndr, rcvr }
			' "${path}")
			EOF
			rt_query=$?
		fi
		return "${rt_query}"
}
### GET SCRIPT PATH ##################################
script_path=$(cd "$(dirname "$0")" && pwd)
my_pid=$$
number_entries=500
cmd_var=""
cmd_action=""
cmd_path=""
cmd_pattern=""
trx_base=""
trx_hash=""
trx_date=""
trx_stamp=""
trx_sender=""
trx_receiver=""
trx_amount=""
trx_asset=""

### SOURCE EXPLORER.CONF IF THERE IS ANY #############
if [ -f "${script_path}"/control/explorer.conf ] && [ -s "${script_path}"/control/explorer.conf ]
then
	. "${script_path}"/control/explorer.conf
fi

###CHECK FOR STDIN INPUT##############################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi

### CHECK IF GUI MODE OR CMD MODE AND ASSIGN VARIABLES #######
if [ $# -gt 0 ]
then
	### GO THROUGH PARAMETERS ONE BY ONE ##########################
	while [ $# -gt 0 ]
	do
		### GET TARGET VARIABLES ######################################
		case $1 in
			"-action")	cmd_var=$1
					;;
			"-pattern")	cmd_var=$1
					;;
			"-path")	cmd_var=$1
					;;
			*)		### SET TARGET VARIABLES ######################################
					case "${cmd_var}" in
						"-action")	cmd_action=$1
								;;
						"-pattern")	cmd_pattern=$(echo "$1"|sed 's/\./\\./g')
								;;
						"-path")	cmd_path=$1
								if [ -e "${script_path}/trx/${cmd_path}" ]
			    					then
			    						cmd_path="${script_path}/trx/${cmd_path}"
			    					else
			    						if [ -e "${script_path}/${cmd_path}" ]
			    						then
			    							cmd_path="${script_path}/trx/${cmd_path}"
			    						else
			    							exit 2
			    						fi
			    					fi
								;;
						*)		exit 1
								;;
					esac
					cmd_var=""
					;;
		esac
		shift
	done

	case "${cmd_action}" in
		"search")	### GO THROUGH ALL TRANSACTIONS ################
				for trx in $(grep -s "${cmd_pattern}" "${script_path}"/trx/*|awk -F: '/:.*:/ {print $1}'|sort -r -u -t. -k2 -k3|head -${number_entries})
				do
					### GET TRX DATA ###############################
					get_trx_data "${trx}"
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### VERIFY SIGNATURE ###########################
						signature="ERROR_VERIFY_SIGNATURE"
						if gpg --status-fd 1 --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --verify "${trx}"|grep -q "GOODSIG.*${trx_sender}" && [ "${trx_base%%.*}" = "${trx_sender}" ]
						then
							signature="OK"
						fi

						### GET CONFIRMATIONS ##########################
						trx_confirmations=$(grep -s -l "trx/${trx_base} ${trx_hash}" "${script_path}"/proofs/*/*.txt|grep -c -v "${trx_sender}\|${trx_receiver}")

						### CHECK IF INDEXED ###########################
						index="ERROR_NOT_INDEXED"
						if [ -e "${script_path}/proofs/${trx_sender}/${trx_sender}.txt" ] && grep -q "trx/${trx_base} ${trx_hash}" "${script_path}/proofs/${trx_sender}/${trx_sender}.txt"
						then
							index="OK"
						fi

						### BUILD STRING WITH TRANSACTION INFO #########
						trx_history="${trx_history}</tr><td>${trx_date} (${trx_stamp})</td><td>${trx_sender}</td><td>${trx_receiver}</td><td>${trx_amount}</td><td>${trx_asset}</td><td>${signature}</td><td>${index}</td><td>${trx_confirmations}</td><td><button style=\"border:1px solid #FFFFFF;\" onClick=\"displayTrx(this.value)\" name=\"trx_file\" value=\"${trx_base}\">show trx</button></td></tr>"
					fi
				done
				### BUILD TABLE HEADER #######################
				header="<tr><th>Date</th><th>Sender</th><th>Receiver</th><th>Amount</th><th>Asset</th><th>Signature</th><th>Index</th><th>Confirmations</th><th>Action</th></tr>"

				### DISPLAY TABLE HEADER AND CONTENT #########
				printf "%s" "${header}${trx_history}"
				;;
		"display")	### GET TRX DATA ###############################
				get_trx_data "${cmd_path}"
				trx_text=$(cat "${cmd_path}")
				trx_file=$(basename "${cmd_path}")
				popup="<h3 style=font-family:monospace;>Timestamp:<br>${trx_stamp}<br>(${trx_date})<br><br>Amount:<br>${trx_amount} ${trx_asset}<br><br>Sender:<br>${trx_sender}<br><br>Receiver:<br>${trx_receiver}<br><br>File:<br>${trx_file}<br><br>Raw:<br></h3><pre>${trx_text}</pre>"
				printf "%s" "${popup}"
				;;
	esac
else
	exit 1
fi
