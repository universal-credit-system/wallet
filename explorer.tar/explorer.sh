#!/bin/sh
### GET SCRIPT PATH ############################
script_path=$(dirname "$(readlink -f "${0}")")

### GET PID FOR TMP FILES ######################
my_pid=$$

### GET PATTERN ################################
pattern=$1
pattern=$(echo "${pattern}"|sed 's/\./\\./g')

### GO THROUGH ALL TRANSACTIONS ################
for trx in $(grep "${pattern}" "${script_path}"/trx/* 2>/dev/null|grep ":.*:"|cut -d ':' -f1|sort -r -u -t. -k2 -k3)
do
	### GET SENDER AND RECEIVER OF TRX #############
	sender=$(awk -F: '/:SNDR:/{print $3}' "${trx}")
	receiver=$(awk -F: '/:RCVR:/{print $3}' "${trx}")
	if [ -n "${sender}" ] && [ -n "${receiver}" ]
	then
		signature="ERROR_VERIFY_SIGNATURE"
		### VERIFY SIGNATURE ###########################
		gpg --status-fd 1 --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --verify "${trx}" >"${script_path}/gpg_${my_pid}_verify.tmp" 2>/dev/null
		rt_query=$?
		if [ "$rt_query" -eq 0 ]
		then
			signed_correct=$(grep "GOODSIG" "${script_path}/gpg_${my_pid}_verify.tmp"|grep -c "${sender}")
			if [ "$signed_correct" -ge 1 ]
			then
				trx_file=$(basename "${trx}")
				if [ "${trx_file%%.*}" = "${sender}" ]
				then
					signature="OK"
				fi
			fi
		fi
		rm "${script_path}/gpg_${my_pid}_verify.tmp" 2>/dev/null
		
		### GET TRX DATA ###############################
		trx_base=$(basename "${trx}")
		trx_hash=$(sha256sum "${trx}")
		trx_hash=${trx_hash%% *}
		amount=$(awk -F: '/:AMNT:/{print $3}' "${trx}")
		asset=$(awk -F: '/:ASST:/{print $3}' "${trx}")
		trx_stamp=${trx_base#*.}
		
		### GET CONFIRMATIONS ##########################
		confirmations=$(grep -s -l "trx/${trx_base} ${trx_hash}" "${script_path}"/proofs/*/*.txt|grep -c -v "${sender}\|${receiver}")
		
		### CHECK IF INDEXED ###########################
		index="ERROR_NOT_INDEXED"
		is_indexed=$(grep -c "trx/${trx_base} ${trx_hash}" "${script_path}/proofs/${sender}/${sender}.txt")
		if [ "$is_indexed" -gt 0 ]
		then
			index="OK"
		fi
		
		### BUILD STRING WITH TRANSACTION INFO #########
		trx_history="${trx_history}</tr><td>${trx_stamp}</td><td>${sender}</td><td>${receiver}</td><td>${amount}</td><td>${asset}</td><td>${signature}</td><td>${index}</td><td>${confirmations}</td></tr>"
	fi
done
### BUILD TABLE HEADER #######################
header="<tr><th>Stamp</th><th>Sender</th><th>Receiver</th><th>Amount</th><th>Asset</th><th>Signature</th><th>Index</th><th>Confirmations</th></tr>"

### DISPLAY TABLE HEADER AND CONTENT #########
echo "${header}${trx_history}"

