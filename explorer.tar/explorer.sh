#!/bin/sh
get_trx_data(){
		### GET TRX DATA ###############################
		path=$1
		rt_query=1
		if [ -e "${path}" ]
		then
			trx_base=$(basename "${path}")
			trx_hash=$(sha256sum "${path}")
			trx_hash=${trx_hash%% *}
			trx_stamp=${trx_base#*.}
			trx_date_day=$(date -u +%x --date=@"${trx_stamp}")
			trx_date_time=$(date -u +%X.%3N --date=@"${trx_stamp}")
			trx_date="${trx_date_day} ${trx_date_time}"
			IFS='|' read -r trx_amount trx_asset trx_sender trx_receiver  <<-EOF
			$(awk -F: '
				/^:AMNT:/ {amnt=$3}
				/^:ASST:/ {asst=$3}
				/^:SNDR:/ {sndr=$3}
				/^:RCVR:/ {rcvr=$3}
			END { printf "%s|%s|%s|%s\n", amnt, asst, sndr, rcvr }
			' "${path}")
			EOF
			rt_query=$?
			if [ "${rt_query}" -eq 0 ]
			then
				trx_confirmations=$(find "${script_path}"/proofs -maxdepth 2 -type f -name "*.txt" -exec awk \
						-v trx_ref="trx/${trx_base} ${trx_hash}" \
						-v sndr="${trx_sender}" \
						-v rcvr="${trx_receiver}" \
						-f "${script_path}"/control/functions/get_confirmations.awk {} +)
			fi
		fi
		return "${rt_query}"
}
### GET SCRIPT PATH ##################################
script_path=$(cd "$(dirname "$0")" && pwd)
number_entries=500
debug=0
cmd_var=""
cmd_action=""
cmd_path=""
cmd_pattern=""
trx_base=""
trx_hash=""
trx_date=""
trx_stamp=""
trx_sender=""
trx_receiver=""
trx_amount=""
trx_asset=""
trx_confirmations=""

### SOURCE EXPLORER.CONF IF THERE IS ANY #############
if [ -f "${script_path}"/control/explorer.conf ] && [ -s "${script_path}"/control/explorer.conf ]
then
	. "${script_path}"/control/explorer.conf
fi

###CHECK FOR STDIN INPUT##############################
if [ ! -t 0 ]
then
	set -- $(cat) "$@"
fi

### CHECK IF GUI MODE OR CMD MODE AND ASSIGN VARIABLES #######
if [ $# -gt 0 ]
then
	### GO THROUGH PARAMETERS ONE BY ONE ##########################
	while [ $# -gt 0 ]
	do
		### GET TARGET VARIABLES ######################################
		case $1 in
			"-action")	cmd_var=$1
					;;
			"-pattern")	cmd_var=$1
					;;
			"-path")	cmd_var=$1
					;;
			"-debug")	debug=1
					set -v
					;;
			"-trace")	trace=1
					set -x
					;;		
			*)		### SET TARGET VARIABLES ######################################
					case "${cmd_var}" in
						"-action")	cmd_action=$1
								;;
						"-pattern")	cmd_pattern=$(echo "$1"|sed 's/\./\\./g')
								;;
						"-path")	cmd_path=$1
								if [ -e "${script_path}/trx/${cmd_path}" ]
			    					then
			    						cmd_path="${script_path}/trx/${cmd_path}"
			    					else
			    						if [ -e "${script_path}/${cmd_path}" ]
			    						then
			    							cmd_path="${script_path}/trx/${cmd_path}"
			    						else
			    							exit 2
			    						fi
			    					fi
								;;
						*)		exit 1
								;;
					esac
					cmd_var=""
					;;
		esac
		shift
	done

	case "${cmd_action}" in
		"search")	### GO THROUGH ALL TRANSACTIONS ################
				for trx in $(find "${script_path}"/trx -maxdepth 1 -type f -exec grep -F -- ":${cmd_pattern}" {} +|awk -F: '/:.*:/ {print $1}'|sort -r -u -t. -k2 -k3|head -${number_entries})
				do
					### GET TRX DATA ###############################
					get_trx_data "${trx}"
					rt_query=$?
					if [ "${rt_query}" -eq 0 ]
					then
						### VERIFY SIGNATURE ###########################
						signature="ERROR_VERIFY_SIGNATURE"
						if gpg --status-fd 1 --no-default-keyring --keyring="${script_path}"/control/keyring.file --trust-model always --verify "${trx}"|grep -q -- "GOODSIG.*${trx_sender}" && [ "${trx_base%%.*}" = "${trx_sender}" ]
						then
							signature="OK"
						fi

						### CHECK IF INDEXED ###########################
						index="ERROR_NOT_INDEXED"
						if [ -e "${script_path}/proofs/${trx_sender}/${trx_sender}.txt" ] && grep -qF -- "trx/${trx_base} ${trx_hash}" "${script_path}/proofs/${trx_sender}/${trx_sender}.txt"
						then
							index="OK"
						fi

						### BUILD STRING WITH TRANSACTION INFO #########
						trx_history="${trx_history}</tr><td>${trx_date} (${trx_stamp})</td><td>${trx_sender}</td><td>${trx_receiver}</td><td>${trx_amount}</td><td>${trx_asset}</td><td>${signature}</td><td>${index}</td><td>${trx_confirmations}</td><td><button style=\"border:1px solid #FFFFFF;\" onClick=\"displayTrx(this.value)\" name=\"trx_file\" value=\"${trx_base}\">show trx</button></td></tr>"
					fi
				done
				### BUILD TABLE HEADER #######################
				header="<tr><th>Date</th><th>Sender</th><th>Receiver</th><th>Amount</th><th>Asset</th><th>Signature</th><th>Index</th><th>Confirmations</th><th>Action</th></tr>"

				### DISPLAY TABLE HEADER AND CONTENT #########
				printf "%s" "${header}${trx_history}"
				;;
		"display")	### GET TRX DATA ###############################
				get_trx_data "${cmd_path}"
				trx_text=$(cat "${cmd_path}")
				trx_file=$(basename "${cmd_path}")
				
				###GET MULTI SIG USERS IF THERE ARE ANY################
				trx_msig_users=""
				is_multi_sig=0
				for msig_user_trx in $(awk -F: '$0 ~ /^:MSIG:/ { print $3 }' "${cmd_path}")
				do
					is_multi_sig=1
					sign_string=""
					if [ -f "${script_path}/proofs/${msig_user_trx}/${msig_user_trx}.txt" ] && [ -s "${script_path}/proofs/${msig_user_trx}/${msig_user_trx}.txt" ]
					then
						sign_string=" PENDING"
						if grep -qF -- "trx/${trx_base} ${trx_hash}" "${script_path}/proofs/${msig_user_trx}/${msig_user_trx}.txt"
						then
							sign_string=" SIGNED"
						fi
					fi
					trx_msig_users="${trx_msig_users}${msig_user_trx}${sign_string}<br>"
				done
				wallet_msig_users=""
				for msig_user_wallet in $(grep -sF -- ":MSIG:" "${script_path}/proofs/${trx_sender}/multi.sig"|cut -d ':' -f3)
				do
					is_multi_sig=1
					sign_string=""
					if [ -f "${script_path}/proofs/${msig_user_wallet}/${msig_user_wallet}.txt" ] && [ -s "${script_path}/proofs/${msig_user_wallet}/${msig_user_wallet}.txt" ]
					then
						sign_string=" PENDING"
						if grep -qF -- "trx/${trx_base} ${trx_hash}" "${script_path}/proofs/${msig_user_wallet}/${msig_user_wallet}.txt"
						then
							sign_string=" SIGNED"
						fi
					fi
					wallet_msig_users="${wallet_msig_users}${msig_user_wallet}${sign_string}<br>"
				done
				is_multi_sign_okay=1
				if [ -n "${wallet_msig_users}" ]
				then
					is_multi_sign_okay=1
					###CHECK MULTI-SIG CONFIRMATIONS#############################
					if awk \
					    -v DEBUG_MODE="${debug}" \
					    -v PROOF_PATH="${script_path}/proofs" \
					    -v TRX_REF="trx/${trx_base} ${trx_hash}" \
					    -f "${script_path}"/control/functions/check_multisig.awk \
					    "${script_path}/trx/${trx_base}"
					then
						is_multi_sign_okay=0
					fi
					wallet_msig_users="<br>Multi-Signature Wallet Designated Signers:<br>${wallet_msig_users}"
				fi
				if [ -n "${trx_msig_users}" ]
				then
					is_multi_sign_okay=1
					###CHECK MULTI-SIG CONFIRMATIONS#############################
					if awk \
					    -v DEBUG_MODE="${debug}" \
					    -v PROOF_PATH="${script_path}/proofs" \
					    -v TRX_REF="trx/${trx_base} ${trx_hash}" \
					    -f "${script_path}"/control/functions/check_multisig.awk \
					    "${script_path}/proofs/${trx_sender}/multi.sig"
					then
						is_multi_sign_okay=0
					fi
					trx_msig_users="<br>Multi-Signature Transaction Designated Signers:<br>${trx_msig_users}"
				fi
				msig_status=""
				if [ "${is_multi_sig}" -eq 1 ]
				then
					multi_sig_status="PENDING"
					if [ "${is_multi_sign_okay}" -eq 0 ]
					then
						multi_sig_status="AUTHORIZED"
					fi
					msig_status="<br>Multi-Signature Status:<br>${multi_sig_status}<br>"
				fi
				msig_string="${wallet_msig_users}${trx_msig_users}${msig_status}"
				popup="<h3 style=font-family:monospace;>Timestamp:<br>${trx_stamp}<br>(${trx_date})<br><br>Amount:<br>${trx_amount} ${trx_asset}<br><br>Sender:<br>${trx_sender}<br><br>Receiver:<br>${trx_receiver}<br><br>Confirmations:<br>${trx_confirmations}<br><br>File:<br>trx/${trx_file}<br>${msig_string}<br>Raw:<br></h3><pre>${trx_text}</pre>"
				printf "%s" "${popup}"
				;;
	esac
else
	exit 1
fi
