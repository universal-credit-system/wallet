#!/bin/sh
print_message(){
		if [ "${rt_query}" -eq 0 ]
		then
			printf "%s\n" "DONE"
		else
			printf "%s\n" "FAILED"
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}

### ASSIGN VARIABLES ########################
wwwpath=$1
targetenv=$2
my_pid=$$
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "${0}")
error_counter=0

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

### CHECK IF DIRECTORY-VARIABLE EMPTY #######
if [ -n "${wwwpath}" ]
then
	### CHECK IF DIRECTROY EXISTS ###############
	if [ -d "${wwwpath}" ]
	then
		rt_query=0
		
		### COPY FILES INTO WWW-DATA FOLDER #########
		printf "%s" "[${script_name}][INFO] Moving files into folder $wwwpath..."
		mv -- "${script_path}"/logo.png "${wwwpath}"/logo.png || rt_query=1
		mv -- "${script_path}"/favicon.ico "${wwwpath}"/favicon.ico || rt_query=1
		mv -- "${script_path}"/searchicon.png "${wwwpath}"/searchicon.png || rt_query=1
		mv -- "${script_path}"/explorer.php "${wwwpath}"/explorer.php || rt_query=1
		mv -- "${script_path}"/explorer.html "${wwwpath}"/explorer.html || rt_query=1
		print_message "${rt_query}"

		### WRITE PATH TO SCRIPTS ###################
		printf "%s" "[${script_name}][INFO] Configure scripts..."
		sed "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" "${wwwpath}"/explorer.php >"${wwwpath}"/explorer.php."${my_pid}".tmp && mv -- "${wwwpath}"/explorer.php."${my_pid}".tmp "${wwwpath}"/explorer.php || rt_query=1
		sed "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" "${script_path}"/explorer.sh >"${script_path}"/explorer.sh."${my_pid}".tmp && mv -- "${script_path}"/explorer.sh."${my_pid}".tmp "${script_path}"/explorer.sh && chmod +x "${script_path}"/explorer.sh || rt_query=1
		print_message "${rt_query}"

		#############################################
		### TARGET ENVIRONMENT SPECIFIC TASKS #######
		#############################################

		### TERMUX ##################################
		is_termux=$(echo "${targetenv}"|grep -cF -- "termux")
		if [ "${is_termux}" = 1 ]
		then
			printf "%s" "[${script_name}][INFO] Run termux-fix-shebang for explorer.sh..."
			termux-fix-shebang "${script_path}"/explorer.sh
			print_message "${rt_query}"
		fi
	else
		### WRITE ERROR MESSAGE #####################
		printf "%s" "[${script_name}][ERROR] Path -> \"$wwwpath\" is not a folder!"
		error_counter=1
	fi
else
	### WRITE HELP MESSAGE ######################
	printf "%s\n" "[${script_name}][ERROR] missing path to www root directory! example: ./${script_name} /var/www/html"
	error_counter=1
fi
### DISPLAY OUTPUT #######################
printf "%s\n" "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})"

