#!/bin/sh
print_message(){
		if [ "$rt_query" -eq 0 ]
		then
			printf "%b" "DONE\n"
		else
			printf "%b" "FAILED\n"
			error_detected=1
			error_counter=$(( error_counter + 1 ))
		fi
		rt_query=0
}

### ASSIGN VARIABLES ########################
wwwpath=$1
targetenv=$2
my_pid=$$
script_path=$(dirname "$(readlink -f "${0}")")
script_name=$(basename "${0}")
error_detected=0
error_counter=0

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

### CHECK IF DIRECTORY-VARIABLE EMPTY #######
if [ -n "${wwwpath}" ]
then
	### CHECK IF DIRECTROY EXISTS ###############
	if [ -d "${wwwpath}" ]
	then
		rt_query=0
		
		### COPY FILES INTO WWW-DATA FOLDER #########
		printf "%b" "[ INFO ] Moving files into folder $wwwpath..."
		mv "${script_path}"/logo.png "${wwwpath}"/logo.png || rt_query=1
		mv "${script_path}"/favicon.ico "${wwwpath}"/favicon.ico || rt_query=1
		mv "${script_path}"/searchicon.png "${wwwpath}"/searchicon.png || rt_query=1
		mv "${script_path}"/explorer.php "${wwwpath}"/explorer.php || rt_query=1
		mv "${script_path}"/explorer.html "${wwwpath}"/explorer.html || rt_query=1
		print_message "$rt_query"

		### WRITE PATH TO SCRIPTS ###################
		printf "%b" "[ INFO ] Configure scripts..."
		sed -i."${my_pid}".tmp "s#<<EXPLORER_INSTALL_PATH>>#${script_path}#g" "${wwwpath}"/explorer.php && rm "${wwwpath}"/explorer.php."${my_pid}".tmp 2>/dev/null || rt_query=1
		sed -i."${my_pid}".tmp "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" "${script_path}"/explorer.sh && rm "${script_path}"/explorer.sh."${my_pid}".tmp 2>/dev/null || rt_query=1
		print_message "$rt_query"

		#############################################
		### TARGET ENVIRONMENT SPECIFIC TASKS #######
		#############################################

		### TERMUX ##################################
		is_termux=$(echo "${targetenv}"|grep -c "termux")
		if [ "${is_termux}" = 1 ]
		then
			printf "%b" "[ INFO ] Run termux-fix-shebang for explorer.sh..."
			termux-fix-shebang "${script_path}"/explorer.sh
			print_message "$rt_query"
		fi
	else
		### WRITE ERROR MESSAGE #####################
		echo "[ ERROR ] The provided path -> $wwwpath is not a folder!"
		error_counter=1
	fi
else
	### WRITE HELP MESSAGE ######################
	echo "[ ERROR ] You have to handover the path to www! See below example:"
	echo "          ./install_explorer.sh /var/www/html"
	error_counter=1
fi
### DISPLAY OUTPUT #######################
printf "%b" "[ INFO ] $script_name finished (errors:$error_counter)\n"
