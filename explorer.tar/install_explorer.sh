#!/bin/sh
print_message(){
		if [ "$rt_query" -eq 0 ]
		then
			printf "%b" "DONE\n"
		else
			printf "%b" "FAILED\n"
			error_detected=1
		fi
		rt_query=0
}

### ASSIGN VARIABLES ########################
wwwpath=$1
targetenv=$2
script_path=$(dirname $(readlink -f "${0}"))
script_name=$(basename "${0}")
error_detected=0

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

### CHECK IF DIRECTORY-VARIABLE EMPTY #######
if [ -n "${wwwpath}" ]
then
	### CHECK IF DIRECTROY EXISTS ###############
	if [ -d "${wwwpath}" ]
	then
		rt_query=0
		
		### COPY FILES INTO WWW-DATA FOLDER #########
		printf "%b" "[ INFO ] Moving files into folder $wwwpath..."
		mv "${script_path}"/logo.png "${wwwpath}"/logo.png || rt_query=1
		mv "${script_path}"/favicon.ico "${wwwpath}"/favicon.ico || rt_query=1
		mv "${script_path}"/searchicon.png "${wwwpath}"/searchicon.png || rt_query=1
		mv "${script_path}"/explorer.php "${wwwpath}"/explorer.php || rt_query=1
		mv "${script_path}"/explorer.html "${wwwpath}"/explorer.html || rt_query=1
		print_message "$rt_query"

		### WRITE PATH TO SCRIPTS ###################
		printf "%b" "[ INFO ] Configure scripts..."
		sed -i "s#<<EXPLORER_INSTALL_PATH>>#${script_path}#g" "${wwwpath}"/explorer.php || rt_query=1
		sed -i "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" "${script_path}"/explorer.sh || rt_query=1
		print_message "$rt_query"

		#############################################
		### TARGET ENVIRONMENT SPECIFIC TASKS #######
		#############################################

		### TERMUX ##################################
		is_termux=$(echo "${targetenv}"|grep -c "termux")
		if [ "${is_termux}" = 1 ]
		then
			printf "%b" "[ INFO ] Run termux-fix-shebang for explorer.sh..."
			termux-fix-shebang "${script_path}"/explorer.sh
			print_message "$rt_query"
		fi
		### DISPLAY OUTPUT ##########################
		error_text="with errors"
		if [ "$error_detected" -eq 0 ]
		then
			error_text="without errors"
		fi
		printf "%b" "[ INFO ] $script_name finished $error_text. exiting...\n"
	else
		### WRITE ERROR MESSAGE #####################
		echo "[ ERROR ] The provided path -> $wwwpath is not a folder!"
	fi
else
	### WRITE HELP MESSAGE ######################
	echo "[ ERROR ] You have to handover the path to www! See below example:"
	echo "          ./install_explorer.sh /var/www/html"
fi
