#!/bin/sh
print_message(){
		message="$1"
		if [ -n "${message}" ]
		then
			printf "%b" "${message}"|tee -a "${script_path}/install_explorer_${timestamp}.log"
		else
			if [ "${rt_query}" -eq 0 ]
			then
				printf "%s\n" "DONE"|tee -a "${script_path}/install_explorer_${timestamp}.log"
			else
				printf "%s\n" "FAILED"|tee -a "${script_path}/install_explorer_${timestamp}.log"
				error_counter=$(( error_counter + 1 ))
			fi
		fi
		rt_query=0
}
trap_command(){
	    	command_to_add="$1"
		if [ -n "${command_to_add:-}" ]
		then
			if [ -z "${current_trap:-}" ]
		    	then
		    		### IF EMPTY SET TRAP #########################
		    		current_trap=${command_to_add}
		    		trap "${command_to_add}" EXIT
		    	else
		    		### IF NOT EMPTY APPEND #######################
				trap "${current_trap}; ${command_to_add}" EXIT
				current_trap="${current_trap}; ${command_to_add}"
			fi
		fi
}
### ASSIGN VARIABLES ########################
wwwpath=$1
targetenv=$2
timestamp=$(date -u +%Y%m%d_%H%M%S)
script_path=$(cd "$(dirname "$0")" && pwd)
script_name=$(basename "${0}")
error_counter=0
rt_query=0

### REMOVE TRAILING /########################
wwwpath=$(echo "${wwwpath}"|sed 's/\/$//g')

### CHECK IF DIRECTORY-VARIABLE EMPTY #######
if [ -n "${wwwpath}" ]
then
	### CHECK IF DIRECTROY EXISTS ###############
	if [ -d "${wwwpath}" ]
	then
		rt_query=0
		
		### COPY FILES INTO WWW-DATA FOLDER #########
		print_message "[${script_name}][INFO] Moving files into folder $wwwpath..."
		mv -- "${script_path}"/logo.png "${wwwpath}"/logo.png || rt_query=1
		mv -- "${script_path}"/favicon.ico "${wwwpath}"/favicon.ico || rt_query=1
		mv -- "${script_path}"/searchicon.png "${wwwpath}"/searchicon.png || rt_query=1
		mv -- "${script_path}"/explorer.php "${wwwpath}"/explorer.php || rt_query=1
		mv -- "${script_path}"/explorer.html "${wwwpath}"/explorer.html || rt_query=1
		print_message

		### CREATE TMP ##############################
		trap_command '[ -n "${install_dep:-}" ] && rm -f -- "${install_dep}"'
		install_dep=$(mktemp "${wwwpath}/install_tmp.XXXXXX") || exit 1

		### WRITE PATH TO SCRIPTS ###################
		print_message "[${script_name}][INFO] Configure scripts..."
		sed "s#<<WALLET_INSTALL_PATH>>#${script_path}#g" "${wwwpath}"/explorer.php >"${install_dep}" && mv -- "${install_dep}" "${wwwpath}"/explorer.php || rt_query=1
		sed "s#<<WWW-DATA_INSTALL_PATH>>#${wwwpath}#g" "${script_path}"/explorer.sh >"${install_dep}" && mv -- "${install_dep}" "${script_path}"/explorer.sh && chmod +x "${script_path}"/explorer.sh || rt_query=1
		print_message

		#############################################
		### TARGET ENVIRONMENT SPECIFIC TASKS #######
		#############################################

		### TERMUX ##################################
		is_termux=$(echo "${targetenv}"|grep -cF -- "termux")
		if [ "${is_termux}" = 1 ]
		then
			print_message "[${script_name}][INFO] Run termux-fix-shebang for explorer.sh..."
			termux-fix-shebang "${script_path}"/explorer.sh
			print_message
		fi
	else
		### WRITE ERROR MESSAGE #####################
		print_message "[${script_name}][ERROR] Path -> \"$wwwpath\" is not a folder!\n"
		error_counter=1
	fi
else
	### WRITE HELP MESSAGE ######################
	print_message "[${script_name}][ERROR] missing path to www root directory! example: ./${script_name} /var/www/html\n"
	error_counter=1
fi
### DISPLAY OUTPUT #######################
print_message "[${script_name}][INFO] ${script_name} finished (errors:${error_counter})\n"

