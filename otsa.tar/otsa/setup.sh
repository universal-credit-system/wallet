#!/bin/sh

### GET DIR SCRIPT IS RUNNING IN ###################################
script_path=$(dirname $(readlink -f ${0}))

### CREATE CA-ROOT-KEY AND CA-ROOT-CERTIFICATE-SIGNING-REQUEST #####
openssl req -new -newkey rsa:4096 -nodes -extensions v3_ca -out root.csr -keyout root.key -config ${script_path}/openssl.cnf

### SIGN CA-ROOT-CERTIFICATE #######################################
openssl x509 -trustout -signkey root.key -days 1461 -req -in root.csr -out root.crt

### CREATE TSA-KEY #################################################
openssl genrsa -out tsa.key 4096

### CREATE TSA-CERTIFICATE-SIGNING-REQUEST #########################
openssl req -new -key tsa.key -out tsa.csr -nodes -days 1461 -config ${script_path}/openssl.cnf

### SIGN TSA-CERTIFICATE ###########################################
openssl x509 -req -days 1641 -in tsa.csr -CA root.crt -CAkey root.key -set_serial 01 -out tsa.crt -extfile tsa_extension.cnf

### COPY ROOT-CERTIFICATO CA-CERTIFICATE FOLDER ####################
#sudo cp root.crt /usr/local/share/ca-certificates/
#sudo update-ca-certificates

### TEST TSA SETUP #################################################
#openssl ts -query -data testing.txt -no_nonce -sha512 -out test_query.tsq

### TSA SERVER RESPONSE ############################################
#openssl ts -reply -queryfile test_query.tsq -out test_response.tsr -inkey tsa.key -signer tsa.crt -config ${script_path}/openssl.cnf

### TSA CLIENT VERIFICATION ########################################
#openssl ts -verify -queryfile test_query.tsq -in test_response.tsr -CAfile root.crt -untrusted tsa.crt -config ${script_path}/openssl.cnf
