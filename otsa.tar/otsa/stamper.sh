#!/bin/sh

### GET VARIABLES #########################
query_file=$1
connected_ip=$2
connected_port=$3

### SET TSA FILES #########################
query_file=$(basename $query_file)
response_file=${query_file%%.*}

### GET DIR SCRIPT IS RUNNING IN ##########
script_path=$(dirname $(dirname $(readlink -f ${0})))

### GET PID OF SESSION ####################
session_pid=$$

### WRITE ENTRY TO LOGFILE ################
stamper_date=$(date -u)
echo "${stamper_date}: $connected_ip $connected_port requested timestamp" >>${script_path}/log/tsa.log

### CHECK IF FILE EXISTS ##################
if [ -s "${script_path}/server/tmp/${query_file}" ]
then
	cd ${script_path}/otsa/

	### PROCESS TSA REQUEST #####################
	openssl ts -reply -queryfile ${script_path}/server/tmp/${query_file} -inkey ${script_path}/otsa/tsa.key -signer ${script_path}/otsa/tsa.crt -out ${script_path}/server/tmp/${response_file}.tsr -config ${script_path}/otsa/openssl.cnf 2>/dev/null
fi
