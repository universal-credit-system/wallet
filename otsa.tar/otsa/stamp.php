<?php
	$timestamp_query = 0;
	foreach (getallheaders() as $name => $value) {
		if (strpos($name, 'Content-Type') !== false && strpos($value, 'application/timestamp-query') !== false) {
			$timestamp_query = 1;
		} else {
			$ovar = 1;
		}
	}
	if ($timestamp_query == 1) {
		$remote_address = $_SERVER['REMOTE_ADDR'];
        	$remote_port = $_SERVER['REMOTE_PORT'];
		$tmp_id = uniqid();
		$query_file = "/home/m0e/ucs3/wallet/server/tmp/tsa_".$tmp_id.".tsq";
		$response_file = "/home/m0e/ucs3/wallet/server/tmp/tsa_".$tmp_id.".tsr";
		$input_body = file_get_contents('php://input');
		file_put_contents($query_file, $input_body);
		$output_var = shell_exec("/home/m0e/ucs3/wallet/otsa/stamper.sh $query_file $remote_address $remote_port");
		header('Content-Description: File Transfer');
		header('Content-Type: application/timestamp-reply');
		header('Content-Disposition: attachment; filename="'.basename($response_file).'"');
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length: ' . filesize($response_file));
		readfile($response_file);
		unlink($query_file);
		unlink($response_file);
	} else {
		var_dump(http_response_code(400));
	}
?>
