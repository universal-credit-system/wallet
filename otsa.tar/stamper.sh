#!/bin/sh

### GET CONTROLLER.SH PID #################
controller_pid=$1

### GET DIR SCRIPT IS RUNNING IN ##########
script_path=$(dirname $(readlink -f ${0}))

### GET PID OF SESSION ####################
session_pid=$$

### CHECK IF SERVER IS STILL RUNNING ######
ps --pid $controller_pid >/dev/null
controller_running=$?

if [ $controller_running = 0 ]
then
	### WRITE ENTRY TO LOGFILE ##################
	stamper_date=$(date -u)
	echo "${stamper_date}: $TCPREMOTEIP $TCPREMOTEPORT requested timestamp" >>${script_path}/log/tsa.log

	### WRITE OUTPUT TO TMP FILE ################
	dd bs=1 status=none >${script_path}/server/tmp/tsa_${session_pid}.out

	### CHECK IF CORRECT PACKAGE ################
	is_timestamp_query=$(grep -c "Content-Type: application/timestamp-query" ${script_path}/server/tmp/tsa_${session_pid}.out)
	if [ $is_timestamp_query = 1 ]
	then
		###CHECK CONTENT LENGTH ####################
		content_length_available=$(grep -c "Content-Length:" ${script_path}/server/tmp/tsa_${session_pid}.out)
		if [ $content_length_available = 1 ]
		then
			### GET TOTAL SIZE ##########################
			content_length=$(grep "Content-Length:" ${script_path}/server/tmp/tsa_${session_pid}.out)
			content_length=${content_length#* }
			
			### GET BODY ################################
			tail -c ${content_length} ${script_path}/server/tmp/tsa_${session_pid}.out >${script_path}/server/tmp/tsa_${session_pid}.tsq

			### PROCESS TSA REQUEST #####################
			openssl ts -reply -queryfile ${script_path}/server/tsa_${session_pid}.tsq -inkey ${script_path}/otsa/tsa.key -signer ${script_path}/otsa/tsa.crt -out ${script_path}/server/tmp/tsa_${session_pid}.tsr
			rt_query=$?
			if [ $rt_query = 0 ]
			then
		        	### IF SUCCESSFULL RESPOND ##################
		        	cat ${script_path}/server/tmp/tsa_${session_pid}.tsr
			fi

			### REMOVE TSA QUERY & RESPONSE #####################
			rm ${script_path}/server/tmp/tsa_${session_pid}.ts* 2>/dev/null
		fi
	fi

	### REMOVE TMP FILE #########################
	rm ${script_path}/server/tmp/tsa_${session_pid}.out 2>/dev/null
fi
